CREATE TABLE `main`.`data_server` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `expansion_id` TINYINT(3) UNSIGNED NOT NULL,
  `server_name` VARCHAR(256) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `ds_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE NO ACTION ON DELETE NO ACTION
) CHARSET=utf8 COLLATE=utf8_unicode_ci;
