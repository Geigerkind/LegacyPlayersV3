ALTER TABLE `main`.`data_server`
	ADD COLUMN `archived` BIT(1) DEFAULT 0 NOT NULL AFTER `retail_id`;

UPDATE `main`.`data_server` SET `archived` = 1 WHERE `id` IN (4, 9, 10, 16);