ALTER TABLE `main`.`armory_guild`
	ADD COLUMN `server_uid` BIGINT(20) UNSIGNED NOT NULL AFTER `id`,
  ADD  UNIQUE INDEX `ag_unique_sid_name` (`server_id`, `guild_name`);

ALTER TABLE `main`.`armory_guild`
  ADD  UNIQUE INDEX `ag_unique_sid_uid` (`server_uid`, `server_id`);
