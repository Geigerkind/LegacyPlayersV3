ALTER TABLE `main`.`armory_instance_resets`
	ADD COLUMN `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT FIRST,
  DROP PRIMARY KEY,
  ADD PRIMARY KEY (`id`),
  ADD  UNIQUE INDEX `unique_value` (`server_id`, `map_id`, `difficulty`, `reset_time`);
