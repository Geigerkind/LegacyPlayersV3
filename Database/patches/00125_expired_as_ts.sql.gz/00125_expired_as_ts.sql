ALTER TABLE `main`.`instance_meta`
    CHANGE `expired` `expired` BIGINT(20) UNSIGNED NULL COMMENT 'TS when instance expired';