ALTER TABLE `main`.`instance_attempt`
	ADD COLUMN `npc_id` INT(11) UNSIGNED NOT NULL AFTER `creature_id`,
  ADD CONSTRAINT `ia2_npc_id` FOREIGN KEY (`npc_id`) REFERENCES `main`.`data_npc`(`id`) ON UPDATE CASCADE;
