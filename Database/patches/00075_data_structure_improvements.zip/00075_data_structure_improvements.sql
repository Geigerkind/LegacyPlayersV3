ALTER TABLE `main`.`armory_item`
  DROP FOREIGN KEY `ai_random_property_id`;

ALTER TABLE `main`.`armory_item`
	CHANGE `random_property_id` `random_property_id` SMALLINT(5) UNSIGNED NULL;

ALTER TABLE `main`.`data_item_random_property`
	CHANGE `id` `id` SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `main`.`armory_item`
  ADD CONSTRAINT `ai_random_property_id` FOREIGN KEY (`random_property_id`) REFERENCES `main`.`data_item_random_property`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;
