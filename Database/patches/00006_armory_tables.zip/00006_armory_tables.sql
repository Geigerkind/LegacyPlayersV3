CREATE TABLE `main`.`armory_guild` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `server_id` INT(11) UNSIGNED NOT NULL,
  `guild_name` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `ag_server_id` FOREIGN KEY (`server_id`) REFERENCES `main`.`data_server`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `main`.`armory_character` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `server_id` INT(11) UNSIGNED NOT NULL,
  `server_uid` BIGINT(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `ac_server_id` FOREIGN KEY (`server_id`) REFERENCES `main`.`data_server`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE `main`.`armory_item` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `item_id` INT(11) UNSIGNED NOT NULL,
  `enchant_id` INT(11) UNSIGNED,
  `gem_id1` INT(11) UNSIGNED,
  `gem_id2` INT(11) UNSIGNED,
  `gem_id3` INT(11) UNSIGNED,
  `gem_id4` INT(11) UNSIGNED,
  PRIMARY KEY (`id`),
  CONSTRAINT `ai_item_id` FOREIGN KEY (`item_id`) REFERENCES `main`.`data_item`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `ai_enchant_id` FOREIGN KEY (`enchant_id`) REFERENCES `main`.`data_enchant`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `ai_gem_id1` FOREIGN KEY (`gem_id1`) REFERENCES `main`.`data_gem`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `ai_gem_id2` FOREIGN KEY (`gem_id2`) REFERENCES `main`.`data_gem`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `ai_gem_id3` FOREIGN KEY (`gem_id3`) REFERENCES `main`.`data_gem`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `ai_gem_id4` FOREIGN KEY (`gem_id4`) REFERENCES `main`.`data_gem`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE `main`.`armory_gear` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `head` INT(11) UNSIGNED,
  `neck` INT(11) UNSIGNED,
  `shoulder` INT(11) UNSIGNED,
  `back` INT(11) UNSIGNED,
  `chest` INT(11) UNSIGNED,
  `shirt` INT(11) UNSIGNED,
  `tabard` INT(11) UNSIGNED,
  `wrist` INT(11) UNSIGNED,
  `main_hand` INT(11) UNSIGNED,
  `off_hand` INT(11) UNSIGNED,
  `ternary_hand` INT(11) UNSIGNED,
  `glove` INT(11) UNSIGNED,
  `belt` INT(11) UNSIGNED,
  `leg` INT(11) UNSIGNED,
  `boot` INT(11) UNSIGNED,
  `ring1` INT(11) UNSIGNED,
  `ring2` INT(11) UNSIGNED,
  `trinket1` INT(11) UNSIGNED,
  `trinket2` INT(11) UNSIGNED,
  PRIMARY KEY (`id`),
  CONSTRAINT `ag_slot1` FOREIGN KEY (`head`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot2` FOREIGN KEY (`neck`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot3` FOREIGN KEY (`shoulder`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot4` FOREIGN KEY (`back`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot5` FOREIGN KEY (`chest`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot6` FOREIGN KEY (`shirt`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot7` FOREIGN KEY (`tabard`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot8` FOREIGN KEY (`wrist`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot9` FOREIGN KEY (`main_hand`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot10` FOREIGN KEY (`off_hand`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot11` FOREIGN KEY (`ternary_hand`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot12` FOREIGN KEY (`glove`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot14` FOREIGN KEY (`leg`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot15` FOREIGN KEY (`boot`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot16` FOREIGN KEY (`ring1`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot17` FOREIGN KEY (`ring2`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot18` FOREIGN KEY (`trinket1`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot19` FOREIGN KEY (`trinket2`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL,
  CONSTRAINT `ag_slot13` FOREIGN KEY (`belt`) REFERENCES `main`.`armory_item`(`id`) ON UPDATE SET NULL ON DELETE SET NULL
);

CREATE TABLE `main`.`armory_character_info` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `gear_id` INT(11) UNSIGNED NOT NULL,
  `hero_class` TINYINT(3) UNSIGNED NOT NULL,
  `level` TINYINT(3) UNSIGNED NOT NULL,
  `gender` BINARY(1) NOT NULL,
  `profession1` TINYINT(3) UNSIGNED,
  `prefession2` TINYINT(3) UNSIGNED,
  `talent_specialization` VARCHAR(128),
  `faction` BINARY(1) NOT NULL,
  `race` TINYINT(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `aci_hero_class` FOREIGN KEY (`hero_class`) REFERENCES `main`.`data_hero_class`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `aci_race` FOREIGN KEY (`race`) REFERENCES `main`.`data_race`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `aci_prof1` FOREIGN KEY (`profession1`) REFERENCES `main`.`data_profession`(`id`) ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT `aci_prof2` FOREIGN KEY (`prefession2`) REFERENCES `main`.`data_profession`(`id`) ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT `aci_gear_id` FOREIGN KEY (`gear_id`) REFERENCES `main`.`armory_gear`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE `main`.`armory_character_history` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `character_id` INT(11) UNSIGNED NOT NULL,
  `character_info_id` INT(11) UNSIGNED NOT NULL,
  `character_name` VARCHAR(64) NOT NULL,
  `guild_id` INT(11) UNSIGNED NOT NULL,
  `guild_rank` VARCHAR(64) NOT NULL,
  `timestamp` BIGINT(20) UNSIGNED NOT NULL DEFAULT UNIX_TIMESTAMP(),
  PRIMARY KEY (`id`),
  CONSTRAINT `ach_guild_id` FOREIGN KEY (`guild_id`) REFERENCES `main`.`armory_guild`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `ach_character_id` FOREIGN KEY (`character_id`) REFERENCES `main`.`armory_character`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `ach_character_info_id` FOREIGN KEY (`character_info_id`) REFERENCES `main`.`armory_character_info`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`armory_character`
	ADD COLUMN `last_update` INT(11) UNSIGNED NULL AFTER `server_uid`,
  ADD CONSTRAINT `ac_last_update` FOREIGN KEY (`last_update`) REFERENCES `main`.`armory_character_history`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;
