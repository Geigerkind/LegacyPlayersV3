UPDATE main.data_item_stat SET stat_type=34 WHERE stat_type=35;

INSERT INTO main.data_localization (language_id, content) VALUES
(1, "Increases your shield block rating by $s1."),
(1, "Increases your expertise rating by $s1."),
(1, "Improves haste rating by $s1."),
(1, "Improves spell critical strike rating by $s1."),
(1, "Improves spell haste rating by $s1."),
(1, "Improves spell hit rating by $s1."),
(1, "Increases your resilience rating by $s1."),
(1, "Increases your spell penetration rating by $s1.");