INSERT INTO main.data_localization (language_id, content) VALUES
(1, "Herbalism"),
(1, "Mining"),
(1, "Skinning"),
(1, "Alchemy"),
(1, "Blacksmithing"),
(1, "Enchanting"),
(1, "Engineering"),
(1, "Inscription"),
(1, "Jewelcrafting"),
(1, "Leatherworking"),
(1, "Tailoring");

INSERT INTO main.data_profession (localization_id) VALUES
(28),
(29),
(31),
(32),
(33),
(34),
(35),
(36),
(37),
(38);