CREATE TABLE `main`.`data_encounter` (  
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  `map_id` SMALLINT(6) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) ,
  CONSTRAINT `denc_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE,
  CONSTRAINT `denc_map_id` FOREIGN KEY (`map_id`) REFERENCES `main`.`data_map`(`id`) ON UPDATE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`instance_attempt`   
	DROP COLUMN `npc_id`, 
	CHANGE `creature_id` `encounter_id` INT(11) UNSIGNED NOT NULL, 
  DROP INDEX `ia2_npc_id`,
  DROP FOREIGN KEY `ia2_npc_id`,
  ADD CONSTRAINT `ia2_encounter_id` FOREIGN KEY (`encounter_id`) REFERENCES `main`.`data_encounter`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;

CREATE TABLE `main`.`data_encounter_npcs` (  
  `encounter_id` INT(11) UNSIGNED NOT NULL,
  `npc_id` INT(11) UNSIGNED NOT NULL,
  `requires_death` BIT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`encounter_id`, `npc_id`) ,
  CONSTRAINT `denc_npc_encounter_id` FOREIGN KEY (`encounter_id`) REFERENCES `main`.`data_encounter`(`id`) ON UPDATE CASCADE,
  CONSTRAINT `denc_npc_npc_id` FOREIGN KEY (`npc_id`) REFERENCES `main`.`data_npc`(`id`) ON UPDATE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;
