INSERT INTO `main`.`data_localization` (`id`, `language_id`, `content`) VALUES
(119822, 1, "Flame Leviathan - 1 Tower destroyed"),
(119823, 1, "Flame Leviathan - 2 Tower destroyed"),
(119824, 1, "Flame Leviathan - 3 Tower destroyed"),
(119825, 1, "Flame Leviathan HM - 4 Tower destroyed"),
(119826, 1, "XT-002 Deconstructor HM"),
(119827, 1, "Assembly of Iron HM"),
(119828, 1, "Freya - Knock"),
(119829, 1, "Freya - Knock, Knock"),
(119830, 1, "Freya HM - Knock, Knock, Knock"),
(119831, 1, "Thorim HM"),
(119832, 1, "Mimiron HM"),
(119833, 1, "General Vezax HM"),
(119834, 1, "Yogg-Saron - Three Lights in the Darkness"),
(119835, 1, "Yogg-Saron - Two Lights in the Darkness"),
(119836, 1, "Yogg-Saron HM - One Light in the Darkness"),
(119837, 1, "Yogg-Saron HM - Alone in the Darkness");

INSERT INTO `main`.`data_encounter` (`id`, `localization_id`, `map_id`, `retail_id`) VALUES
-- Flame Leviathan HM
(146, 119822, 603, NULL),
(147, 119823, 603, NULL),
(148, 119824, 603, NULL),
(149, 119825, 603, NULL),
-- XT Hardmode
(150, 119826, 603, NULL),
-- Iron Council HM
(151, 119827, 603, NULL),
-- Freya HM
(152, 119828, 603, NULL),
(153, 119829, 603, NULL),
(154, 119830, 603, NULL),
-- Thorim HM
(155, 119831, 603, NULL),
-- Mimiron HM
(156, 119832, 603, NULL),
-- General Vezax HM
(157, 119833, 603, NULL),
-- Yogg-Saron HM
(158, 119834, 603, NULL),
(159, 119835, 603, NULL),
(160, 119836, 603, NULL),
(161, 119837, 603, NULL);
