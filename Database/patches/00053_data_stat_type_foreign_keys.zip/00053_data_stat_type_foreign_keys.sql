ALTER TABLE `main`.`data_item_stat`
  ADD CONSTRAINT `dis_stat_type` FOREIGN KEY (`stat_type`) REFERENCES `main`.`data_stat_type`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE `main`.`data_enchant`
	CHANGE `stat_type1` `stat_type1` TINYINT(3) UNSIGNED NULL,
	CHANGE `stat_value1` `stat_value1` SMALLINT(5) UNSIGNED NULL,
	CHANGE `stat_type2` `stat_type2` TINYINT(3) UNSIGNED NULL,
	CHANGE `stat_value2` `stat_value2` SMALLINT(5) UNSIGNED NULL,
	CHANGE `stat_type3` `stat_type3` TINYINT(3) UNSIGNED NULL,
	CHANGE `stat_value3` `stat_value3` SMALLINT(5) UNSIGNED NULL;

UPDATE main.data_enchant SET stat_value3=NULL, stat_type3=NULL WHERE stat_type3 = 0;
UPDATE main.data_enchant SET stat_value2=NULL, stat_type2=NULL WHERE stat_type2 = 0;
UPDATE main.data_enchant SET stat_value1=NULL, stat_type1=NULL WHERE stat_type1 = 0;

ALTER TABLE `main`.`data_enchant`
  ADD CONSTRAINT `dets_stat_type1` FOREIGN KEY (`stat_type1`) REFERENCES `main`.`data_stat_type`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;

ALTER TABLE `main`.`data_enchant` DROP FOREIGN KEY `dets_expansion_id`;

ALTER TABLE `main`.`data_enchant` ADD CONSTRAINT `dets_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE `main`.`data_enchant`
  ADD CONSTRAINT `dets_stat_type2` FOREIGN KEY (`stat_type2`) REFERENCES `main`.`data_stat_type`(`id`) ON UPDATE CASCADE ON DELETE SET NULL,
  ADD CONSTRAINT `dets_stat_type3` FOREIGN KEY (`stat_type3`) REFERENCES `main`.`data_stat_type`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;
