CREATE TABLE `main`.`data_item_effect` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `expansion_id` TINYINT(3) UNSIGNED NOT NULL,
  `item_id` INT(11) UNSIGNED NOT NULL,
  `cooldown` INT(11) UNSIGNED NOT NULL,
  `spell_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `die2_item_id` FOREIGN KEY (`expansion_id`, `item_id`) REFERENCES `main`.`data_item`(`expansion_id`, `id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `die2_spell_id` FOREIGN KEY (`expansion_id`, `spell_id`) REFERENCES `main`.`data_spell`(`expansion_id`, `id`) ON UPDATE CASCADE ON DELETE CASCADE
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`data_item_effect`
	CHANGE `spell_id` `spell_id` INT(11) UNSIGNED NOT NULL  AFTER `item_id`,
	ADD COLUMN `charges` TINYINT(3) UNSIGNED NOT NULL AFTER `cooldown`;

ALTER TABLE `main`.`data_item_effect`
	CHANGE `cooldown` `cooldown` INT(11) NOT NULL,
	CHANGE `charges` `charges` TINYINT(3) NOT NULL;
