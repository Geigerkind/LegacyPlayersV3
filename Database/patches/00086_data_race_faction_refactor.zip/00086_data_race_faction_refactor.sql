ALTER TABLE `main`.`data_race`
	ADD COLUMN `faction` BINARY(1) DEFAULT '0' NOT NULL AFTER `localization_id`;

INSERT INTO data_race (`localization_id`, `faction`) VALUES
(45383, 1);

UPDATE main.data_race SET localization_id = 9, faction=1 WHERE id = 2;
UPDATE main.data_race SET localization_id = 6, faction=1 WHERE id = 5;
UPDATE main.data_race SET localization_id = 7, faction=1 WHERE id = 6;
UPDATE main.data_race SET localization_id = 2, faction=0 WHERE id = 7;
UPDATE main.data_race SET localization_id = 45383, faction=1 WHERE id = 9;
UPDATE main.data_race SET localization_id = 10, faction=1 WHERE id = 10;
UPDATE main.data_race SET localization_id = 5, faction=0 WHERE id = 11;

ALTER TABLE `main`.`armory_character_info`
	DROP COLUMN `faction`;
