CREATE TABLE `main`.`data_spell_effect` (
  `expansion_id` TINYINT(3) UNSIGNED NOT NULL,
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `points_lower` INT(11) NOT NULL,
  `points_upper` INT(11) NOT NULL,
  `amount` INT(11) UNSIGNED NOT NULL,
  `duration` INT(11) UNSIGNED NOT NULL,
  `radius` INT(11) UNSIGNED NOT NULL,
   KEY(`id`),
  PRIMARY KEY (`expansion_id`, `id`),
  CONSTRAINT `dsv_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE NO ACTION
);
