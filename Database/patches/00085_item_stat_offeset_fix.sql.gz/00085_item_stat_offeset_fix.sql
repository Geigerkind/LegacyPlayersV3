INSERT INTO main.data_localization (language_id, content) VALUES
(1, "HealthRegen");

INSERT INTO main.data_stat_type (localization_id) VALUES
(119301);

ALTER TABLE `main`.`data_item_stat`
  DROP INDEX `dis_type_unique`,
  DROP FOREIGN KEY `dis_stat_type`;

UPDATE main.data_item_stat SET stat_type = stat_type + 1;

ALTER TABLE `main`.`data_item_stat`
  ADD  UNIQUE INDEX `dis_unique` (`expansion_id`, `item_id`, `stat_type`),
  ADD CONSTRAINT `dis_stat_type` FOREIGN KEY (`stat_type`) REFERENCES `main`.`data_stat_type`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;
