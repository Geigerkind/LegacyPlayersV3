CREATE TABLE `main`.`data_difficulty` (
  `id` TINYINT(3) UNSIGNED NOT NULL,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  `icon` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`) ,
  CONSTRAINT `dd_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `main`.`data_localization` (`language_id`, `content`) VALUES
(1,"10 Player"),
(1,"25 Player"),
(1,"10 Player (Heroic)"),
(1,"25 Player (Heroic)"),
(1,"40 Player"),
(1,"20 Player");

INSERT INTO `main`.`data_difficulty` (`id`, `localization_id`, `icon`) VALUES
(3,119809,"difficulty_10_player"),
(4,119810,"difficulty_25_player"),
(5,119811,"difficulty_10_player_heroic"),
(6,119812,"difficulty_25_player_heroic"),
(9,119813,"difficulty_40_player"),
(148,119814,"difficulty_20_player");