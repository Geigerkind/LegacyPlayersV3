CREATE TABLE `main`.`instance_battleground` (
  `instance_meta_id` INT(11) UNSIGNED NOT NULL,
  `winner` TINYINT(1) UNSIGNED NOT NULL,
  `score_alliance` INT(11) UNSIGNED NOT NULL,
  `score_horde` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`instance_meta_id`) ,
  CONSTRAINT `ib_instance_meta_id` FOREIGN KEY (`instance_meta_id`) REFERENCES `main`.`instance_meta`(`id`) ON UPDATE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;
