UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (33113, 33114, 33139, 33387, 33142, 33214, 34275);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (33118, 33121, 33122);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (33186, 33388, 33846, 33453);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (33293, 33329, 33343, 33346, 33344);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (32933, 32934, 33768, 32930);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (34035);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (33651, 33670, 34057, 33836);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (32919, 33202, 32916, 32918, 33203, 30391, 32913, 32914, 32915);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (32882, 33110, 32886, 32907, 32908, 32883, 32885, 32872, 32873, 32877, 32925, 32878, 32924, 32876, 32922, 32904, 32923, 33196);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (32926, 32938);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (33488, 33524);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (33288, 33136, 33966, 33985, 33983, 33990, 33943, 33988);
UPDATE `main`.`data_npc` SET `map_id` = 603 WHERE id IN (32871, 33052, 32955, 34097);
UPDATE `main`.`data_npc` SET `map_id` = 649 WHERE id IN (34796, 35469, 35144, 34799, 34797, 35470);
UPDATE `main`.`data_npc` SET `map_id` = 649 WHERE id IN (34780, 34825, 34826, 34815);
UPDATE `main`.`data_npc` SET `map_id` = 649 WHERE id IN (34461, 34458, 34460, 34451, 34469, 36116, 34459, 34467, 34448, 34468, 36114, 34449, 34465, 34445, 34471, 36109);
UPDATE `main`.`data_npc` SET `map_id` = 649 WHERE id IN (34456, 36120, 34466, 36108, 34447, 36119, 34473, 34441, 34472, 34454, 36121, 34470, 34444, 34463, 34455);
UPDATE `main`.`data_npc` SET `map_id` = 649 WHERE id IN (34474, 34450, 36124, 34475, 36118, 34453, 36122);
UPDATE `main`.`data_npc` SET `map_id` = 649 WHERE id IN (35465, 36301);
UPDATE `main`.`data_npc` SET `map_id` = 649 WHERE id IN (34496, 36066, 34497, 36065);
UPDATE `main`.`data_npc` SET `map_id` = 649 WHERE id IN (34606, 34607, 34605);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (38711, 38712);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (37949, 37890, 38136, 38010, 38135, 38009, 38222);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (36948, 37200, 38607, 37187);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (36961, 36978, 37830, 37026, 37116, 36969);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (36960, 36982, 37029, 37930, 37117, 36968);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (37540, 37215);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (38508);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (36897, 36889);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (37562, 37697);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (38369, 38454);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (37868, 36791, 37934, 37886, 37907, 37863);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (36980);
UPDATE `main`.`data_npc` SET `map_id` = 631 WHERE id IN (37695, 37698, 36633, 36701, 36609, 37799, 36824);
UPDATE `main`.`data_npc` SET `map_id` = 724 WHERE id IN (40142, 39863, 40683, 40681);

INSERT INTO `main`.`data_localization` (`language_id`, `id`, `content`) VALUES
(1, 119816, "Assembly of Iron"),
(1, 119817, "Beasts of Northrend"),
(1, 119818, "Faction Champions"),
(1, 119819, "Twin Val'kyr"),
(1, 119820, "Gunship Battle"),
(1, 119821, "Blood Prince Council");

INSERT INTO `main`.`data_encounter` (`id`, `localization_id`, `map_id`) VALUES
-- Ulduar
(114, 58925, 603), -- Flame Leviathan
(115, 60721, 603), -- Ignis the Furnace Master
(116, 65038, 603), -- Razorscale
(117, 70246, 603), -- XT-002 Deconstructor
(118, 119816, 603), -- Assembly of Iron
(119, 61711, 603), -- Kologarn
(120, 54554, 603), -- Auriaya
(121, 63001, 603), -- Mimiron
(122, 59174, 603), -- Freya
(123, 68206, 603), -- Thorim
(124, 60435, 603), -- Hodir
(125, 59539, 603), -- General Vezax
(126, 70312, 603), -- Yogg-Saron
(127, 53776, 603), -- Algalon the Observer
-- PDOK
(128, 119817, 649), -- Beasts of Northrend
(129, 62324, 649), -- Lord Jaraxxus
(130, 119818, 649), -- Faction Champions
(131, 119819, 649), -- Twin Val'kyr
(132, 54094, 649), -- Anub'arak
-- ICC
(133, 62332, 631), -- Lord Marrowgar
(134, 61886, 631), -- Lady Deathwhisper
(135, 119820, 631), -- Gunship Battle
(136, 57140, 631), -- Deathbringer Saurfang
(137, 58778, 631), -- Festergut
(138, 65430, 631), -- Rotface
(139, 64693, 631), -- Professor Putricde
(140, 119821, 631), -- Blood Prince Council
(141, 55158, 631), -- Blood-Queen Lana'thel
(142, 68956, 631), -- Valithria Dreamwalker
(143, 66507, 631), -- Sindragosa
(144, 50223, 631), -- The Lich King
-- Ruby
(145, 60151, 724); -- Halion

INSERT INTO `main`.`data_encounter_npcs` (`encounter_id`, `npc_id`, `requires_death`, `can_start_encounter`, `is_pivot`, `health_treshold`) VALUES
(114, 33113, 1, 1, 1, NULL), -- Flame Leviathan
(114, 33114, 0, 0, 0, NULL), -- Flame Leviathan Seat
(114, 33139, 0, 0, 0, NULL), -- Flame Leviathan Turret
(114, 33387, 0, 0, 0, NULL), -- Writing Lasher
(114, 33142, 0, 0, 0, NULL), -- Leviathan Defense Turret
(114, 33214, 0, 0, 0, NULL), -- Mechanolift 304-A
(114, 34275, 0, 0, 0, NULL), -- Ward of Life
(115, 33118, 1, 1, 1, NULL), -- Ignis the Furnace Master
(115, 33121, 0, 0, 0, NULL), -- Iron Construct
(115, 33122, 0, 0, 0, NULL), -- Iron Construct (Magma)
(116, 33186, 1, 1, 1, NULL), -- Razorscale
(116, 33388, 0, 0, 1, NULL), -- Dark Rune Guardian
(116, 33846, 0, 0, 1, NULL), -- Dark Rune Sentinel
(116, 33453, 0, 0, 1, NULL), -- Dark Rune Watcher
(117, 33293, 1, 1, 1, NULL), -- XT-002 Deconstructor
(117, 33329, 0, 0, 0, NULL), -- Heart of the Deconstructor
(117, 33343, 0, 0, 0, NULL), -- XS-013 Scrapbot
(117, 33346, 0, 0, 0, NULL), -- XE-321 Boombot
(117, 33344, 0, 0, 0, NULL), -- XE-321 Pummeller
(118, 32867, 1, 1, 0, NULL), -- Steelbreaker
(118, 32927, 1, 1, 0, NULL), -- Runemaster Molgeim
(118, 32857, 1, 1, 0, NULL), -- Stormcaller Brundir
(119, 32930, 1, 1, 1, NULL), -- Kologarn
(119, 32933, 0, 1, 0, NULL), -- Left Arm
(119, 32934, 0, 1, 0, NULL), -- Right Arm
(119, 33768, 0, 1, 0, NULL), -- Rubble
(120, 33515, 1, 1, 1, NULL), -- Auriaya
(120, 34014, 0, 1, 0, NULL), -- Sanctum Sentry
(120, 34035, 0, 0, 0, NULL), -- Feral Defender
(121, 33350, 0, 1, 0, NULL), -- Mimiron
(121, 34071, 1, 1, 0, NULL), -- Leviathan Mk II
(121, 33432, 1, 0, 0, NULL), -- Leviathan Mk II
(121, 33651, 1, 0, 0, NULL), -- VX-001
(121, 33670, 1, 0, 1, NULL), -- Aerial Command Unit
(121, 34057, 0, 0, 0, NULL), -- Assault Bot
(121, 33836, 0, 0, 0, NULL), -- Bomb Bot
(121, 34191, 0, 0, 0, NULL), -- Trash Bot
(122, 32906, 0, 1, 1, 2), -- Freya
(122, 32919, 0, 0, 0, NULL), -- Storm Lasher
(122, 33202, 0, 0, 0, NULL), -- Ancient Water Spirit
(122, 32916, 0, 0, 0, NULL), -- Snaplasher
(122, 32918, 0, 0, 0, NULL), -- Detonating Lasher
(122, 33203, 0, 0, 0, NULL), -- Ancient Conservator
(122, 30391, 0, 0, 0, NULL), -- Healthy Mushroom
(122, 32915, 0, 0, 0, NULL), -- Elder Brightleaf
(122, 32914, 0, 0, 0, NULL), -- Elder Stonebark
(122, 32913, 0, 0, 0, NULL), -- Elder Ironbranch
(123, 32865, 0, 1, 1, 2), -- Thorim
(123, 32882, 0, 1, 0, NULL), -- Jormungar Behemoth
(123, 33110, 0, 0, 0, NULL), -- Dark Rune Acolyte
(123, 32886, 0, 0, 0, NULL), -- Dark Rune Acolyte
(123, 32907, 0, 0, 0, NULL), -- Captured Mercenary Captain
(123, 32908, 0, 0, 0, NULL), -- Captured Mercenary Captain
(123, 32883, 0, 0, 0, NULL), -- Captured Mercenary Soldier
(123, 32885, 0, 0, 0, NULL), -- Captured Mercenary Soldier
(123, 32872, 0, 0, 0, NULL), -- Runic Colossus
(123, 32873, 0, 0, 0, NULL), -- Ancient Rune Giant
(123, 32877, 0, 0, 0, NULL), -- Dark Rune Warbringer
(123, 32925, 0, 0, 0, NULL), -- Dark Rune Warbringer
(123, 32878, 0, 0, 0, NULL), -- Dark Rune Evoker
(123, 32924, 0, 0, 0, NULL), -- Dark Rune Evoker
(123, 32876, 0, 0, 0, NULL), -- Dark Rune Champion
(123, 32922, 0, 0, 0, NULL), -- Dark Rune Champion
(123, 32904, 0, 0, 0, NULL), -- Dark Rune Commoner
(123, 32923, 0, 0, 0, NULL), -- Dark Rune Commoner
(123, 33196, 0, 0, 0, NULL), -- Sif
(124, 32845, 0, 1, 1, 2), -- Hodir
(124, 32926, 0, 1, 0, NULL), -- Flash Freeze
(124, 32938, 0, 1, 0, NULL), -- Flash Freeze
(125, 33271, 1, 1, 1, NULL), -- General Vezax
(125, 33488, 0, 0, 0, NULL), -- Saronite Vapor
(125, 33524, 1, 0, 1, NULL), -- Saronite Animus
(126, 33288, 1, 0, 1, NULL), -- Yogg-Saron
(126, 33136, 1, 1, 0, NULL), -- Guardian of Yogg-Saron
(126, 33134, 0, 1, 0, NULL), -- Sara
(126, 33966, 0, 0, 0, NULL), -- Crusher Tentacle
(126, 33985, 0, 0, 0, NULL), -- Corruptor Tentacle
(126, 33983, 0, 0, 0, NULL), -- Constrictor Tentacle
(126, 33990, 0, 0, 0, NULL), -- Laughing Skull
(126, 33943, 1, 0, 0, NULL), -- Influence Tentacle
(126, 33890, 0, 0, 0, NULL), -- Brain of Yogg-Saron
(126, 33988, 0, 0, 0, NULL), -- Immortal Guardian
(127, 32871, 0, 1, 1, 2), -- Algalon the Observer
(127, 33052, 0, 0, 0, NULL), -- Living Constellation
(127, 32955, 0, 0, 0, NULL), -- Collapsing Star
(127, 34097, 0, 0, 0, NULL), -- Unleashed Dark Matter
(128, 34796, 1, 1, 0, NULL), -- Gormok the Impaler
(128, 35469, 1, 1, 0, NULL), -- Gormok the Impaler
(128, 35144, 1, 0, 0, NULL), -- Acidmaw
(128, 34799, 1, 0, 0, NULL), -- Dreadscale
(128, 34797, 1, 0, 1, NULL), -- Icehowl
(128, 35470, 1, 0, 1, NULL), -- Icehowl
(129, 34780, 1, 1, 1, NULL), -- Lord Jaraxxus
(129, 34825, 0, 0, 0, NULL), -- Nether Portal
(129, 34826, 0, 0, 0, NULL), -- Misstress of Pain
(129, 34815, 0, 0, 0, NULL), -- Felflame Infernal
(130, 34461, 1, 1, 0, NULL),
(130, 34458, 1, 1, 0, NULL),
(130, 34460, 1, 1, 0, NULL),
(130, 34451, 1, 1, 0, NULL),
(130, 34469, 1, 1, 0, NULL),
(130, 36116, 1, 1, 0, NULL),
(130, 34459, 1, 1, 0, NULL),
(130, 34467, 1, 1, 0, NULL),
(130, 34448, 1, 1, 0, NULL),
(130, 34468, 1, 1, 0, NULL),
(130, 36114, 1, 1, 0, NULL),
(130, 34449, 1, 1, 0, NULL),
(130, 34465, 1, 1, 0, NULL),
(130, 34445, 1, 1, 0, NULL),
(130, 34471, 1, 1, 0, NULL),
(130, 36109, 1, 1, 0, NULL),
(130, 34456, 1, 1, 0, NULL),
(130, 36120, 1, 1, 0, NULL),
(130, 34466, 1, 1, 0, NULL),
(130, 36108, 1, 1, 0, NULL),
(130, 34447, 1, 1, 0, NULL),
(130, 36119, 1, 1, 0, NULL),
(130, 34473, 1, 1, 0, NULL),
(130, 34441, 1, 1, 0, NULL),
(130, 34472, 1, 1, 0, NULL),
(130, 34454, 1, 1, 0, NULL),
(130, 36121, 1, 1, 0, NULL),
(130, 34470, 1, 1, 0, NULL),
(130, 34444, 1, 1, 0, NULL),
(130, 34463, 1, 1, 0, NULL),
(130, 34455, 1, 1, 0, NULL),
(130, 34474, 1, 1, 0, NULL),
(130, 34450, 1, 1, 0, NULL),
(130, 36124, 1, 1, 0, NULL),
(130, 34475, 1, 1, 0, NULL),
(130, 36118, 1, 1, 0, NULL),
(130, 34453, 1, 1, 0, NULL),
(130, 36122, 1, 1, 0, NULL),
(130, 35465, 0, 1, 0, NULL),
(130, 36301, 0, 1, 0, NULL),
(131, 34496, 1, 1, 0, NULL),
(131, 36066, 1, 1, 0, NULL),
(131, 34497, 1, 1, 0, NULL),
(131, 36065, 1, 1, 0, NULL),
(132, 34564, 1, 1, 1, NULL),
(132, 34606, 0, 0, 0, NULL),
(132, 34607, 0, 0, 0, NULL),
(132, 34605, 0, 0, 0, NULL),
(133, 36612, 1, 1, 1, NULL), -- Lord Marrowgar
(133, 38711, 0, 0, 0, NULL), -- Bone Spike
(133, 38712, 0, 0, 0, NULL), -- Bone Spike
(134, 36855, 1, 1, 1, NULL), -- Lady Deathwhisper
(134, 37949, 0, 0, 0, NULL), -- Cult Adherent
(134, 37890, 0, 0, 0, NULL), -- Cult Fanatic
(134, 38136, 0, 0, 0, NULL), -- Empowered Adherent
(134, 38010, 0, 0, 0, NULL), -- Reanimated Adherent
(134, 38135, 0, 0, 0, NULL), -- Deformed Fanatic
(134, 38009, 0, 0, 0, NULL), -- Reanimated Fanatic
(134, 38222, 0, 0, 0, NULL), -- Vengeful Shade
(135, 37540, 1, 1, 1, NULL), -- The Skybreaker
(135, 37215, 1, 1, 1, NULL), -- Orgrim's Hammer
(135, 36948, 0, 0, 0, NULL),
(135, 37200, 0, 0, 0, NULL),
(135, 38607, 0, 0, 0, NULL),
(135, 37187, 0, 0, 0, NULL),
(135, 36961, 0, 0, 0, NULL),
(135, 36978, 0, 0, 0, NULL),
(135, 37830, 0, 0, 0, NULL),
(135, 37026, 0, 0, 0, NULL),
(135, 37116, 0, 0, 0, NULL),
(135, 36969, 0, 0, 0, NULL),
(135, 36960, 0, 0, 0, NULL),
(135, 36982, 0, 0, 0, NULL),
(135, 37029, 0, 0, 0, NULL),
(135, 37930, 0, 0, 0, NULL),
(135, 37117, 0, 0, 0, NULL),
(135, 36968, 0, 0, 0, NULL),
(136, 37813, 1, 1, 1, NULL), -- Deathbringer Sauerfang
(136, 38508, 0, 0, 0, NULL), -- Blood Beast
(137, 36626, 1, 1, 1, NULL), -- Festergut
(138, 36627, 1, 1, 1, NULL), -- Rotface
(138, 36897, 0, 0, 0, NULL), -- Little Ooze
(138, 36889, 0, 0, 0, NULL), -- Big Ooze
(139, 36678, 1, 1, 1, NULL), -- Professor Putricide
(139, 37562, 0, 0, 0, NULL), -- Gas Cloud
(139, 37697, 0, 0, 0, NULL), -- Volatile Ooze
(140, 37970, 1, 1, 0, NULL), -- Prince Valanar
(140, 37973, 1, 1, 0, NULL), -- Prince Taldaram
(140, 37972, 1, 1, 0, NULL), -- Prince Keleseth
(140, 38369, 0, 0, 0, NULL), -- Dark Nucleus
(140, 38454, 0, 0, 0, NULL), -- Kinetic Bomb
(141, 38004, 1, 1, 1, NULL), -- Blood-Queen Lana'thel
(142, 36789, 0, 1, 1, 99), -- Valithria Dreamwalker
(142, 37868, 0, 1, 0, NULL), -- Risen Archmage
(142, 36791, 0, 0, 0, NULL), -- Blazing Skeleton
(142, 37934, 0, 0, 0, NULL), -- Blistering Zombie
(142, 37886, 0, 0, 0, NULL), -- Gluttonoues Abomination
(142, 37907, 0, 0, 0, NULL), -- Rot Worm
(142, 37863, 0, 0, 0, NULL), -- Suppressor
(143, 37755, 1, 1, 1, NULL), -- Sindragosa
(143, 36980, 0, 0, 0, NULL), -- Ice Tomb
(144, 38153, 1, 1, 1, NULL), -- The Lich King
(144, 37695, 0, 0, 0, NULL), -- Drudge Ghoul
(144, 37698, 0, 0, 0, NULL), -- Shambling Horror
(144, 36633, 0, 0, 0, NULL), -- Ice Sphere
(144, 36701, 0, 0, 0, NULL), -- Raging Spirit
(144, 36609, 0, 0, 0, NULL), -- Val'kyr Shadowguard
(144, 37799, 0, 0, 0, NULL), -- Vile Spirit
(144, 36824, 0, 0, 0, NULL), -- Spirit Warden
(145, 40142, 1, 1, 1, NULL), -- Halion
(145, 39863, 1, 1, 1, NULL), -- Halion
(145, 40683, 0, 0, 0, NULL), -- Living Ember
(145, 40681, 0, 0, 0, NULL); -- Living Inferno

