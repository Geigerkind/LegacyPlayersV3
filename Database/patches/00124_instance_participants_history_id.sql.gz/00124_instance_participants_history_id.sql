ALTER TABLE `main`.`instance_participants`
	ADD COLUMN `history_id` INT(11) UNSIGNED NULL AFTER `character_id`,
  ADD CONSTRAINT `ip_history_id` FOREIGN KEY (`history_id`) REFERENCES `main`.`armory_character_history`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;
