CREATE TABLE `main`.`utility_tiny_url` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `url_payload` VARCHAR(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;
