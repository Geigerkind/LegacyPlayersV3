ALTER TABLE `main`.`instance_participants`
  DROP PRIMARY KEY,
  ADD PRIMARY KEY (`instance_meta_id`, `character_id`);
