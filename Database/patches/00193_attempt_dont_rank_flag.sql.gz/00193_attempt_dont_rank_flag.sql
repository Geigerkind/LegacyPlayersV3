ALTER TABLE `main`.`instance_attempt`
	ADD COLUMN `rankable` TINYINT(1) DEFAULT 1 NOT NULL AFTER `is_kill`;
