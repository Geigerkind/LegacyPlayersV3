ALTER TABLE `main`.`data_item_random_property`
	CHANGE `enchant_id2` `enchant_id2` INT(11) UNSIGNED NULL,
	CHANGE `enchant_id3` `enchant_id3` INT(11) UNSIGNED NULL,
	CHANGE `enchant_id4` `enchant_id4` INT(11) UNSIGNED NULL,
	CHANGE `enchant_id5` `enchant_id5` INT(11) UNSIGNED NULL;

DELETE FROM main.data_item_random_property WHERE id = 2164;

UPDATE main.data_item_random_property SET enchant_id2=NULL WHERE enchant_id2=0;
UPDATE main.data_item_random_property SET enchant_id3=NULL WHERE enchant_id3=0;
UPDATE main.data_item_random_property SET enchant_id4=NULL WHERE enchant_id4=0;
UPDATE main.data_item_random_property SET enchant_id5=NULL WHERE enchant_id5=0;

ALTER TABLE `main`.`data_item_random_property`
  ADD CONSTRAINT `dirp_enchant_id1` FOREIGN KEY (`enchant_id1`, `expansion_id`) REFERENCES `main`.`data_enchant`(`id`, `expansion_id`) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE `main`.`data_item_random_property` DROP FOREIGN KEY `dirp_expansion_id`;

ALTER TABLE `main`.`data_item_random_property` ADD CONSTRAINT `dirp_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `main`.`data_item_random_property`
  ADD CONSTRAINT `dirp_enchant_id2` FOREIGN KEY (`enchant_id2`, `expansion_id`) REFERENCES `main`.`data_enchant`(`id`, `expansion_id`) ON UPDATE CASCADE ON DELETE NO ACTION,
  ADD CONSTRAINT `dirp_enchant_id3` FOREIGN KEY (`enchant_id3`, `expansion_id`) REFERENCES `main`.`data_enchant`(`id`, `expansion_id`) ON UPDATE CASCADE ON DELETE NO ACTION,
  ADD CONSTRAINT `dirp_enchant_id4` FOREIGN KEY (`enchant_id4`, `expansion_id`) REFERENCES `main`.`data_enchant`(`id`, `expansion_id`) ON UPDATE CASCADE ON DELETE NO ACTION,
  ADD CONSTRAINT `dirp_enchant_id5` FOREIGN KEY (`enchant_id5`, `expansion_id`) REFERENCES `main`.`data_enchant`(`id`, `expansion_id`) ON UPDATE CASCADE ON DELETE NO ACTION;
