INSERT INTO `main`.`data_encounter_npcs` (`encounter_id`, `npc_id`, `requires_death`, `can_start_encounter`, `is_pivot`, `health_treshold`) VALUES
(102, 24850, 1, 1, 1, 3),
(102, 24891, 0, 0, 0, NULL);