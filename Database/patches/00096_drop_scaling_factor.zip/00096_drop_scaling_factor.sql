ALTER TABLE `main`.`armory_item`
	DROP COLUMN `random_property_scaling_factor`;
