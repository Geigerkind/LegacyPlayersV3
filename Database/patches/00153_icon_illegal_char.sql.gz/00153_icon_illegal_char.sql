UPDATE data_icon SET icon = "ability_druid_mangle" WHERE id = 4520;
UPDATE data_icon SET icon = "inv_helmet_100" WHERE id = 1125;
UPDATE data_icon SET icon = "spell_shadow_devouringplague" WHERE id = 5189;