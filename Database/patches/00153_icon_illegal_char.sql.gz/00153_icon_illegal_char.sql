UPDATE main.data_icon SET icon = "ability_druid_mangle3" WHERE id = 4520;
UPDATE main.data_icon SET icon = "inv_helmet_142" WHERE id = 1125;
UPDATE main.data_icon SET icon = "spell_shadow_devouringplague2" WHERE id = 5189;