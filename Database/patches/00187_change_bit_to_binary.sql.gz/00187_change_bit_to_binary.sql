ALTER TABLE `main`.`data_server`
	CHANGE `archived` `archived` BINARY(1) DEFAULT '0' NOT NULL;
