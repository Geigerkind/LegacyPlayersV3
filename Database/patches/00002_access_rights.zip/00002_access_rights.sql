ALTER TABLE `main`.`member`
	ADD COLUMN `access_rights` INT(11) UNSIGNED DEFAULT 0 NOT NULL AFTER `new_mail`;
