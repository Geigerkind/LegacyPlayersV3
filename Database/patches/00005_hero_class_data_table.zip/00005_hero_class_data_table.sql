CREATE TABLE `main`.`data_hero_class` (
  `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `dhc_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE NO ACTION ON DELETE NO ACTION
);
