CREATE TABLE `main`.`data_item_sheath` (
  `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `dis3_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`data_item`
	CHANGE `sheath` `sheath` TINYINT(3) UNSIGNED NULL;

UPDATE main.data_item SET sheath = NULL WHERE sheath = 0;
UPDATE main.data_item SET sheath = 6 WHERE sheath = 7;

INSERT INTO main.data_localization (language_id, content) VALUES
(1, "One Handed"),
(1, "Staff"),
(1, "Two Handed Weapon"),
(1, "Off-hand"),
(1, "Enchanter's Rod"),
(1, "Held in Off-hand");

INSERT INTO main.data_item_sheath (localization_id) VALUES
(86756),
(86757),
(86758),
(86759),
(86760),
(86761);

ALTER TABLE `main`.`data_item`
  ADD CONSTRAINT `di_sheath` FOREIGN KEY (`sheath`) REFERENCES `main`.`data_item_sheath`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;
