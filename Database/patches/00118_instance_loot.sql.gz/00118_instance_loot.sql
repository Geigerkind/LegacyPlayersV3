CREATE TABLE `main`.`instance_loot` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `instance_meta_id` INT(11) UNSIGNED NOT NULL,
  `character_id` INT(11) UNSIGNED NOT NULL,
  `item_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`, `instance_meta_id`) ,
  CONSTRAINT `il_instance_meta_id` FOREIGN KEY (`instance_meta_id`) REFERENCES `main`.`instance_meta`(`id`) ON UPDATE CASCADE,
  CONSTRAINT `il_character_id` FOREIGN KEY (`character_id`) REFERENCES `main`.`armory_character`(`id`) ON UPDATE CASCADE,
  CONSTRAINT `il_item_id` FOREIGN KEY (`item_id`) REFERENCES `main`.`data_item`(`id`) ON UPDATE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;
