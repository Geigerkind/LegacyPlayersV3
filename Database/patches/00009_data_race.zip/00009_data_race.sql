INSERT INTO main.data_localization (language_id, content) VALUES
(1, "Human"),
(1, "Gnome"),
(1, "Dwarf"),
(1, "Night elf"),
(1, "Draenei"),
(1, "Undead"),
(1, "Tauren"),
(1, "Troll"),
(1, "Orc"),
(1, "Blood elf");

INSERT INTO main.data_race (localization_id) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10);