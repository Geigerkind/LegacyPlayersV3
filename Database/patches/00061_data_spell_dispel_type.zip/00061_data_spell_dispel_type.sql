CREATE TABLE `main`.`data_spell_dispel_type` (
  `id` TINYINT(3) UNSIGNED NOT NULL,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  `color` VARCHAR(6) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `dsdt_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`data_spell_dispel_type`
	CHANGE `id` `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT;

INSERT INTO main.data_localization (language_id, content) VALUES
(1, "None"),
(1, "Magic"),
(1, "Curse"),
(1, "All(M+C+D+P)"),
(1, "Special - npc only"),
(1, "ZG Trinkets");

INSERT INTO main.data_spell_dispel_type (localization_id, color) VALUES
(86861, "cc0000"),
(86862, "3399ff"),
(86863, "9900ff"),
(80567, "996600"),
(41737, "009900"),
(85253, "000000"),
(78119, "000000"),
(86864, "000000"),
(81407, "000000"),
(86865, "cc0000"),
(86866, "000000");

UPDATE main.data_spell SET dispel_type = dispel_type + 1;

ALTER TABLE `main`.`data_spell`
  ADD CONSTRAINT `dsp_dispel_type` FOREIGN KEY (`dispel_type`) REFERENCES `main`.`data_spell_dispel_type`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_spell` DROP FOREIGN KEY `dps_subtext_localization_id`;

ALTER TABLE `main`.`data_spell` ADD CONSTRAINT `dps_subtext_localization_id` FOREIGN KEY (`subtext_localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_spell` DROP FOREIGN KEY `dsp_aura_localization_id`;

ALTER TABLE `main`.`data_spell` ADD CONSTRAINT `dsp_aura_localization_id` FOREIGN KEY (`aura_localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_spell` DROP FOREIGN KEY `dsp_description_localization_id`;

ALTER TABLE `main`.`data_spell` ADD CONSTRAINT `dsp_description_localization_id` FOREIGN KEY (`description_localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_spell` DROP FOREIGN KEY `dsp_expansion_id`;

ALTER TABLE `main`.`data_spell` ADD CONSTRAINT `dsp_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE `main`.`data_spell` DROP FOREIGN KEY `dsp_localization_id`;

ALTER TABLE `main`.`data_spell` ADD CONSTRAINT `dsp_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;
