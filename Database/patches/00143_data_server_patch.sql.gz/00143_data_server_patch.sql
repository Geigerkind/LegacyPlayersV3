ALTER TABLE `main`.`data_server`
	ADD COLUMN `patch` VARCHAR(20) NOT NULL AFTER `owner`;

UPDATE `main`.`data_server` SET `patch` = "1.12.1" WHERE id = 1;
UPDATE `main`.`data_server` SET `patch` = "2.4.3" WHERE id = 2;
UPDATE `main`.`data_server` SET `patch` = "3.3.5" WHERE id = 3;