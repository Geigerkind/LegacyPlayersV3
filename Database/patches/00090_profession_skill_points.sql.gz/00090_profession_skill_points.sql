ALTER TABLE `main`.`armory_character_history`
	ADD COLUMN `prof_skill_points1` SMALLINT(5) UNSIGNED NULL AFTER `title`,
	ADD COLUMN `prof_skill_points2` SMALLINT(5) UNSIGNED NULL AFTER `prof_skill_points1`;
