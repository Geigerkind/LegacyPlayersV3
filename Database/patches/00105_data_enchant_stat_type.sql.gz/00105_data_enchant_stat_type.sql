UPDATE main.data_enchant SET stat_type1 = stat_type1 + 1 WHERE NOT ISNULL(stat_type1);
UPDATE main.data_enchant SET stat_type2 = stat_type2 + 1 WHERE NOT ISNULL(stat_type2);
UPDATE main.data_enchant SET stat_type3 = stat_type3 + 1 WHERE NOT ISNULL(stat_type3);