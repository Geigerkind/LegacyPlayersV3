INSERT INTO `main`.`data_localization` (`id`, `language_id`, `content`) VALUES
(119838, 1, "Hodir HM");

INSERT INTO `main`.`data_encounter` (`id`, `localization_id`, `map_id`, `retail_id`) VALUES
(162, 119838, 603, NULL);