ALTER TABLE `main`.`utility_addon_paste`
	ADD COLUMN `member_id` INT(11) UNSIGNED NOT NULL AFTER `content`,
  ADD CONSTRAINT `uap_member_id` FOREIGN KEY (`member_id`) REFERENCES `main`.`account_member`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;
