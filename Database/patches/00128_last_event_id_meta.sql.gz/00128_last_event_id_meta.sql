ALTER TABLE `main`.`instance_meta`
    ADD COLUMN `last_event_id` INT(11) UNSIGNED DEFAULT 1 NOT NULL AFTER `map_id`;