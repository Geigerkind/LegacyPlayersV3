CREATE TABLE `main`.`armory_arena_team` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `server_uid` BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
  `server_id` INT(11) UNSIGNED NOT NULL,
  `team_name` VARCHAR(32) NOT NULL,
  `size_type` TINYINT(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`armory_arena_team`
  ADD CONSTRAINT `FK_aat_server_id` FOREIGN KEY (`server_id`) REFERENCES `main`.`data_server`(`id`) ON UPDATE CASCADE ON DELETE NO ACTION;

ALTER TABLE `main`.`armory_character_history`
	ADD COLUMN `arena2` INT(11) UNSIGNED NULL AFTER `facial`,
	ADD COLUMN `arena3` INT(11) UNSIGNED NULL AFTER `arena2`,
	ADD COLUMN `arena5` INT(11) UNSIGNED NULL AFTER `arena3`,
  ADD CONSTRAINT `ach_arena2` FOREIGN KEY (`arena2`) REFERENCES `main`.`armory_arena_team`(`id`) ON UPDATE CASCADE ON DELETE SET NULL,
  ADD CONSTRAINT `ach_arena3` FOREIGN KEY (`arena3`) REFERENCES `main`.`armory_arena_team`(`id`) ON UPDATE CASCADE ON DELETE SET NULL,
  ADD CONSTRAINT `ach_arena5` FOREIGN KEY (`arena5`) REFERENCES `main`.`armory_arena_team`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;
