ALTER TABLE `main`.`data_encounter_npcs`
	ADD COLUMN `health_treshold` TINYINT(3) UNSIGNED NULL COMMENT 'Between 0 and 100' AFTER `is_pivot`;

UPDATE `main`.`data_encounter_npcs` SET `health_treshold` = 3 WHERE encounter_id = 102 AND npc_id = 24844;