INSERT INTO `main`.`data_encounter_npcs` (`encounter_id`, `npc_id`, `requires_death`, `can_start_encounter`, `is_pivot`, `health_treshold`) VALUES
(57, 66534, 0, 1, 0, NULL);