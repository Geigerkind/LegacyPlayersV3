CREATE TABLE `main`.`data_item_random_property` (
  `expansion_id` TINYINT(3) UNSIGNED NOT NULL,
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  `enchant_id1` INT(11) UNSIGNED NOT NULL,
  `enchant_id2` INT(11) UNSIGNED NOT NULL,
  `enchant_id3` INT(11) UNSIGNED NOT NULL,
  `enchant_id4` INT(11) UNSIGNED NOT NULL,
  `enchant_id5` INT(11) UNSIGNED NOT NULL,
   KEY(`id`),
  PRIMARY KEY (`expansion_id`, `id`),
  CONSTRAINT `dirp_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE NO ACTION,
  CONSTRAINT `dirp_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE NO ACTION
);

ALTER TABLE `main`.`armory_item`
	ADD COLUMN `random_property_id` INT(11) UNSIGNED NULL AFTER `item_id`;
