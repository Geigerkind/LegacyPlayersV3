UPDATE `main`.`data_encounter_npcs` SET requires_death=1,can_start_encounter=1,is_pivot=0 WHERE encounter_id=71 AND npc_id = 17256;
UPDATE `main`.`data_encounter_npcs` SET requires_death=1,can_start_encounter=1,is_pivot=0 WHERE encounter_id=71 AND npc_id = 17257;
UPDATE `main`.`data_encounter_npcs` SET requires_death=0,can_start_encounter=0,is_pivot=0 WHERE encounter_id=71 AND npc_id = 17454;