CREATE TABLE `main`.`data_map` (
  `id` SMALLINT(6) UNSIGNED NOT NULL,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  `icon` TINYINT(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) ,
  CONSTRAINT `dm_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`data_map`
	CHANGE `icon` `icon` VARCHAR(100) NOT NULL;
