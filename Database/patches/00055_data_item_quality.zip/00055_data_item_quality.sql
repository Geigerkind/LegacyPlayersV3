CREATE TABLE `main`.`data_item_quality` (
  `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  `color` VARCHAR(6) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `diq_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE NO ACTION
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

UPDATE main.data_item SET quality = quality + 1;

INSERT INTO main.data_localization (language_id, content) VALUES
(1, "Poor"),
(1, "Common"),
(1, "Uncommon"),
(1, "Rare"),
(1, "Epic"),
(1, "Legendary"),
(1, "Artifact"),
(1, "Heirloom");

INSERT INTO main.data_item_quality (localization_id, color) VALUES
(86744, "9d9d9d"),
(86745, "e8e8e8"),
(86746, "1eff00"),
(86747, "0070ff"),
(86748, "a335ee"),
(86749, "ff8000"),
(86750, "e6cc80"),
(86751, "00ccff");

ALTER TABLE `main`.`data_item`
  ADD CONSTRAINT `di_quality` FOREIGN KEY (`quality`) REFERENCES `main`.`data_item_quality`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

