INSERT INTO `main`.`data_encounter_npcs` (`encounter_id`, `npc_id`, `requires_death`, `can_start_encounter`, `is_pivot`, `health_treshold`) VALUES
(104, 25038, 1, 1, 1, NULL);

DELETE FROM `main`.`data_encounter_npcs` WHERE `encounter_id` = 104 AND `npc_id` = 25039;