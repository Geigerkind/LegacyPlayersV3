ALTER TABLE `main`.`utility_tiny_url`
	CHANGE `url_payload` `url_payload` TEXT(32768) CHARSET utf8 COLLATE utf8_unicode_ci NOT NULL;

ALTER TABLE `main`.`utility_tiny_url`
	CHANGE `url_payload` `url_payload` TEXT CHARSET utf8 COLLATE utf8_unicode_ci NOT NULL;
