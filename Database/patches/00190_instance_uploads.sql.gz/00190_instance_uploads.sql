CREATE TABLE `main`.`instance_uploads` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `member_id` INT(11) UNSIGNED NOT NULL,
  `timestamp` BIGINT(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `main`.`instance_uploads` (`id`,`member_id`, `timestamp`) VALUES
(1, 21, 0);

ALTER TABLE `main`.`instance_uploads`
  ADD CONSTRAINT `fk_upload_member_id` FOREIGN KEY (`member_id`) REFERENCES `main`.`account_member`(`id`) ON UPDATE CASCADE ON DELETE NO ACTION;

ALTER TABLE `main`.`instance_meta`
	ADD COLUMN `upload_id` INT(11) UNSIGNED DEFAULT 1 NOT NULL AFTER `uploaded_user`;

ALTER TABLE `main`.`instance_meta`
	DROP COLUMN `uploaded_user`;

ALTER TABLE `main`.`instance_meta`
  ADD CONSTRAINT `im_upload_id` FOREIGN KEY (`upload_id`) REFERENCES `main`.`instance_uploads`(`id`) ON UPDATE CASCADE;
