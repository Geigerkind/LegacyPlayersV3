INSERT INTO `main`.`data_encounter_npcs` (`encounter_id`, `npc_id`, `requires_death`, `can_start_encounter`, `is_pivot`, `health_treshold`) VALUES
(141, 37955, 1, 1, 1, NULL),
(143, 36853, 1, 1, 1, NULL),
(144, 36597, 1, 1, 1, NULL);

UPDATE `main`.`data_npc` SET `is_boss` = 1, `map_id` = 631 WHERE `id` = 36853;