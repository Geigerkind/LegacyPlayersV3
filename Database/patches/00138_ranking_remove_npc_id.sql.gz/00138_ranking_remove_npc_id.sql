ALTER TABLE `main`.`instance_ranking_damage`
	DROP COLUMN `npc_id`,
  DROP INDEX `ird_npc_id`,
  DROP FOREIGN KEY `ird_npc_id`;

ALTER TABLE `main`.`instance_ranking_heal`
	DROP COLUMN `npc_id`,
  DROP INDEX `irh_npc_id`,
  DROP FOREIGN KEY `irh_npc_id`;

ALTER TABLE `main`.`instance_ranking_threat`
	DROP COLUMN `npc_id`,
  DROP INDEX `irt_npc_id`,
  DROP FOREIGN KEY `irt_npc_id`;
