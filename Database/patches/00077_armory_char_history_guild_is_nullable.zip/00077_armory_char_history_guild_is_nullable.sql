ALTER TABLE `main`.`armory_character_history`
	CHANGE `guild_id` `guild_id` INT(11) UNSIGNED NULL,
	CHANGE `guild_rank` `guild_rank` VARCHAR(64) CHARSET utf8 COLLATE utf8_unicode_ci NULL;

ALTER TABLE `main`.`armory_character_history` DROP FOREIGN KEY `ach_guild_id`;

ALTER TABLE `main`.`armory_character_history` ADD CONSTRAINT `ach_guild_id` FOREIGN KEY (`guild_id`) REFERENCES `main`.`armory_guild`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;
