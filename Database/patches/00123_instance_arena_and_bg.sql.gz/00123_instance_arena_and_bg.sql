ALTER TABLE `main`.`instance_battleground`
	CHANGE `winner` `winner` TINYINT(1) UNSIGNED NULL,
	CHANGE `score_alliance` `score_alliance` INT(11) UNSIGNED NULL,
	CHANGE `score_horde` `score_horde` INT(11) UNSIGNED NULL,
  DROP PRIMARY KEY,
  ADD PRIMARY KEY (`instance_meta_id`);

ALTER TABLE `main`.`instance_skirmish`
	CHANGE `winner` `winner` TINYINT(1) UNSIGNED NULL;

ALTER TABLE `main`.`instance_rated_arena`
	CHANGE `winner` `winner` TINYINT(1) UNSIGNED NULL,
	CHANGE `team_change1` `team_change1` INT(11) NULL,
	CHANGE `team_change2` `team_change2` INT(11) NULL;
