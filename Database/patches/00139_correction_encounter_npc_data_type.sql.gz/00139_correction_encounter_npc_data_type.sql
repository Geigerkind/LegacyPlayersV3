ALTER TABLE `main`.`data_encounter_npcs`
	CHANGE `requires_death` `requires_death` BOOL DEFAULT 1 NOT NULL,
	CHANGE `can_start_encounter` `can_start_encounter` BOOL DEFAULT 1 NOT NULL,
	CHANGE `is_pivot` `is_pivot` BOOL DEFAULT 0 NOT NULL COMMENT 'There may only be one per encounter';
