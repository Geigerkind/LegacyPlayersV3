CREATE TABLE `main`.`instance_participants` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `instance_meta_id` INT(11) UNSIGNED NOT NULL,
  `character_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`, `instance_meta_id`) ,
  CONSTRAINT `ip_instance_meta_id` FOREIGN KEY (`instance_meta_id`) REFERENCES `main`.`instance_meta`(`id`) ON UPDATE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`instance_participants`
	DROP COLUMN `id`,
  DROP PRIMARY KEY,
  ADD PRIMARY KEY (`instance_meta_id`);

ALTER TABLE `main`.`instance_participants`
  ADD CONSTRAINT `ip_character_id` FOREIGN KEY (`character_id`) REFERENCES `main`.`armory_character`(`id`) ON UPDATE CASCADE;
