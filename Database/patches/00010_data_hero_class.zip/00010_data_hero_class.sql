INSERT INTO main.data_localization (language_id, content) VALUES
(1, "Druid"),
(1, "Hunter"),
(1, "Mage"),
(1, "Paladin"),
(1, "Priest"),
(1, "Rogue"),
(1, "Shaman"),
(1, "Warlock"),
(1, "Warrior"),
(1, "Death knight"),
(1, "Monk"),
(1, "Demon hunter");

INSERT INTO main.data_race (localization_id) VALUES
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(21),
(22);