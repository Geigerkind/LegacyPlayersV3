ALTER TABLE `main`.`account_member`
  ADD  UNIQUE INDEX `am_unique_name` (`nickname`),
  ADD  UNIQUE INDEX `am_unique_mail` (`mail`);

ALTER TABLE `main`.`armory_character_facial`
  DROP INDEX `value_key`,
  ADD  UNIQUE INDEX `acf_unique` (`skin_color`, `face_style`, `hair_style`, `hair_color`, `facial_hair`),
  ADD  KEY `acf_value_key` (`skin_color`, `face_style`, `hair_style`, `hair_color`, `facial_hair`);

ALTER TABLE `main`.`armory_character_history`
  ADD  KEY `ach_value_key` (`character_id`, `character_info_id`, `character_name`, `guild_id`, `guild_rank`, `title`, `prof_skill_points1`, `prof_skill_points2`, `facial`);

ALTER TABLE `main`.`armory_character_info`
  ADD  UNIQUE INDEX `aci_unique` (`gear_id`, `hero_class_id`, `level`, `gender`, `profession1`, `profession2`, `talent_specialization`, `race_id`),
  ADD  KEY `aci_value_key` (`gear_id`, `hero_class_id`, `level`, `gender`, `profession1`, `profession2`, `talent_specialization`, `race_id`);

ALTER TABLE `main`.`armory_gear`
  ADD  UNIQUE INDEX `ag_unique` (`head`, `neck`, `shoulder`, `back`, `chest`, `shirt`, `tabard`, `wrist`, `main_hand`, `off_hand`, `ternary_hand`, `glove`, `belt`, `leg`, `boot`, `ring1`, `ring2`, `trinket1`, `trinket2`),
  ADD  KEY `ag_value_key` (`head`, `neck`, `shoulder`, `back`, `chest`, `shirt`, `tabard`, `wrist`, `main_hand`, `off_hand`, `ternary_hand`, `glove`, `belt`, `leg`, `boot`, `ring1`, `ring2`, `trinket1`, `trinket2`);

ALTER TABLE `main`.`armory_guild`
  ADD  KEY `ag_value_key` (`server_uid`, `server_id`, `guild_name`);

ALTER TABLE `main`.`armory_item`
  ADD  UNIQUE INDEX `ai_unique` (`item_id`, `random_property_id`, `enchant_id`, `gem_id1`, `gem_id2`, `gem_id3`, `gem_id4`),
  ADD  KEY `ai_value_key` (`item_id`, `random_property_id`, `enchant_id`, `gem_id1`, `gem_id2`, `gem_id3`, `gem_id4`);
