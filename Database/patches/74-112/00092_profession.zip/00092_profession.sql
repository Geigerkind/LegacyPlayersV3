INSERT INTO main.data_profession (id, localization_id) VALUES
(393, 30);
