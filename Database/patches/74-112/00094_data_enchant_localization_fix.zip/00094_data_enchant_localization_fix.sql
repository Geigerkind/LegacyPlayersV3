INSERT INTO main.data_localization (language_id, content) VALUES
(1, "+$i Block Rating"),
(1, "+$i Attack Power"),
(1, "+$i Spell Power"),
(1, "+$i Critical Strike Rating"),
(1, "+$i Shadow Resistance"),
(1, "+$i Nature Resistance"),
(1, "+$i Frost Resistance"),
(1, "+$i Fire Resistance"),
(1, "+$i Arcane Resistance"),
(1, "+$i Mana Per 5 sec."),
(1, "+$i Dodge Rating"),
(1, "+$i Health per 5 sec."),
(1, "+$i Defense Rating"),
(1, "+$i Healing"),
(1, "+$i Shadow Damage"),
(1, "+$i Frost Damage"),
(1, "+$i Nature Damage"),
(1, "+$i Fire Damage"),
(1, "+$i Arcane Damage"),
(1, "+$i Spirit"),
(1, "+$i Strength"),
(1, "+$i Intellect"),
(1, "+$i Stamina"),
(1, "+$i Agility"),
(1, "+$i Armor (+$n/+$f)"),
(1, "+$i Stamina (+$n/+$f)"),
(1, "+$i Intellect (+$n/+$f)"),
(1, "+$i Haste"),
(1, "+$i Block"),
(1, "+$i Critical Strike"),
(1, "+$i Dodge"),
(1, "+$i Spell Damage");

INSERT INTO main.data_enchant (expansion_id, id, localization_id, stat_type1, stat_value1, stat_type2, stat_value2, stat_type3, stat_value3) VALUES
(1, 2802, 119744, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2803, 119743, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2804, 119742, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2805, 119741, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2806, 119740, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2815, 119751, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2817, 119739, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2818, 119738, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2819, 119737, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2820, 119736, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2821, 119735, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2823, 119750, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2825, 119722, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 2826, 119749, NULL, NULL, NULL, NULL, NULL, NULL),
(1, 3726, 119748, NULL, NULL, NULL, NULL, NULL, NULL);

UPDATE main.data_enchant SET localization_id = 119747 WHERE id = 2798 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119746 WHERE id = 2799 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119745 WHERE id = 2800 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119744 WHERE id = 2802 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119743 WHERE id = 2803 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119742 WHERE id = 2804 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119741 WHERE id = 2805 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119740 WHERE id = 2806 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119739 WHERE id = 2807 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119738 WHERE id = 2808 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119737 WHERE id = 2809 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119736 WHERE id = 2810 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119735 WHERE id = 2811 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119734 WHERE id = 2812 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119733 WHERE id = 2813 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119732 WHERE id = 2814 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119731 WHERE id = 2815 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119730 WHERE id = 2816 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119729 WHERE id = 2817 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119728 WHERE id = 2818 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119727 WHERE id = 2819 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119726 WHERE id = 2820 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119725 WHERE id = 2821 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119724 WHERE id = 2822 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119724 WHERE id = 2823 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119723 WHERE id = 2824 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119722 WHERE id = 2825 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119721 WHERE id = 2826 AND expansion_id IN (2,3);
UPDATE main.data_enchant SET localization_id = 119752 WHERE id = 2824 AND expansion_id = 2;

INSERT INTO main.data_localization (language_id, content) VALUES
(1, "of Dodge"),
(1, "of Sorcery"),
(1, "of Striking");

INSERT INTO main.data_item_random_property (expansion_id, id, localization_id, enchant_id1, enchant_id2, enchant_id3, enchant_id4, enchant_id5, scaling_coefficient1, scaling_coefficient2, scaling_coefficient3, scaling_coefficient4, scaling_coefficient5) VALUES
('1','-18','70478','2802',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-324','70479','2817',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-47','70482','2826','2805',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-29','70486','2815','2802',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-326','70488','2818',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-327','70489','2819',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-19','70493','2804',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-328','70495','2820',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-20','70497','2825',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-329','70502','2821',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-15','70504','2806',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-84','70505','2803',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-17','70506','2805',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-68','70507','2805','2803',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-12','70508','2806','2805',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-69','70509','2803','2804',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-11','70510','2802','2804',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-10','70511','2804','2805',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-78','70512','2802','2803',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-9','70513','2804','2806',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-14','70514','2802','2823',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-81','70515','2803','2806',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-13','70516','2802','2806',NULL,NULL,NULL,'6666','6666',NULL,NULL,NULL),
('1','-330','119713','2803','2804','2806',NULL,NULL,'5259','5259','5259',NULL,NULL),
('1','-325','119753','2815',NULL,NULL,NULL,NULL,'10000',NULL,NULL,NULL,NULL),
('1','-332','119754','2803','2804','3726',NULL,NULL,'5259','5259','5259',NULL,NULL),
('1','-331','119755','2803','2825','3726',NULL,NULL,'5259','5259','5259',NULL,NULL);
