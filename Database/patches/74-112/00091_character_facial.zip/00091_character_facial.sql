CREATE TABLE `main`.`armory_character_facial` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `skin_color` SMALLINT(3) UNSIGNED NOT NULL,
  `face_style` SMALLINT(3) UNSIGNED NOT NULL,
  `hair_style` SMALLINT(3) UNSIGNED NOT NULL,
  `hair_color` SMALLINT(3) UNSIGNED NOT NULL,
  `facial_hair` SMALLINT(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
);

ALTER TABLE `main`.`armory_character_history`
	ADD COLUMN `facial` INT(11) UNSIGNED NULL AFTER `prof_skill_points2`,
  ADD CONSTRAINT `ach_facial` FOREIGN KEY (`facial`) REFERENCES `main`.`armory_character_facial`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;

ALTER TABLE `main`.`armory_character_facial`
  ADD  KEY `value_key` (`skin_color`, `face_style`, `hair_style`, `hair_color`, `facial_hair`);
