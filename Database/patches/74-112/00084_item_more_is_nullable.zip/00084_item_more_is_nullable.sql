ALTER TABLE `main`.`data_item`
	CHANGE `max_durability` `max_durability` SMALLINT(5) UNSIGNED NULL,
	CHANGE `item_level` `item_level` SMALLINT(5) UNSIGNED NULL,
	CHANGE `delay` `delay` SMALLINT(5) UNSIGNED NULL;

UPDATE main.data_item SET max_durability = NULL WHERE max_durability = 0;
UPDATE main.data_item SET item_level = NULL WHERE item_level = 0;
UPDATE main.data_item SET delay = NULL WHERE delay = 0;