ALTER TABLE `main`.`data_profession`
	ADD COLUMN `icon` SMALLINT(5) UNSIGNED NOT NULL AFTER `localization_id`;

UPDATE main.data_profession SET icon = 5257 WHERE id = 171;
UPDATE main.data_profession SET icon = 4470 WHERE id = 164;
UPDATE main.data_profession SET icon = 5258 WHERE id = 165;
UPDATE main.data_profession SET icon = 4475 WHERE id = 182;
UPDATE main.data_profession SET icon = 4476 WHERE id = 186;
UPDATE main.data_profession SET icon = 4477 WHERE id = 197;
UPDATE main.data_profession SET icon = 4472 WHERE id = 202;
UPDATE main.data_profession SET icon = 4473 WHERE id = 333;
UPDATE main.data_profession SET icon = 2667 WHERE id = 393;
UPDATE main.data_profession SET icon = 2353 WHERE id = 755;
UPDATE main.data_profession SET icon = 1353 WHERE id = 773;

ALTER TABLE `main`.`data_profession`
  ADD CONSTRAINT `dp_icon` FOREIGN KEY (`icon`) REFERENCES `main`.`data_icon`(`id`) ON UPDATE CASCADE;
