USE main;

DELETE c FROM main.data_item_effect c
JOIN (SELECT a.expansion_id, a.id, b.spell_id FROM main.data_item a
JOIN main.data_itemset_effect b ON a.itemset = b.itemset_id) d ON c.item_id = d.id AND c.expansion_id = d.expansion_id AND c.spell_id = d.spell_id;