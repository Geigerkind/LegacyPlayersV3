CREATE TABLE `main`.`armory_instance_resets` (
  `server_id` INT(11) UNSIGNED NOT NULL,
  `map_id` SMALLINT(5) UNSIGNED NOT NULL,
  `difficulty` TINYINT(3) UNSIGNED NOT NULL,
  `reset_time` BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`server_id`, `map_id`, `difficulty`)
);

ALTER TABLE `main`.`armory_instance_resets`
  ADD CONSTRAINT `FK_air_server_id` FOREIGN KEY (`server_id`) REFERENCES `main`.`data_server`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;
