ALTER TABLE `main`.`instance_attempt`
	ADD COLUMN `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT FIRST,
  DROP PRIMARY KEY,
  ADD PRIMARY KEY (`id`),
  DROP FOREIGN KEY `ia2_instance_meta_id`;

ALTER TABLE `main`.`instance_attempt`
  ADD CONSTRAINT `ia2_instance_meta_id` FOREIGN KEY (`instance_meta_id`) REFERENCES `main`.`instance_meta`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;

CREATE TABLE `main`.`instance_ranking_damage` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `character_id` INT(11) UNSIGNED NOT NULL,
  `npc_id` INT(11) UNSIGNED NOT NULL,
  `attempt_id` INT(11) UNSIGNED NOT NULL,
  `damage` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) ,
  CONSTRAINT `ird_character_id` FOREIGN KEY (`character_id`) REFERENCES `main`.`armory_character`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `ird_npc_id` FOREIGN KEY (`npc_id`) REFERENCES `main`.`data_npc`(`id`) ON UPDATE CASCADE,
  CONSTRAINT `ird_attempt_id` FOREIGN KEY (`attempt_id`) REFERENCES `main`.`instance_attempt`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `main`.`instance_ranking_heal` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `character_id` INT(11) UNSIGNED NOT NULL,
  `npc_id` INT(11) UNSIGNED NOT NULL,
  `attempt_id` INT(11) UNSIGNED NOT NULL,
  `heal` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) ,
  CONSTRAINT `irh_character_id` FOREIGN KEY (`character_id`) REFERENCES `main`.`armory_character`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `irh_npc_id` FOREIGN KEY (`npc_id`) REFERENCES `main`.`data_npc`(`id`) ON UPDATE CASCADE,
  CONSTRAINT `irh_attempt_id` FOREIGN KEY (`attempt_id`) REFERENCES `main`.`instance_attempt`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `main`.`instance_ranking_threat` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `character_id` INT(11) UNSIGNED NOT NULL,
  `npc_id` INT(11) UNSIGNED NOT NULL,
  `attempt_id` INT(11) UNSIGNED NOT NULL,
  `threat` INT(11) NOT NULL,
  PRIMARY KEY (`id`) ,
  CONSTRAINT `irt_character_id` FOREIGN KEY (`character_id`) REFERENCES `main`.`armory_character`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `irt_npc_id` FOREIGN KEY (`npc_id`) REFERENCES `main`.`data_npc`(`id`) ON UPDATE CASCADE,
  CONSTRAINT `irt_attempt_id` FOREIGN KEY (`attempt_id`) REFERENCES `main`.`instance_attempt`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;
