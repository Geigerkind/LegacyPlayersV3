CREATE TABLE `main`.`instance_attempt` (
  `instance_meta_id` INT(11) UNSIGNED NOT NULL,
  `creature_id` BIGINT(20) UNSIGNED NOT NULL,
  `start_ts` BIGINT(20) UNSIGNED NOT NULL,
  `end_ts` BIGINT(20) UNSIGNED NOT NULL,
  `is_kill` BOOL NOT NULL,
  PRIMARY KEY (`instance_meta_id`) ,
  CONSTRAINT `ia2_instance_meta_id` FOREIGN KEY (`instance_meta_id`) REFERENCES `main`.`instance_meta`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;
