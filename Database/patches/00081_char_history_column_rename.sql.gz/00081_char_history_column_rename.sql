ALTER TABLE `main`.`armory_character_info`
    DROP FOREIGN KEY `aci_hero_class`;

ALTER TABLE `main`.`armory_character_info`
    DROP FOREIGN KEY `aci_race`;

ALTER TABLE `main`.`armory_character_info`
	CHANGE `hero_class` `hero_class_id` TINYINT(3) UNSIGNED NOT NULL,
	CHANGE `race` `race_id` TINYINT(3) UNSIGNED NOT NULL;

ALTER TABLE `main`.`armory_character_info`
    ADD CONSTRAINT `aci_hero_class` FOREIGN KEY (`hero_class_id`) REFERENCES `main`.`data_hero_class` (`id`) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE `main`.`armory_character_info`
    ADD CONSTRAINT `aci_race` FOREIGN KEY (`race_id`) REFERENCES `main`.`data_race` (`id`) ON UPDATE CASCADE ON DELETE CASCADE;