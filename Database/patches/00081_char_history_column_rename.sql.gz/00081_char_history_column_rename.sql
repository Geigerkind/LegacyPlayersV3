ALTER TABLE `main`.`armory_character_info`
	CHANGE `hero_class` `hero_class_id` TINYINT(3) UNSIGNED NOT NULL,
	CHANGE `race` `race_id` TINYINT(3) UNSIGNED NOT NULL;
