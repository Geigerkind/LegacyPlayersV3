INSERT INTO `main`.`data_encounter` (`id`, `localization_id`, `map_id`, `retail_id`) VALUES
(163, 44817, 531, 712),
(164, 50832, 531, 713),
(165, 48334, 531, 714);

INSERT INTO `main`.`data_encounter_npcs` (`encounter_id`, `npc_id`, `requires_death`, `can_start_encounter`, `is_pivot`, `health_treshold`) VALUES
(163, 15510, 1, 1, 1, NULL),
(163, 16630, 0, 0, 0, NULL),
(163, 15962, 0, 0, 0, NULL),
(164, 15299, 1, 1, 1, NULL),
(164, 15667, 0, 0, 0, NULL),
(165, 15509, 1, 1, 1, NULL);

