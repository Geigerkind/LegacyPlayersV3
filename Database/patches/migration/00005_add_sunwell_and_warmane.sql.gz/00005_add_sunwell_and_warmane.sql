INSERT INTO `main`.`data_server` (`id`, `expansion_id`, `server_name`, `owner`, `patch`) VALUES
(9, 3, "Frosthold", NULL, "3.3.5"),
(10, 3, "Angrathar", NULL, "3.3.5"),
(11, 2, "Nightbane", NULL, "2.4.3"),
(12, 3, "Frostmourne", NULL, "3.3.5"),
(13, 3, "Lordaeron", NULL, "3.3.5"),
(14, 3, "Icecrown", NULL, "3.3.5"),
(15, 3, "Blackrock", NULL, "3.3.5");