UPDATE `main`.`data_server` SET `owner` = NULL WHERE `id` = 4;
INSERT IGNORE INTO `main`.`data_server` (`id`, `expansion_id`, `server_name`, `owner`) VALUES
(5, 2, "Karazhan", 1);

ALTER TABLE `main`.`armory_character`
	ADD COLUMN `old_id` INT(11) UNSIGNED NULL AFTER `server_uid`;

INSERT INTO `main`.`armory_character` (`old_id`, `server_id`, `server_uid`)
SELECT C.id, (5), C.server_uid FROM `main`.`armory_character_history`  A
JOIN `main`.`armory_character` C ON A.character_id = C.id
WHERE `timestamp` >= 1595690200 AND C.server_id = 4
GROUP BY C.id, C.server_id, C.server_uid;

ALTER TABLE `main`.`armory_guild`
	ADD COLUMN `old_id` INT(11) UNSIGNED NULL AFTER `guild_name`;

INSERT INTO `main`.`armory_guild` (`old_id`, `server_uid`, `server_id`, `guild_name`)
SELECT C.id, C.server_uid, (5), C.guild_name FROM `main`.`armory_character_history`  A
JOIN `armory_guild` C ON A.guild_id= C.id
WHERE `timestamp` >= 1595690200 AND C.server_id = 4
GROUP BY C.id, C.server_id, C.server_uid, C.guild_name;

UPDATE `main`.`armory_character_history` A
    JOIN `main`.`armory_character` B
        ON A.`character_id` = B.`old_id`
SET A.`character_id` = B.`id`;

UPDATE `main`.`armory_character_history` A
    JOIN `main`.`armory_guild` B
        ON A.`guild_id` = B.`old_id`
SET A.`guild_id` = B.`id`;

ALTER TABLE `main`.`armory_character`
	DROP COLUMN `old_id`;

ALTER TABLE `main`.`armory_guild`
	DROP COLUMN `old_id`;
