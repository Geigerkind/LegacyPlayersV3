INSERT INTO `main`.`data_server` (`id`, `expansion_id`, `server_name`, `owner`, `patch`) VALUES
(6, 3, "Crystalsong", NULL, "3.3.5");