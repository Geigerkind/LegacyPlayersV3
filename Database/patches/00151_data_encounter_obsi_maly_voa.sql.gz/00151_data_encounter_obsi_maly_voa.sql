UPDATE `main`.`data_npc` SET `map_id` = NULL WHERE id IN (1420, 2914, 4075, 14881, 1412);
UPDATE `main`.`data_npc` SET `map_id` = 615 WHERE id = 30643;

INSERT INTO `main`.`data_encounter` (`id`, `localization_id`, `map_id`) VALUES
-- Obsidian Sanctum
(108, 65691, 615), -- 28860
-- Eye of Eternity
(109, 62619, 616), -- 28859
-- Vault of Archavon
(110, 54299, 624), -- 31125
(111, 58211, 624), -- 33993
(112, 61788, 624), -- 35013
(113, 68374, 624); -- 38433

INSERT INTO `main`.`data_encounter_npcs` (`encounter_id`, `npc_id`, `requires_death`, `can_start_encounter`, `is_pivot`, `health_treshold`) VALUES
(108, 28860, 1, 1, 1, NULL), -- Sartharion
(108, 30452, 0, 0, 0, NULL), -- Tenebron
(108, 30451, 0, 0, 0, NULL), -- Shadron
(108, 31214, 0, 0, 0, NULL), -- Sartharion Twilight Whelp
(108, 30643, 0, 0, 0, NULL), -- Lava Blaze
(109, 28859, 1, 1, 1, NULL), -- Malygos
(109, 30084, 0, 0, 0, NULL), -- Power Spark
(109, 30245, 0, 0, 0, NULL), -- Nexus Lord
(109, 30249, 0, 0, 0, NULL), -- Scion of Eternity
(110, 31125, 1, 1, 1, NULL), -- Archavon the Stonewatcher
(111, 33993, 1, 1, 1, NULL), -- Emalon the Stormwatcher
(111, 33998, 0, 0, 0, NULL), -- Tempest Minion
(112, 35013, 1, 1, 1, NULL), -- Koralon the Flame Watcher
(113, 38433, 1, 1, 1, NULL), -- Toravon the Ice Watcher
(111, 38456, 0, 0, 0, NULL); -- Frozen Orb
