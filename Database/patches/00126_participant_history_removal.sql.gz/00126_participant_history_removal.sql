ALTER TABLE `main`.`instance_participants`
    DROP COLUMN `history_id`,
DROP INDEX `ip_history_id`,
DROP FOREIGN KEY `ip_history_id`;