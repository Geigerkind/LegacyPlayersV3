CREATE TABLE `main`.`data_language` (
  `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `language` VARCHAR(256) NOT NULL,
  `short_code` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`id`)
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `main`.`data_localization` (
  `language_id` TINYINT(3) UNSIGNED NOT NULL,
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `content` VARCHAR(256) NOT NULL,
  PRIMARY KEY (`id`, `language_id`),
  CONSTRAINT `language_id` FOREIGN KEY (`language_id`) REFERENCES `main`.`data_language`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `main`.`data_race` (
  `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `dr_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE `main`.`data_profession` (
  `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `dp_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE `main`.`data_expansion` (
  `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `de_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_profession`(`localization_id`) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE `main`.`data_item` (
  `expansion_id` TINYINT(3) UNSIGNED NOT NULL,
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`, `expansion_id`),
  CONSTRAINT `di_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE NO ACTION ON DELETE NO ACTION
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `main`.`data_enchant` (
  `expansion_id` TINYINT(3) UNSIGNED NOT NULL,
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
   KEY(`id`),
  PRIMARY KEY (`expansion_id`, `id`),
  CONSTRAINT `dets_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE NO ACTION ON DELETE NO ACTION
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `main`.`data_gem` (
  `expansion_id` TINYINT(3) UNSIGNED NOT NULL,
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
   KEY(`id`),
  PRIMARY KEY (`expansion_id`, `id`),
  CONSTRAINT `dg_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE NO ACTION ON DELETE NO ACTION
) CHARSET=utf8 COLLATE=utf8_unicode_ci;
