UPDATE `main`.`data_encounter_npcs` SET `requires_death` = 1 WHERE encounter_id = 75;
UPDATE `main`.`data_encounter_npcs` SET `requires_death` = 0 WHERE encounter_id = 75 AND `npc_id` = 18545;