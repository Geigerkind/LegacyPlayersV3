ALTER TABLE `main`.`armory_character_info`
	CHANGE `talent_specialization` `talent_specialization` VARCHAR(160) CHARSET utf8 COLLATE utf8_unicode_ci NULL;
