DELETE FROM main.armory_character;
DELETE FROM main.armory_character_info;

ALTER TABLE `main`.`armory_character_info`
  DROP FOREIGN KEY `aci_prof1`,
  DROP FOREIGN KEY `aci_prof2`;

ALTER TABLE `main`.`armory_character_info`
	CHANGE `profession1` `profession1` SMALLINT(5) UNSIGNED NULL,
	CHANGE `profession2` `profession2` SMALLINT(5) UNSIGNED NULL;

ALTER TABLE `main`.`data_profession`
	CHANGE `id` `id` SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `main`.`armory_character_info`
  ADD CONSTRAINT `aci_prof1` FOREIGN KEY (`profession1`) REFERENCES `main`.`data_profession`(`id`) ON UPDATE CASCADE ON DELETE SET NULL,
  ADD CONSTRAINT `aci_prof2` FOREIGN KEY (`profession2`) REFERENCES `main`.`data_profession`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;

UPDATE main.data_profession SET id = 182 WHERE id = 1;
UPDATE main.data_profession SET id = 186 WHERE id = 2;
UPDATE main.data_profession SET id = 171 WHERE id = 3;
UPDATE main.data_profession SET id = 164 WHERE id = 4;
UPDATE main.data_profession SET id = 333 WHERE id = 5;
UPDATE main.data_profession SET id = 202 WHERE id = 6;
UPDATE main.data_profession SET id = 773 WHERE id = 7;
UPDATE main.data_profession SET id = 755 WHERE id = 8;
UPDATE main.data_profession SET id = 165 WHERE id = 9;
UPDATE main.data_profession SET id = 197 WHERE id = 10;