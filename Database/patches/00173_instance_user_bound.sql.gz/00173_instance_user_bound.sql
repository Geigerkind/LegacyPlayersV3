ALTER TABLE `main`.`instance_meta`
	ADD COLUMN `uploaded_user` INT(11) UNSIGNED DEFAULT 21 NOT NULL AFTER `last_event_id`;
