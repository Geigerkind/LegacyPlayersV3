INSERT INTO `main`.`data_encounter_npcs` (`encounter_id`, `npc_id`, `requires_death`, `can_start_encounter`, `is_pivot`, `health_treshold`) VALUES
(128, 34800, 0, 0, 0, NULL);

DELETE FROM `main`.`data_encounter_npcs` WHERE npc_id = 35470;
DELETE FROM `main`.`data_encounter_npcs` WHERE npc_id = 35469;