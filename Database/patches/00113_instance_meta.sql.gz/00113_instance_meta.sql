CREATE TABLE `main`.`instance_meta` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `start_ts` BIGINT(20) UNSIGNED NOT NULL,
  `end_ts` BIGINT(20) UNSIGNED NOT NULL,
  `expired` BINARY(1) NOT NULL DEFAULT '0',
  `instance_id` INT(11) UNSIGNED NOT NULL,
  `map_id` SMALLINT(6) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`instance_meta`
	ADD COLUMN `server_id` INT(11) UNSIGNED NOT NULL AFTER `id`,
  ADD CONSTRAINT `im_server_id` FOREIGN KEY (`server_id`) REFERENCES `main`.`data_server`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;
