ALTER TABLE `main`.`instance_loot`
    ADD COLUMN `amount` INT(11) UNSIGNED NOT NULL AFTER `looted_ts`;