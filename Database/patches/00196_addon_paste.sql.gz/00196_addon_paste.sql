CREATE TABLE `main`.`utility_addon_paste` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(256) NOT NULL,
  `expansion_id` TINYINT(3) UNSIGNED NOT NULL,
  `addon_name` VARCHAR(256) NOT NULL,
  `tags` VARCHAR(1024) NOT NULL COMMENT 'Comma separated ids',
  `description` TEXT(8192) NOT NULL,
  `content` TEXT(65532) NOT NULL,
  PRIMARY KEY (`id`) ,
  CONSTRAINT `uap_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;
