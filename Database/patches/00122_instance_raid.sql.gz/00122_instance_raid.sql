CREATE TABLE `main`.`instance_raid` (
  `instance_meta_id` INT(11) UNSIGNED NOT NULL,
  `map_difficulty` TINYINT(1) UNSIGNED NOT NULL,
  PRIMARY KEY (`instance_meta_id`) ,
  CONSTRAINT `ir_instance_meta_id` FOREIGN KEY (`instance_meta_id`) REFERENCES `main`.`instance_meta`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`instance_meta`
	DROP COLUMN `map_difficulty`,
  DROP INDEX `im_lookup`,
  ADD  KEY `im_lookup` (`server_id`, `expired`, `instance_id`, `map_id`);
