ALTER TABLE `main`.`data_item`
	CHANGE `required_level` `required_level` TINYINT(3) UNSIGNED NULL;

UPDATE main.data_item SET required_level = NULL WHERE required_level = 0;