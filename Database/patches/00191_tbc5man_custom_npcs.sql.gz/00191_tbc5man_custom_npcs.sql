INSERT INTO `main`.`data_localization` (`language_id`, `id`, `content`) VALUES
(1, 119839, "Ravaged Scarab"),
(1, 119840, "Red Shield Scarab"),
(1, 119841, "Yellow Shield Scarab"),
(1, 119842, "Invasive Scarab");

INSERT INTO `main`.`data_npc` (`expansion_id`, `id`, `localization_id`, `is_boss`, `friend`, `family`, `map_id`) VALUES
(2, 39630, 44817, 1, 0, 0, 531),
(2, 39631, 44334, 1, 0, 0, 531);

UPDATE `main`.`data_npc` SET `map_id` = 531, `localization_id` = 119839 WHERE `expansion_id` = 2 AND `id` = 25811;
UPDATE `main`.`data_npc` SET `map_id` = 531, `localization_id` = 119840 WHERE `expansion_id` = 2 AND `id` = 25813;
UPDATE `main`.`data_npc` SET `map_id` = 531, `localization_id` = 119841 WHERE `expansion_id` = 2 AND `id` = 25812;
UPDATE `main`.`data_npc` SET `map_id` = 531, `localization_id` = 119842 WHERE `expansion_id` = 2 AND `id` = 24869;