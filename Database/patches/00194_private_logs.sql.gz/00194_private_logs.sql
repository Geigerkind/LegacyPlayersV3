ALTER TABLE `main`.`instance_meta`
	ADD COLUMN `privacy_type` TINYINT(1) UNSIGNED DEFAULT 0 NOT NULL AFTER `upload_id`;

ALTER TABLE `main`.`instance_meta`
	ADD COLUMN `privacy_ref` INT(11) NULL AFTER `privacy_type`;

CREATE TABLE `main`.`account_privacy_groups` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_name` VARCHAR(64) NOT NULL,
  `member_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) ,
  CONSTRAINT `fk_apg_member_id` FOREIGN KEY (`member_id`) REFERENCES `main`.`account_member`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `main`.`account_privacy_group_member` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_id` INT(11) UNSIGNED NOT NULL,
  `member_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) ,
  CONSTRAINT `fk_apgm_group_id` FOREIGN KEY (`group_id`) REFERENCES `main`.`account_privacy_groups`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_apgm_member_id` FOREIGN KEY (`member_id`) REFERENCES `main`.`account_member`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
);

RENAME TABLE `main`.`account_privacy_groups` TO `main`.`account_privacy_group`;

UPDATE `main`.`instance_meta` SET privacy_ref = 0;

ALTER TABLE `main`.`instance_meta`
	CHANGE `privacy_ref` `privacy_ref` INT(11) UNSIGNED DEFAULT 0 NOT NULL;

ALTER TABLE `main`.`account_member`
	ADD COLUMN `default_privacy_type` TINYINT(1) UNSIGNED DEFAULT 0 NOT NULL AFTER `access_rights`;
