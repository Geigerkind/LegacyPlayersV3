ALTER TABLE `main`.`data_server`
	ADD COLUMN `owner` INT(11) UNSIGNED NULL AFTER `server_name`,
  ADD CONSTRAINT `ds_owner` FOREIGN KEY (`owner`) REFERENCES `main`.`account_member`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_server` DROP FOREIGN KEY `ds_expansion_id`;

ALTER TABLE `main`.`data_server` ADD CONSTRAINT `ds_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_server` DROP FOREIGN KEY `ds_owner`;

ALTER TABLE `main`.`data_server` ADD CONSTRAINT `ds_owner` FOREIGN KEY (`owner`) REFERENCES `main`.`account_member`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;
