ALTER TABLE `main`.`armory_character_info`
    DROP FOREIGN KEY `aci_prof2`;

ALTER TABLE `main`.`armory_character_info`
	CHANGE `prefession2` `profession2` TINYINT(3) UNSIGNED NULL;

ALTER TABLE `main`.`armory_character_info`
    ADD CONSTRAINT `aci_prof2` FOREIGN KEY (`profession2`) REFERENCES `main`.`data_profession` (`id`) ON UPDATE CASCADE ON DELETE SET NULL;