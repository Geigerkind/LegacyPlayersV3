ALTER TABLE `main`.`armory_character_info`
	CHANGE `prefession2` `profession2` TINYINT(3) UNSIGNED NULL;
