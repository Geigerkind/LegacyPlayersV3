INSERT INTO main.data_server (expansion_id, server_name) VALUES
(1, "Shino's Test Vanilla server"),
(2, "Shino's Test TBC server"),
(3, "Shino's Test WOTLK server");