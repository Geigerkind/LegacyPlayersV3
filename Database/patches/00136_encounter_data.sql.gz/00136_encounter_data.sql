ALTER TABLE `main`.`data_encounter_npcs`
	ADD COLUMN `can_start_encounter` BIT(1) DEFAULT 1 NOT NULL AFTER `requires_death`;

ALTER TABLE `main`.`data_encounter_npcs`
  DROP FOREIGN KEY `denc_npc_npc_id`;

UPDATE `main`.`data_npc` SET is_boss=1 WHERE id IN (16179, 16181, 16180, 17543, 17547, 25840);

INSERT INTO `main`.`data_localization` (`id`, `language_id`, `content`) VALUES
(119815, 1, "Servant's Quarter");

INSERT INTO `main`.`data_encounter` (`id`, `localization_id`, `map_id`) VALUES
-- Molten Core
(1, 47079, 409),
(2, 47150, 409),
(3, 45228, 409),
(4, 45208, 409),
(5, 42885, 409),
(6, 49399, 409),
(7, 49990, 409),
(8, 45405, 409),
(9, 47186, 409),
(10, 48495, 409),
-- Onyxia's Lair
(11, 48074, 249),
-- Zul'Gurub
(12, 45943, 309),
(13, 45940, 309),
(14, 45947, 309),
(15, 43126, 309),
(16, 44562, 309),
(17, 45938, 309),
(18, 45169, 309),
(19, 45941, 309),
(20, 46415, 309),
(21, 45743, 309),
-- Black Wing Lair
(22, 48585, 469),
(23, 50645, 469),
(24, 43311, 469),
(25, 44962, 469),
(26, 44556, 469),
(27, 44983, 469),
(28, 43647, 469),
(29, 47897, 469),
-- Ruins of Ahn'Qiraj
(30, 46752, 509),
(31, 45250, 509),
(32, 47539, 509),
(33, 43383, 509),
(34, 42823, 509),
(35, 48122, 509),
-- Temple of Ahn'Qiraj
(36, 50228, 531),
(37, 50213, 531),
(38, 42911, 531),
(39, 44817, 531),
(40, 50236, 531),
(41, 48126, 531),
(42, 43388, 531),
-- Naxxramas
(43, 48197, 533),
(44, 45624, 533),
(45, 45352, 533),
(46, 50187, 533),
(47, 47981, 533),
(48, 45882, 533),
(49, 46975, 533),
(50, 42594, 533),
(51, 45480, 533),
(52, 47123, 533),
(53, 46221, 533),
(54, 45464, 533),
(55, 50221, 533),
(56, 48973, 533),
(57, 46559, 533),
-- Karazhan
(58, 51501, 532),
(59, 52085, 532),
(60, 52056, 532),
(61, 119815, 532),
(62, 52137, 532),
(63, 52467, 532),
(64, 52235, 532),
(65, 52453, 532),
(66, 52118, 532),
(67, 52164, 532),
(68, 52131, 532),
-- Gruul's Lair
(69, 51923, 565),
(70, 51898, 565),
-- Magtheridon's Lair
(71, 52054, 544),
-- Tempest Keep
(72, 51403, 550),
(73, 52540, 550),
(74, 51921, 550),
(75, 51991, 550),
-- Serpantshrine Cavern
(76, 51943, 548),
(77, 52469, 548),
(78, 52024, 548),
(79, 51793, 548),
(80, 52086, 548),
(81, 52014, 548),
-- Zul'Aman
(82, 52100, 568),
(83, 51401, 568),
(84, 51988, 568),
(85, 51905, 568),
(86, 51920, 568),
(87, 52596, 568),
-- Mount Hyjal
(88, 52173, 534),
(89, 51452, 534),
(90, 51999, 534),
(91, 51510, 534),
(92, 51474, 534),
-- Black Temple
(93, 51925, 564),
(94, 52428, 564),
(95, 52233, 564),
(96, 52457, 564),
(97, 51902, 564),
(98, 52188, 564),
(99, 52087, 564),
(100, 52468, 564),
(101, 51945, 564),
-- Sunwell Plateau
(102, 51992, 580),
(103, 51584, 580),
(104, 51819, 580),
(105, 51764, 580),
(106, 52038, 580),
(107, 52004, 580);

INSERT INTO `main`.`data_encounter_npcs` (`encounter_id`, `npc_id`, `requires_death`, `can_start_encounter`) VALUES
(1, 12118, 1, 1), -- Lucifron
(1, 12119, 0, 0), -- Flamewaker Protector
(2, 11982, 1, 1), -- Magmadar
(3, 12259, 1, 1), -- Gehennas
(3, 11664, 0, 0), -- Flamewaker Elite
(4, 12057, 1, 1), -- Garr
(4, 12099, 0, 0), -- Firesworn
(5, 12056, 1, 1), -- Baron Geddon
(6, 12264, 1, 1), -- Shazzrah
(7, 12098, 1, 1), -- Sulfuron Harbinger
(7, 11662, 0, 1), -- Flamewaker Priest
(8, 11988, 1, 1), -- Golemagg the Incinerator
(8, 11672, 0, 0), -- Core Rager
(9, 12018, 0, 1), -- Majordomo Executus
(9, 11663, 1, 0), -- Flamewaker Healer
(9, 11664, 1, 0), -- Flamewaker Elite
(10, 11502, 1, 1), -- Ragnaros
(10, 12143, 0, 0), -- Son of Flame
(11, 10184, 1, 1), -- Onyxia
(11, 12129, 0, 0), -- Onyxia Warder
(11, 11262, 0, 0), -- Onyxia Whelp
(12, 14517, 1, 1), -- High Priestess Jeklik
(12, 11368, 0, 0), -- Bloodseeker Bat
(13, 14507, 1, 1), -- High Priest Venoxis
(14, 14510, 1, 1), -- High Priestess Mar'li
(14, 11388, 0, 0), -- Witherbark Speaker
(14, 15041, 0, 0), -- Spawn of Mar'li
(15, 11382, 1, 1), -- Bloodlord Mandokir
(15, 14988, 0, 1), -- Ohgan
(16, 15082, 1, 1), -- Gri'lek
(16, 15083, 1, 1), -- Hazza'rah
(16, 15163, 0, 0), -- Nightmare Illusion
(16, 15084, 1, 1), -- Renataki
(16, 15085, 1, 1), -- Wushoolay
(17, 14509, 1, 1), -- High Priest Thekal
(17, 11347, 0, 0), -- Zealot Lor'Khan
(17, 11348, 0, 0), -- Zealot Zath
(17, 11361, 0, 0), -- Zulian Tiger
(18, 15114, 1, 1), -- Ghaz'Ranka
(19, 14515, 1, 1), -- High Priestess Arlokk
(19, 11365, 0, 0), -- Zulian Panther
(20, 11380, 1, 1), -- Jin'do the Hexxer
(20, 14826, 0, 0), -- Sacrificed Troll
(21, 14834, 1, 1), -- Hakkar
(21, 11357, 0, 0), -- Son of Hakkar
(22, 12435, 1, 1), -- Razorgore the Untamed
(22, 12557, 1, 1), -- Grethok the Controller
(22, 14456, 0, 1), -- Blackwing Guardsman
(22, 12416, 0, 1), -- Blackwing Legionnaire
(22, 12420, 0, 1), -- Blackwing Mage
(22, 12422, 0, 1), -- Death Talon Dragonspawn
(23, 13020, 1, 1), -- Vaelastrasz the Corrupt
(24, 12017, 1, 1), -- Broodlord Lashlayer
(25, 11983, 1, 1), -- Firemaw
(26, 14601, 1, 1), -- Ebonroc
(27, 11981, 1, 1), -- Flamegor
(28, 14020, 1, 1), -- Chromaggus
(29, 11583, 1, 1), -- Nefarian
(29, 14261, 0, 1), -- Blue Drakonid
(29, 14262, 0, 1), -- Green Drakonid
(29, 14263, 0, 1), -- Bronze Drakonid
(29, 14264, 0, 1), -- Red Drakonid
(29, 14265, 0, 1), -- Black Drakonid
(29, 14302, 0, 1), -- Chromatic Drakonid
(30, 15348, 1, 1), -- Kurinnaxx
(31, 15341, 1, 1), -- General Rajaxx
-- Wont be included for now => Simplifies things
-- (31, 15391, 0, 1), -- Captain Queez
-- (31, 15392, 0, 1), -- Captain Tuubid
-- (31, 15389, 0, 1), -- Captain Drenn
-- (31, 15390, 0, 1), -- Captain Xurrem
-- (31, 15386, 0, 1), -- Major Yeggeth
-- (31, 15388, 0, 1), -- Major Pakkon
-- (31, 15385, 0, 1), -- Colonel Zerran
-- (31, 15344, 0, 0), -- Swarmguard Needler
-- (31, 15387, 0, 0), -- Qiraji Warrior
(32, 15340, 1, 1), -- Moam
(32, 15527, 0, 0), -- Mana Fiend
(33, 15370, 1, 1), -- Buru the Gorger
(33, 15514, 0, 0), -- Buru Egg
(33, 15521, 0, 0), -- Hive'Zara Hatchling
(34, 15369, 1, 1), -- Ayamiss the Hunter
(34, 15546, 0, 0), -- Hive'Zara Swarmer
(35, 15339, 1, 1), -- Ossirian the Unscarred
(36, 15263, 1, 1), -- The Prophet Skeram
(37, 15544, 1, 1), -- Vem
(37, 15543, 1, 1), -- Princess Yauj
(37, 15621, 0, 0), -- Yauj Brood
(37, 15511, 1, 1), -- Lord Kri
(38, 15516, 1, 1), -- Battleguard Satura
(38, 15984, 0, 1), -- Sartura's Royal Guard
(39, 15510, 1, 1), -- Fankriss the Unyielding
(39, 15962, 0, 0), -- Vekniss Hatchling
(39, 15630, 0, 0), -- Spawn of Fankriss
(40, 15275, 1, 1), -- Emperor Vek'nilash
(40, 15276, 1, 1), -- Emperor Vek'lor
(40, 15316, 0, 0), -- Qiraji Scarab
(40, 15317, 0, 0), -- Qiraji Scorption
(41, 15517, 1, 1), -- Ouro
(41, 15718, 0, 0), -- Ouro Scarab
(42, 15727, 1, 1), -- C'Thun
(42, 15725, 0, 0), -- Claw Tentacle
(42, 15726, 0, 0), -- Eye Tentacle
(42, 15589, 0, 0), -- Eye of C'Thun
(42, 15802, 0, 0), -- Flesh Tentacle
(42, 15728, 0, 0), -- Giant Claw Tentacle
(42, 15334, 0, 0), -- Giant Eye Tentacle
(43, 16028, 1, 1), -- Patchwerk
(44, 15931, 1, 1), -- Grobbulus
(44, 16290, 0, 0), -- Fallout Slime
(45, 15932, 1, 1), -- Gluth
(45, 16360, 0, 0), -- Zombie Chow
(46, 15928, 1, 1), -- Thaddius
(46, 15930, 1, 1), -- Feugen
(46, 15929, 1, 1), -- Stallag
(47, 15954, 1, 1), -- Noth the Plaguebringer
(47, 16983, 0, 0), -- Plagued Champion
(47, 16981, 0, 0), -- Plagued Guardian
(48, 15936, 1, 1), -- Heigan the Unclean
(48, 16057, 0, 0), -- Rotting Maggot
(48, 16056, 0, 0), -- Diseased Maggot
(48, 16236, 0, 0), -- Eye Stalk
(49, 16011, 1, 1), -- Loatheb
(49, 16286, 0, 0), -- Spore
(50, 15956, 1, 1), -- Anub'Rekhan
(50, 16573, 0, 1), -- Crypt Guard
(50, 16698, 0, 0), -- Corpse Scarab
(51, 15953, 1, 1), -- Grand Widow Faerlina
(51, 16506, 0, 1), -- Naxxramas Worshipper
(51, 16505, 0, 1), -- Naxxramas Follower
(52, 15952, 1, 1), -- Maexxna
(52, 17055, 0, 0), -- Maexxna Spiderling
(52, 16486, 0, 0), -- Web Wrap
(53, 16061, 1, 1), -- Instructor Razuvious
(53, 16803, 0, 0), -- Deathknight Understudy
(54, 16060, 1, 1), -- Gothik the Harvester
(54, 16124, 0, 0), -- Unrelenting Trainee
(54, 16125, 0, 0), -- Unrelenting Death Knight
(54, 16126, 0, 0), -- Unrelenting Rider
(54, 16148, 0, 0), -- Spectral Death Knight
(54, 16150, 0, 0), -- Spectral Rider
(54, 16149, 0, 0), -- Spectral Horse
(54, 16127, 0, 0), -- Spectral Trainee
(55, 16062, 1, 1), -- Highlord Mograine
(55, 16064, 1, 1), -- Thane Korth'azz
(55, 16065, 1, 1), -- Lady Blaumeux
(55, 16063, 1, 1), -- Sir ZelCurrently hiek
(56, 15989, 1, 1), -- Sapphiron
(57, 15990, 1, 1), -- Kel'Thuzad
(57, 16427, 0, 1), -- Soldier of the Frozen Wastes
(57, 16428, 0, 1), -- Unstoppable Abomination
(57, 16429, 0, 1), -- Soul Weaver
(57, 16441, 0, 1), -- Guardian of Icecrown
(58, 15550, 1, 1), -- Attumen the Huntsman
(58, 16161, 1, 0), -- Midnight
(59, 15687, 1, 1), -- Moroes
(59, 19875, 0, 1), -- Baroness Dorthea Millstipe
(59, 19872, 0, 1), -- Lady Catriona Von'Indi
(59, 17007, 0, 1), -- Lady Keira Berrybuck
(59, 19874, 0, 1), -- Baron Rafe Dreuger
(59, 19876, 0, 1), -- Lord Robin Daris
(59, 19873, 0, 1), -- Lord Crispin Ference
(60, 16457, 1, 1), -- Maiden of Virtue
(61, 16179, 1, 1), -- Hyakiss the Lurker
(61, 16180, 1, 1), -- Rokad the Ravager
(61, 16181, 1, 1), -- Shadikith the Glider
(62, 18535, 1, 1), -- Dorothee
(62, 17548, 1, 1), -- Tito
(62, 17546, 1, 1), -- Roar
(62, 17543, 1, 1), -- Strawman
(62, 17547, 1, 1), -- Tinhead
(62, 18168, 1, 1), -- The Crone
(62, 17521, 1, 1), -- The Big Bad Wolf
(62, 17534, 1, 1), -- Julliane
(62, 17533, 1, 1), -- Romulo
(63, 15691, 1, 1), -- The Curator
(63, 17096, 0, 0), -- Astral Flare
(63, 19781, 0, 0), -- Astral Flare (?)
(63, 19782, 0, 0), -- Astral Flare (?)
(63, 19783, 0, 0), -- Astral Flare (?)
(64, 16524, 1, 1), -- Shade of Aran
(64, 21160, 0, 0), -- Conjured Water Elemental
(65, 15688, 1, 1), -- Terestian Illhoof
(65, 17229, 0, 0), -- Kil'rek
(65, 17248, 0, 0), -- Demon Chain
(65, 17257, 0, 0), -- Fiendish Imp
(66, 15689, 1, 1), -- Netherspite
(67, 15690, 1, 1), -- Prince Malchezaar
(67, 17646, 0, 0), -- Netherspite Infernal
(67, 17650, 0, 0), -- Price Malchezaar's Axes
(68, 17225, 1, 1), -- Nightbane
(68, 17261, 0, 0), -- Restless Skeleton
(69, 18831, 1, 1), -- High King Maulgar
(69, 18832, 1, 1), -- Krosh Firehand
(69, 18834, 1, 1), -- Olm the Summoner
(69, 18835, 1, 1), -- Kiggler the Crazed
(69, 18836, 1, 1), -- Blindeye the Seer
(69, 18847, 0, 0), -- Wild Fel Stalker
(70, 19044, 1, 1), -- Gruul the Dragonkiller
(71, 17257, 1, 1), -- Magtheridon
(71, 17256, 0, 1), -- Hellfire Channeler
(71, 17454, 0, 0), -- Burning Abyssal
(72, 19514, 1, 1), -- Al'ar
(72, 19551, 0, 0), -- Ember of Al'ar
(73, 19516, 1, 1), -- Void Reaver
(74, 18805, 1, 1), -- High Astromancer Solarian
(74, 18806, 0, 0), -- Solarium Priest
(74, 18925, 0, 0), -- Solarium Agent
(75, 19622, 1, 1), -- Kael'thas Sunstrider
(75, 20064, 0, 1), -- Thaladred the Darkener
(75, 20060, 0, 1), -- Lord Sanguinar
(75, 20062, 0, 1), -- Grand Astromancer Capernian
(75, 20063, 0, 1), -- Master Engineer Telonicus
(75, 21268, 0, 0), -- Netherstrand Longbow
(75, 21274, 0, 0), -- Staff of Disintegration
(75, 21270, 0, 0), -- Cosmic Infuser
(75, 21271, 0, 0), -- Inifinity Blades
(75, 21272, 0, 0), -- Warp Slicer
(75, 21269, 0, 0), -- Devastation
(75, 21273, 0, 0), -- Phaseshift Bulwark
(75, 18545, 0, 0), -- Ashes of Al'ar
(76, 21216, 1, 1), -- Hydross of Unstable
(76, 22035, 0, 0), -- Pure Spawn
(76, 22036, 0, 0), -- Tainted Spawn of Hydross
(77, 21217, 1, 1), -- The Lurker Below
(77, 21873, 0, 0), -- Coilfang Guardian
(77, 21865, 0, 0), -- Coilfang Ambusher
(78, 21215, 1, 1), -- Leotheras the Blind
(78, 21806, 0, 1), -- Greyheart Spellbinder
(78, 21875, 0, 0), -- Shadow of Leotheras
(79, 21214, 1, 1), -- Fathom-Lord Karathress
(79, 21964, 0, 1), -- Fathom-Guard Caribdis
(79, 21965, 0, 1), -- Fathom-Guard Tidalvess
(79, 21966, 0, 1), -- Fathom-Guard Sharkkis
(80, 21213, 1, 1), -- Morogrim Tidewalker
(80, 21920, 0, 0), -- Tidewalker Lurker
(81, 21212, 1, 1), -- Lady Vashj
(81, 21958, 0, 0), -- Enchanted Elemental
(81, 22009, 0, 0), -- Tainted Elemental
(81, 22055, 0, 0), -- Coilfang Elite
(81, 22056, 0, 0), -- Coilfang Strider
(81, 22140, 0, 0), -- Toxic Spore Bat
(82, 23576, 1, 1), -- Nalorakk
(83, 23574, 1, 1), -- Akil'zon
(83, 24858, 0, 0), -- Soaring Eagle
(84, 23578, 1, 1), -- Jan'alai
(84, 23598, 0, 0), -- Amani Dragonhawk Hatchling
(85, 23577, 1, 1), -- Halazzi
(85, 24143, 0, 0), -- Spirit of the Lynx
(85, 24224, 0, 0), -- Corrupted Lightning Totem
(86, 24239, 1, 1), -- Hex Lord Malacrass
(86, 24241, 0, 1), -- Thrug
(86, 24240, 0, 1), -- Alyson Antille
(86, 24243, 0, 1), -- Lord Raadan
(86, 24242, 0, 1), -- Slither
(86, 24244, 0, 1), -- Gazakroth
(86, 24245, 0, 1), -- Fenstalker
(86, 24246, 0, 1), -- Darkheart
(86, 24247, 0, 1), -- Koragg
(87, 23863, 1, 1), -- Zul'jin
(88, 17767, 1, 1), -- Rage Winterchill
(89, 17808, 1, 1), -- Anetheron
(89, 17818, 0, 0), -- Towering Infernal
(90, 17888, 1, 1), -- Kaz'rogal
(91, 17842, 1, 1), -- Azgalor
(91, 17864, 0, 0), -- Lesser Doomguard
(92, 17968, 1, 1), -- Archimonde
(93, 22887, 1, 1), -- High Warlord Naj'entus
(94, 22898, 1, 1), -- Supremus
(95, 22841, 1, 1), -- Shade of Akama
(95, 23421, 0, 1), -- Ashetongue Channeler
(95, 23215, 0, 0), -- Ashetongue Sorcerer
(95, 23216, 0, 0), -- Ashetongue Defender
(95, 23218, 0, 0), -- Ashetongue Rogue
(95, 23523, 0, 0), -- Ashetongue Elementalist
(95, 23524, 0, 0), -- Ashetongue Spiritbinder
(96, 21797, 1, 1), -- Teron Gorefiend
(96, 23111, 0, 0), -- Shadowy Construct
(97, 22498, 1, 1), -- Gurtogg Bloodboil
(98, 23418, 1, 1), -- Essence of Suffering
(98, 23419, 1, 1), -- Essence of Desire
(98, 23420, 1, 1), -- Essence of Anger
(98, 23469, 0, 0), -- Enslaved Soul
(99, 22947, 1, 1), -- Mother Shahraz
(100, 22951, 1, 1), -- Lady Malande
(100, 22950, 1, 1), -- High Nethermancer Zerevor
(100, 22949, 1, 1), -- Gathios the Shatterer
(100, 22952, 1, 1), -- Veras Darkshadow
(101, 22917, 1, 1), -- Illidan Stormrage
(101, 23498, 0, 0), -- Parasitic Shadowfiend
(101, 22997, 0, 0), -- Flame of Azzinoth
(102, 24844, 1, 1), -- Kalecgos
(102, 24892, 0, 0), -- Sathrovarr the Corruptor
(103, 24882, 1, 1), -- Brutallus
(104, 25039, 1, 1), -- Felmyst
(104, 25268, 0, 0), -- Unyielding Dead
(105, 25165, 1, 1), -- Lady Sacrolash
(105, 25166, 1, 1), -- Grand Warlock Alythess
(106, 25741, 1, 1), -- M'uru
(106, 25798, 0, 0), -- Shadowsword Berserker
(106, 25799, 0, 0), -- Shadowsword Fury Mage
(106, 25772, 0, 0), -- Void Sentinal
(106, 25824, 0, 0), -- Void Spawn
(106, 25840, 1, 0), -- Entropius
(107, 25315, 1, 1), -- Kil'jaeden
(107, 25588, 0, 1), -- Hand of the Deceiver
(107, 25708, 0, 0); -- Sinister Reflection