ALTER TABLE `main`.`armory_character`
	DROP COLUMN `last_update`,
  DROP INDEX `ac_last_update`,
  DROP FOREIGN KEY `ac_last_update`;
