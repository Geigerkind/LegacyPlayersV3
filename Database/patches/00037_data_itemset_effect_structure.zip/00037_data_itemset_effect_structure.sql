CREATE TABLE `main`.`data_itemset_effect` (
  `expansion_id` TINYINT(3) UNSIGNED NOT NULL,
  `id` INT(11) UNSIGNED NOT NULL,
  `itemset_id` SMALLINT(5) UNSIGNED NOT NULL,
  `threshold` TINYINT(3) UNSIGNED NOT NULL,
  `spell_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`expansion_id`),
  CONSTRAINT `die_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `die_spell_id` FOREIGN KEY (`expansion_id`, `spell_id`) REFERENCES `main`.`data_spell`(`expansion_id`, `id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `die_itemset_id` FOREIGN KEY (`expansion_id`, `itemset_id`) REFERENCES `main`.`data_itemset_name`(`expansion_id`, `id`) ON UPDATE CASCADE ON DELETE CASCADE
);
