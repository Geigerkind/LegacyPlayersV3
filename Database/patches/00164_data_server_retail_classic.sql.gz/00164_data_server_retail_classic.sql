ALTER TABLE `main`.`data_server`
	ADD COLUMN `is_retail` BOOL DEFAULT 0 NOT NULL AFTER `patch`;

ALTER TABLE `main`.`data_server`
	CHANGE `is_retail` `retail_id` INT(11) UNSIGNED NULL;

UPDATE `main`.`data_server` SET retail_id = NULL WHERE retail_id = 0;