ALTER TABLE `main`.`instance_participants` DROP FOREIGN KEY `ip_character_id`;
ALTER TABLE `main`.`instance_participants` ADD CONSTRAINT `ip_character_id` FOREIGN KEY (`character_id`) REFERENCES `main`.`armory_character` (`id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `main`.`instance_participants` DROP FOREIGN KEY `ip_instance_meta_id`;
ALTER TABLE `main`.`instance_participants` ADD CONSTRAINT `ip_instance_meta_id` FOREIGN KEY (`instance_meta_id`) REFERENCES `main`.`instance_meta` (`id`) ON UPDATE CASCADE ON DELETE CASCADE;