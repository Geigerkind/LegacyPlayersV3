ALTER TABLE `main`.`armory_character`
  ADD  UNIQUE INDEX `ac_unique` (`server_id`, `server_uid`);
