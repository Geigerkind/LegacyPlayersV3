RENAME TABLE `main`.`member` TO `main`.`account_member`;
RENAME TABLE `main`.`api_token` TO `main`.`account_api_token`;
