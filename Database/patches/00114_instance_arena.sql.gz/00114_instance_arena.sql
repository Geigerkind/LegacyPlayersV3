CREATE TABLE `main`.`instance_arena` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `team_id1` INT(11) UNSIGNED NOT NULL,
  `team_id2` INT(11) UNSIGNED NOT NULL,
  `winner` TINYINT(1) UNSIGNED NOT NULL,
  `team_change1` INT(11) COMMENT 'Null => Not rated',
  `team_change2` INT(11) COMMENT 'Null => Not rated',
  PRIMARY KEY (`id`)
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`instance_arena`
  ADD CONSTRAINT `ia_team_id1` FOREIGN KEY (`team_id1`) REFERENCES `main`.`armory_arena_team`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT,
  ADD CONSTRAINT `ia_team_id2` FOREIGN KEY (`team_id2`) REFERENCES `main`.`armory_arena_team`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`instance_arena`
	CHANGE `team_change1` `team_change1` INT(11) NOT NULL,
	CHANGE `team_change2` `team_change2` INT(11) NOT NULL;

RENAME TABLE `main`.`instance_arena` TO `main`.`instance_rated_arena`;

ALTER TABLE `main`.`instance_rated_arena`
	CHANGE `id` `instance_meta_id` INT(11) UNSIGNED NOT NULL,
  DROP PRIMARY KEY,
  ADD PRIMARY KEY (`instance_meta_id`),
  ADD CONSTRAINT `ia_instance_meta_id` FOREIGN KEY (`instance_meta_id`) REFERENCES `main`.`instance_meta`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;
