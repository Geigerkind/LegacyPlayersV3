CREATE TABLE `main`.`armory_guild_rank` (
  `guild_id` INT(11) UNSIGNED NOT NULL,
  `rank_index` TINYINT(3) UNSIGNED NOT NULL,
  `name` VARCHAR(32) NOT NULL,
  PRIMARY KEY (`guild_id`, `rank_index`),
  CONSTRAINT `agr_guild_id` FOREIGN KEY (`guild_id`) REFERENCES `main`.`armory_guild`(`id`) ON UPDATE CASCADE ON DELETE CASCADE
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO main.armory_guild_rank (`guild_id`, `rank_index`, `name`)
SELECT ach.guild_id, (ROW_NUMBER() OVER (PARTITION BY ach.guild_id ORDER BY ach.guild_id, COUNT(ach.guild_id))-1) AS rank_index, ach.guild_rank
FROM main.armory_character_history ach
WHERE NOT ISNULL(ach.guild_id)
GROUP BY ach.guild_id, ach.guild_rank
ORDER BY ach.guild_id, COUNT(ach.guild_id);

UPDATE main.armory_character_history ach
SET ach.guild_rank = (SELECT rank_index FROM main.armory_guild_rank agr WHERE agr.guild_id = ach.guild_id AND agr.name = ach.guild_rank)
WHERE NOT ISNULL(ach.guild_id);

ALTER TABLE `main`.`armory_character_history`
	CHANGE `guild_rank` `guild_rank` TINYINT(3) UNSIGNED NULL;

ALTER TABLE `main`.`armory_character_history`
  ADD CONSTRAINT `ach_guild_rank` FOREIGN KEY (`guild_id`, `guild_rank`) REFERENCES `main`.`armory_guild_rank`(`guild_id`, `rank_index`) ON UPDATE CASCADE ON DELETE SET NULL;
