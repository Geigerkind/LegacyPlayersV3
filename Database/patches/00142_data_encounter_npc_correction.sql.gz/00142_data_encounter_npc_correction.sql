UPDATE `main`.`data_encounter_npcs` SET `requires_death` = 0, `can_start_encounter` = 1 WHERE encounter_id = 58 AND npc_id = 16161;
UPDATE `main`.`data_encounter_npcs` SET `requires_death` = 0, `can_start_encounter` = 1 WHERE encounter_id = 58 AND npc_id = 15550;
UPDATE `main`.`data_encounter_npcs` SET `npc_id` = 16151 WHERE encounter_id = 58 AND npc_id = 16161;
INSERT INTO `main`.`data_encounter_npcs` (`encounter_id`, `npc_id`, `requires_death`, `can_start_encounter`, `is_pivot`) VALUES
(58, 16152, 1, 0, 1);