ALTER TABLE `main`.`data_spell`
	CHANGE `description_localization_id` `description_localization_id` INT(11) UNSIGNED NOT NULL,
	CHANGE `aura_localization_id` `aura_localization_id` INT(11) UNSIGNED NOT NULL;
