CREATE TABLE `main`.`data_item_inventory_type` (
  `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `diit_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`data_item`
	CHANGE `inventory_type` `inventory_type` TINYINT(3) UNSIGNED NULL;

UPDATE main.data_item SET inventory_type = NULL WHERE inventory_type = 0;

INSERT INTO main.data_localization (language_id, content) VALUES
(1, "Head"),
(1, "Neck"),
(1, "Shoulder"),
(1, "Shirt"),
(1, "Chest"),
(1, "Waist"),
(1, "Legs"),
(1, "Feet"),
(1, "Wrists"),
(1, "Hands"),
(1, "Finger"),
(1, "Trinket"),
(1, "Weapon"),
(1, "Ranged"),
(1, "Back"),
(1, "Two-Hand"),
(1, "Bag"),
(1, "Tabard"),
(1, "Robe"),
(1, "Main-Hand"),
(1, "Ammo"),
(1, "Quiver"),
(1, "Relic");

INSERT INTO main.data_item_inventory_type (localization_id) VALUES
(86762),
(86763),
(86764),
(86765),
(86766),
(86767),
(86768),
(86769),
(86770),
(86771),
(86772),
(86773),
(86774),
(84911),
(86775),
(86776),
(86777),
(86778),
(86779),
(86780),
(86781),
(86759),
(86761),
(86782),
(86224),
(86775),
(86783),
(86784);

ALTER TABLE `main`.`data_item`
  ADD CONSTRAINT `di_inventory_type` FOREIGN KEY (`inventory_type`) REFERENCES `main`.`data_item_inventory_type`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;
