INSERT INTO main.data_server (expansion_id, server_name) VALUES
(1, "Algalon - Dalaran Wow - WOTLK"),
(2, "Era 1 - Dalaran Wow - WOTLK"),
(3, "Test Env");