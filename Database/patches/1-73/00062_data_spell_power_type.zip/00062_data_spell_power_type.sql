CREATE TABLE `main`.`data_spell_power_type` (
  `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  `color` VARCHAR(6) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `dspt_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO main.data_localization (language_id, content) VALUES
(1, "Energy"),
(1, "Combo points"),
(1, "Happiness"),
(1, "Runes"),
(1, "Runic power");

INSERT INTO main.data_spell_power_type (localization_id, color) VALUES
(83563, "b1c415"),
(22615, "b1c415"),
(81327, "ff8040"),
(86867, "b1c415"),
(86868, "fff569"),
(86870, "808080"),
(86871, "00d1ff"),
(11669, "80528c"),
(86869, "85ff85");

UPDATE main.data_spell SET power_type = 9 WHERE power_type = 6;

UPDATE main.data_spell SET power_type = power_type + 1;

ALTER TABLE `main`.`data_spell`
  ADD CONSTRAINT `dsp_power_type` FOREIGN KEY (`power_type`) REFERENCES `main`.`data_spell_power_type`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

