CREATE TABLE `main`.`data_item_bonding` (
  `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `dib_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `main`.`data_item`
	CHANGE `bonding` `bonding` TINYINT(3) UNSIGNED NULL;

UPDATE main.data_item SET bonding = NULL WHERE bonding = 0;
UPDATE main.data_item SET bonding = 4 WHERE bonding = 5;

INSERT INTO main.data_localization (language_id, content) VALUES
(1, "Binds when picked up"),
(1, "Binds when equipped"),
(1, "Binds when used"),
(1, "Quest item");

INSERT INTO main.data_item_bonding (localization_id) VALUES
(86752),
(86753),
(86754),
(86755);

ALTER TABLE `main`.`data_item`
  ADD CONSTRAINT `di_bonding` FOREIGN KEY (`bonding`) REFERENCES `main`.`data_item_bonding`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

