ALTER TABLE `main`.`data_item`
	CHANGE `itemset` `itemset` SMALLINT(5) UNSIGNED NULL;

UPDATE main.data_item SET itemset = NULL WHERE itemset = 0;
ALTER TABLE `main`.`data_item`
  ADD  KEY `di_itemset` (`itemset`);

CREATE TABLE `main`.`data_item_dmg_type` (
  `id` TINYINT(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `didt_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT
) CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO main.data_localization (language_id, content) VALUES
(1, "Holy"),
(1, "Fire"),
(1, "Nature"),
(1, "Arcane");

INSERT INTO main.data_item_dmg_type (localization_id) VALUES
(86857),
(86858),
(86859),
(81413),
(49304),
(86860);

ALTER TABLE `main`.`data_item_dmg`
	CHANGE `dmg_type` `dmg_type` TINYINT(3) UNSIGNED NULL;

UPDATE main.data_item_dmg SET dmg_type = NULL WHERE dmg_type = 0;

ALTER TABLE `main`.`data_item_dmg`
  ADD CONSTRAINT `did_dmg_type` FOREIGN KEY (`dmg_type`) REFERENCES `main`.`data_item_dmg_type`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_enchant` DROP FOREIGN KEY `dets_stat_type1`;

ALTER TABLE `main`.`data_enchant` ADD CONSTRAINT `dets_stat_type1` FOREIGN KEY (`stat_type1`) REFERENCES `main`.`data_stat_type`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_enchant` DROP FOREIGN KEY `dets_stat_type2`;

ALTER TABLE `main`.`data_enchant` ADD CONSTRAINT `dets_stat_type2` FOREIGN KEY (`stat_type2`) REFERENCES `main`.`data_stat_type`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_enchant` DROP FOREIGN KEY `dets_stat_type3`;

ALTER TABLE `main`.`data_enchant` ADD CONSTRAINT `dets_stat_type3` FOREIGN KEY (`stat_type3`) REFERENCES `main`.`data_stat_type`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_gem` DROP FOREIGN KEY `dg_enchant_id`;

ALTER TABLE `main`.`data_gem` ADD CONSTRAINT `dg_enchant_id` FOREIGN KEY (`expansion_id`, `enchant_id`) REFERENCES `main`.`data_enchant`(`expansion_id`, `id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_gem` DROP FOREIGN KEY `dg_expansion_id`;

ALTER TABLE `main`.`data_gem` ADD CONSTRAINT `dg_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE `main`.`data_gem` DROP FOREIGN KEY `dg_item_id`;

ALTER TABLE `main`.`data_gem` ADD CONSTRAINT `dg_item_id` FOREIGN KEY (`expansion_id`, `item_id`) REFERENCES `main`.`data_item`(`expansion_id`, `id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_hero_class`
	ADD COLUMN `color` VARCHAR(6) NOT NULL AFTER `localization_id`;

DELETE FROM main.data_race WHERE localization_id >= 11 AND localization_id <= 22;
ALTER TABLE `main`.`data_race`
AUTO_INCREMENT=11;

INSERT INTO main.data_hero_class (localization_id, color) VALUES
(11, "FF7D0A"),
(12, "ABD473"),
(13, "69CCF0"),
(14, "F58CBA"),
(15, "FFFFFF"),
(16, "FFF569"),
(17, "0070DE"),
(18, "9482C9"),
(19, "C79C6E"),
(20, "C41F3B"),
(21, "00FF96"),
(22, "A330C9");

ALTER TABLE `main`.`armory_item`
  ADD CONSTRAINT `ai_random_property_id` FOREIGN KEY (`random_property_id`) REFERENCES `main`.`data_item_random_property`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;

ALTER TABLE `main`.`armory_item` DROP FOREIGN KEY `ai_enchant_id`;

ALTER TABLE `main`.`armory_item` ADD CONSTRAINT `ai_enchant_id` FOREIGN KEY (`enchant_id`) REFERENCES `main`.`data_enchant`(`id`) ON UPDATE CASCADE ON DELETE SET NULL;

ALTER TABLE `main`.`armory_item` DROP FOREIGN KEY `ai_gem_id1`;

ALTER TABLE `main`.`armory_item` ADD CONSTRAINT `ai_gem_id1` FOREIGN KEY (`gem_id1`) REFERENCES `main`.`data_gem`(`item_id`) ON UPDATE CASCADE ON DELETE SET NULL;

ALTER TABLE `main`.`armory_item` DROP FOREIGN KEY `ai_gem_id2`;

ALTER TABLE `main`.`armory_item` ADD CONSTRAINT `ai_gem_id2` FOREIGN KEY (`gem_id2`) REFERENCES `main`.`data_gem`(`item_id`) ON UPDATE CASCADE ON DELETE SET NULL;

ALTER TABLE `main`.`armory_item` DROP FOREIGN KEY `ai_gem_id3`;

ALTER TABLE `main`.`armory_item` ADD CONSTRAINT `ai_gem_id3` FOREIGN KEY (`gem_id3`) REFERENCES `main`.`data_gem`(`item_id`) ON UPDATE CASCADE ON DELETE SET NULL;

ALTER TABLE `main`.`armory_item` DROP FOREIGN KEY `ai_gem_id4`;

ALTER TABLE `main`.`armory_item` ADD CONSTRAINT `ai_gem_id4` FOREIGN KEY (`gem_id4`) REFERENCES `main`.`data_gem`(`item_id`) ON UPDATE CASCADE ON DELETE SET NULL;

