ALTER TABLE `main`.`data_expansion` DROP FOREIGN KEY `de_localization_id`;
ALTER TABLE `main`.`data_expansion` ADD CONSTRAINT `de_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO main.data_localization (language_id, content) VALUES
(1, "Vanilla"),
(1, "TBC"),
(1, "WOTLK"),
(1, "Cataclysm"),
(1, "MoP");

INSERT INTO main.data_expansion (localization_id) VALUES
(23),
(24),
(25),
(26),
(27);