ALTER TABLE `main`.`data_gem`
	ADD COLUMN `enchant_id` INT(11) UNSIGNED NOT NULL AFTER `id`,
	ADD COLUMN `flag` TINYINT(3) UNSIGNED NOT NULL AFTER `enchant_id`;

ALTER TABLE `main`.`data_gem`
	CHANGE `id` `item_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `main`.`data_gem`
  ADD CONSTRAINT `dg_item_id` FOREIGN KEY (`expansion_id`, `item_id`) REFERENCES `main`.`data_item`(`expansion_id`, `id`) ON UPDATE CASCADE ON DELETE NO ACTION,
  ADD CONSTRAINT `dg_enchant_id` FOREIGN KEY (`expansion_id`, `enchant_id`) REFERENCES `main`.`data_enchant`(`expansion_id`, `id`) ON UPDATE CASCADE ON DELETE NO ACTION;

ALTER TABLE `main`.`data_gem` DROP FOREIGN KEY `dg_expansion_id`;

ALTER TABLE `main`.`data_gem` ADD CONSTRAINT `dg_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE NO ACTION;
