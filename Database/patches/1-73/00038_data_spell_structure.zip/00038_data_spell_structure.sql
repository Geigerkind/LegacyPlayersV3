ALTER TABLE `main`.`data_spell`
	CHANGE `rank` `subtext` TINYINT(3) UNSIGNED NOT NULL;
