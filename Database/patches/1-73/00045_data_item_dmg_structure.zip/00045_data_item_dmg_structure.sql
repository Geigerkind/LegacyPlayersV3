CREATE TABLE `main`.`data_item_dmg` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `expansion_id` TINYINT(3) UNSIGNED NOT NULL,
  `item_id` INT(11) UNSIGNED NOT NULL,
  `dmg_type` TINYINT(3) UNSIGNED NOT NULL,
  `dmg_min` SMALLINT(5) UNSIGNED NOT NULL,
  `dmg_max` SMALLINT(5) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `did_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `did_item_id` FOREIGN KEY (`expansion_id`, `item_id`) REFERENCES `main`.`data_item`(`expansion_id`, `id`) ON UPDATE CASCADE ON DELETE CASCADE
) CHARSET=utf8 COLLATE=utf8_unicode_ci;
