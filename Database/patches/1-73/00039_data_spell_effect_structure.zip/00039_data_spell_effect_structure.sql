ALTER TABLE `main`.`data_spell_effect`
	ADD COLUMN `interval` INT(11) UNSIGNED NOT NULL AFTER `radius`;

ALTER TABLE `main`.`data_spell`
	CHANGE `subtext` `subtext_localization_id` INT(11) UNSIGNED NOT NULL,
  ADD CONSTRAINT `dps_subtext_localization_id` FOREIGN KEY (`subtext_localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE NO ACTION;
