CREATE TABLE `main`.`data_npc` (
  `expansion_id` TINYINT(3) UNSIGNED NOT NULL,
  `id` INT(11) UNSIGNED NOT NULL,
  `localization_id` INT(11) UNSIGNED NOT NULL,
  `is_boss` BINARY(1) NOT NULL,
  `friend` TINYINT(3) UNSIGNED NOT NULL,
  `family` TINYINT(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`expansion_id`),
  CONSTRAINT `dn_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE NO ACTION,
  CONSTRAINT `dn_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE NO ACTION
);
