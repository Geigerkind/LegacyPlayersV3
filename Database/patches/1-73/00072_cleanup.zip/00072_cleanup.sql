ALTER TABLE `main`.`data_item`
	DROP COLUMN `note_localization_id`,
  DROP INDEX `di_note_localization_id`,
  DROP FOREIGN KEY `di_note_localization_id`;

ALTER TABLE `main`.`data_hero_class` DROP FOREIGN KEY `dhc_localization_id`;

ALTER TABLE `main`.`data_hero_class` ADD CONSTRAINT `dhc_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT;

ALTER TABLE `main`.`data_item` DROP FOREIGN KEY `di_localization_id`;

ALTER TABLE `main`.`data_item` ADD CONSTRAINT `di_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_item_quality` DROP FOREIGN KEY `diq_localization_id`;

ALTER TABLE `main`.`data_item_quality` ADD CONSTRAINT `diq_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_item_random_property` DROP FOREIGN KEY `dirp_enchant_id1`;

ALTER TABLE `main`.`data_item_random_property` ADD CONSTRAINT `dirp_enchant_id1` FOREIGN KEY (`enchant_id1`, `expansion_id`) REFERENCES `main`.`data_enchant`(`id`, `expansion_id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_item_random_property` DROP FOREIGN KEY `dirp_enchant_id2`;

ALTER TABLE `main`.`data_item_random_property` ADD CONSTRAINT `dirp_enchant_id2` FOREIGN KEY (`enchant_id2`, `expansion_id`) REFERENCES `main`.`data_enchant`(`id`, `expansion_id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_item_random_property` DROP FOREIGN KEY `dirp_enchant_id3`;

ALTER TABLE `main`.`data_item_random_property` ADD CONSTRAINT `dirp_enchant_id3` FOREIGN KEY (`enchant_id3`, `expansion_id`) REFERENCES `main`.`data_enchant`(`id`, `expansion_id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_item_random_property` DROP FOREIGN KEY `dirp_enchant_id4`;

ALTER TABLE `main`.`data_item_random_property` ADD CONSTRAINT `dirp_enchant_id4` FOREIGN KEY (`enchant_id4`, `expansion_id`) REFERENCES `main`.`data_enchant`(`id`, `expansion_id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_item_random_property` DROP FOREIGN KEY `dirp_enchant_id5`;

ALTER TABLE `main`.`data_item_random_property` ADD CONSTRAINT `dirp_enchant_id5` FOREIGN KEY (`enchant_id5`, `expansion_id`) REFERENCES `main`.`data_enchant`(`id`, `expansion_id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_item_random_property` DROP FOREIGN KEY `dirp_localization_id`;

ALTER TABLE `main`.`data_item_random_property` ADD CONSTRAINT `dirp_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_npc` DROP FOREIGN KEY `dn_expansion_id`;

ALTER TABLE `main`.`data_npc` ADD CONSTRAINT `dn_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `main`.`data_expansion`(`id`) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE `main`.`data_npc` DROP FOREIGN KEY `dn_localization_id`;

ALTER TABLE `main`.`data_npc` ADD CONSTRAINT `dn_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_profession` DROP FOREIGN KEY `dp_localization_id`;

ALTER TABLE `main`.`data_profession` ADD CONSTRAINT `dp_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_race` DROP FOREIGN KEY `dr_localization_id`;

ALTER TABLE `main`.`data_race` ADD CONSTRAINT `dr_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

ALTER TABLE `main`.`data_stat_type` DROP FOREIGN KEY `dst_localization_id`;

ALTER TABLE `main`.`data_stat_type` ADD CONSTRAINT `dst_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `main`.`data_localization`(`id`) ON UPDATE CASCADE ON DELETE RESTRICT;

DELETE FROM main.data_localization WHERE
id NOT IN (SELECT localization_id FROM main.data_race) AND
id NOT IN (SELECT localization_id FROM main.data_hero_class) AND
id NOT IN (SELECT localization_id FROM main.data_enchant) AND
id NOT IN (SELECT localization_id FROM main.data_expansion) AND
id NOT IN (SELECT localization_id FROM main.data_item) AND
id NOT IN (SELECT localization_id FROM main.data_item_bonding) AND
id NOT IN (SELECT localization_id FROM main.data_item_class) AND
id NOT IN (SELECT localization_id FROM main.data_item_dmg_type) AND
id NOT IN (SELECT localization_id FROM main.data_item_inventory_type) AND
id NOT IN (SELECT localization_id FROM main.data_item_quality) AND
id NOT IN (SELECT localization_id FROM main.data_item_random_property) AND
id NOT IN (SELECT localization_id FROM main.data_item_sheath) AND
id NOT IN (SELECT localization_id FROM main.data_itemset_name) AND
id NOT IN (SELECT localization_id FROM main.data_profession) AND
id NOT IN (SELECT localization_id FROM main.data_spell) AND
id NOT IN (SELECT subtext_localization_id FROM main.data_spell) AND
id NOT IN (SELECT description_localization_id FROM main.data_spell) AND
id NOT IN (SELECT aura_localization_id FROM main.data_spell) AND
id NOT IN (SELECT localization_id FROM main.data_spell_dispel_type) AND
id NOT IN (SELECT localization_id FROM main.data_spell_power_type) AND
id NOT IN (SELECT localization_id FROM main.data_npc) AND
id NOT IN (SELECT localization_id FROM main.data_stat_type);