USE `main_test`;
insert into `data_language` (`id`, `language`, `short_code`) values('1','English','en');

insert into `data_localization` (`language_id`, `id`, `content`) values('1','23','Vanilla');
insert into `data_localization` (`language_id`, `id`, `content`) values('1','24','TBC');
insert into `data_localization` (`language_id`, `id`, `content`) values('1','25','WOTLK');
insert into `data_localization` (`language_id`, `id`, `content`) values('1','26','Cataclysm');
insert into `data_localization` (`language_id`, `id`, `content`) values('1','27','MoP');

insert into `data_expansion`(`id`,`localization_id`) values
(1,23),
(2,24),
(3,25),
(4,26),
(5,27);
