/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`main` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;

USE `main`;

/*Table structure for table `account_api_token` */

DROP TABLE IF EXISTS `account_api_token`;

CREATE TABLE `account_api_token` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL,
  `token` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `purpose` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `exp_date` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `SECONDARY` (`member_id`),
  KEY `TERNARY` (`token`),
  CONSTRAINT `member_must_exist` FOREIGN KEY (`member_id`) REFERENCES `account_member` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2180 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `account_member` */

DROP TABLE IF EXISTS `account_member`;

CREATE TABLE `account_member` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(1025) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `joined` int(11) unsigned NOT NULL DEFAULT 0,
  `mail_confirmed` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `forgot_password` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `delete_account` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `new_mail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `access_rights` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `am_unique_name` (`nickname`),
  UNIQUE KEY `am_unique_mail` (`mail`)
) ENGINE=InnoDB AUTO_INCREMENT=2188 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `armory_arena_team` */

DROP TABLE IF EXISTS `armory_arena_team`;

CREATE TABLE `armory_arena_team` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server_uid` bigint(20) unsigned NOT NULL DEFAULT 0,
  `server_id` int(11) unsigned NOT NULL,
  `team_name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `size_type` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_aat_server_id` (`server_id`),
  CONSTRAINT `FK_aat_server_id` FOREIGN KEY (`server_id`) REFERENCES `data_server` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `armory_character` */

DROP TABLE IF EXISTS `armory_character`;

CREATE TABLE `armory_character` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server_id` int(11) unsigned NOT NULL,
  `server_uid` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ac_unique` (`server_id`,`server_uid`),
  KEY `ac_server_id` (`server_id`),
  CONSTRAINT `ac_server_id` FOREIGN KEY (`server_id`) REFERENCES `data_server` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=281 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `armory_character_facial` */

DROP TABLE IF EXISTS `armory_character_facial`;

CREATE TABLE `armory_character_facial` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `skin_color` smallint(3) unsigned NOT NULL,
  `face_style` smallint(3) unsigned NOT NULL,
  `hair_style` smallint(3) unsigned NOT NULL,
  `hair_color` smallint(3) unsigned NOT NULL,
  `facial_hair` smallint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `acf_unique` (`skin_color`,`face_style`,`hair_style`,`hair_color`,`facial_hair`),
  KEY `acf_value_key` (`skin_color`,`face_style`,`hair_style`,`hair_color`,`facial_hair`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `armory_character_history` */

DROP TABLE IF EXISTS `armory_character_history`;

CREATE TABLE `armory_character_history` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `character_id` int(11) unsigned NOT NULL,
  `character_info_id` int(11) unsigned NOT NULL,
  `character_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `guild_id` int(11) unsigned DEFAULT NULL,
  `guild_rank` tinyint(3) unsigned DEFAULT NULL,
  `title` smallint(5) unsigned DEFAULT NULL,
  `prof_skill_points1` smallint(5) unsigned DEFAULT NULL,
  `prof_skill_points2` smallint(5) unsigned DEFAULT NULL,
  `facial` int(11) unsigned DEFAULT NULL,
  `arena2` int(11) unsigned DEFAULT NULL,
  `arena3` int(11) unsigned DEFAULT NULL,
  `arena5` int(11) unsigned DEFAULT NULL,
  `timestamp` bigint(20) unsigned NOT NULL DEFAULT unix_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ach_guild_id` (`guild_id`),
  KEY `ach_character_id` (`character_id`),
  KEY `ach_character_info_id` (`character_info_id`),
  KEY `ach_title` (`title`),
  KEY `ach_facial` (`facial`),
  KEY `ach_value_key` (`character_id`,`character_info_id`,`character_name`,`guild_id`,`guild_rank`,`title`,`prof_skill_points1`,`prof_skill_points2`,`facial`),
  KEY `ach_guild_rank` (`guild_id`,`guild_rank`),
  KEY `ach_arena2` (`arena2`),
  KEY `ach_arena3` (`arena3`),
  KEY `ach_arena5` (`arena5`),
  CONSTRAINT `ach_arena2` FOREIGN KEY (`arena2`) REFERENCES `armory_arena_team` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ach_arena3` FOREIGN KEY (`arena3`) REFERENCES `armory_arena_team` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ach_arena5` FOREIGN KEY (`arena5`) REFERENCES `armory_arena_team` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ach_character_id` FOREIGN KEY (`character_id`) REFERENCES `armory_character` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ach_character_info_id` FOREIGN KEY (`character_info_id`) REFERENCES `armory_character_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ach_facial` FOREIGN KEY (`facial`) REFERENCES `armory_character_facial` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ach_guild_id` FOREIGN KEY (`guild_id`) REFERENCES `armory_guild` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ach_guild_rank` FOREIGN KEY (`guild_id`, `guild_rank`) REFERENCES `armory_guild_rank` (`guild_id`, `rank_index`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ach_title` FOREIGN KEY (`title`) REFERENCES `data_title` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=278 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `armory_character_info` */

DROP TABLE IF EXISTS `armory_character_info`;

CREATE TABLE `armory_character_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gear_id` int(11) unsigned NOT NULL,
  `hero_class_id` tinyint(3) unsigned NOT NULL,
  `level` tinyint(3) unsigned NOT NULL,
  `gender` binary(1) NOT NULL,
  `profession1` smallint(5) unsigned DEFAULT NULL,
  `profession2` smallint(5) unsigned DEFAULT NULL,
  `talent_specialization` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `race_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `aci_unique` (`gear_id`,`hero_class_id`,`level`,`gender`,`profession1`,`profession2`,`talent_specialization`,`race_id`),
  KEY `aci_hero_class` (`hero_class_id`),
  KEY `aci_race` (`race_id`),
  KEY `aci_prof1` (`profession1`),
  KEY `aci_prof2` (`profession2`),
  KEY `aci_gear_id` (`gear_id`),
  KEY `aci_value_key` (`gear_id`,`hero_class_id`,`level`,`gender`,`profession1`,`profession2`,`talent_specialization`,`race_id`),
  CONSTRAINT `aci_gear_id` FOREIGN KEY (`gear_id`) REFERENCES `armory_gear` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `aci_hero_class` FOREIGN KEY (`hero_class_id`) REFERENCES `data_hero_class` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `aci_prof1` FOREIGN KEY (`profession1`) REFERENCES `data_profession` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `aci_prof2` FOREIGN KEY (`profession2`) REFERENCES `data_profession` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `aci_race` FOREIGN KEY (`race_id`) REFERENCES `data_race` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=306 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `armory_gear` */

DROP TABLE IF EXISTS `armory_gear`;

CREATE TABLE `armory_gear` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `head` int(11) unsigned DEFAULT NULL,
  `neck` int(11) unsigned DEFAULT NULL,
  `shoulder` int(11) unsigned DEFAULT NULL,
  `back` int(11) unsigned DEFAULT NULL,
  `chest` int(11) unsigned DEFAULT NULL,
  `shirt` int(11) unsigned DEFAULT NULL,
  `tabard` int(11) unsigned DEFAULT NULL,
  `wrist` int(11) unsigned DEFAULT NULL,
  `main_hand` int(11) unsigned DEFAULT NULL,
  `off_hand` int(11) unsigned DEFAULT NULL,
  `ternary_hand` int(11) unsigned DEFAULT NULL,
  `glove` int(11) unsigned DEFAULT NULL,
  `belt` int(11) unsigned DEFAULT NULL,
  `leg` int(11) unsigned DEFAULT NULL,
  `boot` int(11) unsigned DEFAULT NULL,
  `ring1` int(11) unsigned DEFAULT NULL,
  `ring2` int(11) unsigned DEFAULT NULL,
  `trinket1` int(11) unsigned DEFAULT NULL,
  `trinket2` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ag_unique` (`head`,`neck`,`shoulder`,`back`,`chest`,`shirt`,`tabard`,`wrist`,`main_hand`,`off_hand`,`ternary_hand`,`glove`,`belt`,`leg`,`boot`,`ring1`,`ring2`,`trinket1`,`trinket2`),
  KEY `ag_slot1` (`head`),
  KEY `ag_slot2` (`neck`),
  KEY `ag_slot3` (`shoulder`),
  KEY `ag_slot4` (`back`),
  KEY `ag_slot5` (`chest`),
  KEY `ag_slot6` (`shirt`),
  KEY `ag_slot7` (`tabard`),
  KEY `ag_slot8` (`wrist`),
  KEY `ag_slot9` (`main_hand`),
  KEY `ag_slot10` (`off_hand`),
  KEY `ag_slot11` (`ternary_hand`),
  KEY `ag_slot12` (`glove`),
  KEY `ag_slot14` (`leg`),
  KEY `ag_slot15` (`boot`),
  KEY `ag_slot16` (`ring1`),
  KEY `ag_slot17` (`ring2`),
  KEY `ag_slot18` (`trinket1`),
  KEY `ag_slot19` (`trinket2`),
  KEY `ag_slot13` (`belt`),
  KEY `ag_value_key` (`head`,`neck`,`shoulder`,`back`,`chest`,`shirt`,`tabard`,`wrist`,`main_hand`,`off_hand`,`ternary_hand`,`glove`,`belt`,`leg`,`boot`,`ring1`,`ring2`,`trinket1`,`trinket2`),
  CONSTRAINT `ag_slot1` FOREIGN KEY (`head`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot10` FOREIGN KEY (`off_hand`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot11` FOREIGN KEY (`ternary_hand`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot12` FOREIGN KEY (`glove`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot13` FOREIGN KEY (`belt`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot14` FOREIGN KEY (`leg`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot15` FOREIGN KEY (`boot`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot16` FOREIGN KEY (`ring1`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot17` FOREIGN KEY (`ring2`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot18` FOREIGN KEY (`trinket1`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot19` FOREIGN KEY (`trinket2`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot2` FOREIGN KEY (`neck`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot3` FOREIGN KEY (`shoulder`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot4` FOREIGN KEY (`back`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot5` FOREIGN KEY (`chest`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot6` FOREIGN KEY (`shirt`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot7` FOREIGN KEY (`tabard`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot8` FOREIGN KEY (`wrist`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `ag_slot9` FOREIGN KEY (`main_hand`) REFERENCES `armory_item` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=348 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `armory_guild` */

DROP TABLE IF EXISTS `armory_guild`;

CREATE TABLE `armory_guild` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server_uid` bigint(20) unsigned NOT NULL,
  `server_id` int(11) unsigned NOT NULL,
  `guild_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ag_unique_sid_name` (`server_id`,`guild_name`),
  UNIQUE KEY `ag_unique_sid_uid` (`server_uid`,`server_id`),
  KEY `ag_server_id` (`server_id`),
  KEY `ag_value_key` (`server_uid`,`server_id`,`guild_name`),
  CONSTRAINT `ag_server_id` FOREIGN KEY (`server_id`) REFERENCES `data_server` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `armory_guild_rank` */

DROP TABLE IF EXISTS `armory_guild_rank`;

CREATE TABLE `armory_guild_rank` (
  `guild_id` int(11) unsigned NOT NULL,
  `rank_index` tinyint(3) unsigned NOT NULL,
  `name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`guild_id`,`rank_index`),
  CONSTRAINT `agr_guild_id` FOREIGN KEY (`guild_id`) REFERENCES `armory_guild` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `armory_instance_resets` */

DROP TABLE IF EXISTS `armory_instance_resets`;

CREATE TABLE `armory_instance_resets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server_id` int(11) unsigned NOT NULL,
  `map_id` smallint(5) unsigned NOT NULL,
  `difficulty` tinyint(3) unsigned NOT NULL,
  `reset_time` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_value` (`server_id`,`map_id`,`difficulty`,`reset_time`),
  CONSTRAINT `FK_air_server_id` FOREIGN KEY (`server_id`) REFERENCES `data_server` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=404 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `armory_item` */

DROP TABLE IF EXISTS `armory_item`;

CREATE TABLE `armory_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(11) unsigned NOT NULL,
  `random_property_id` smallint(5) DEFAULT NULL,
  `enchant_id` int(11) unsigned DEFAULT NULL,
  `gem_id1` int(11) unsigned DEFAULT NULL,
  `gem_id2` int(11) unsigned DEFAULT NULL,
  `gem_id3` int(11) unsigned DEFAULT NULL,
  `gem_id4` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ai_unique` (`item_id`,`random_property_id`,`enchant_id`,`gem_id1`,`gem_id2`,`gem_id3`,`gem_id4`),
  KEY `ai_item_id` (`item_id`),
  KEY `ai_random_property_id` (`random_property_id`),
  KEY `ai_enchant_id` (`enchant_id`),
  KEY `ai_gem_id1` (`gem_id1`),
  KEY `ai_gem_id2` (`gem_id2`),
  KEY `ai_gem_id3` (`gem_id3`),
  KEY `ai_gem_id4` (`gem_id4`),
  KEY `ai_value_key` (`item_id`,`random_property_id`,`enchant_id`,`gem_id1`,`gem_id2`,`gem_id3`,`gem_id4`),
  CONSTRAINT `ai_enchant_id` FOREIGN KEY (`enchant_id`) REFERENCES `data_enchant` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ai_gem_id1` FOREIGN KEY (`gem_id1`) REFERENCES `data_gem` (`item_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ai_gem_id2` FOREIGN KEY (`gem_id2`) REFERENCES `data_gem` (`item_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ai_gem_id3` FOREIGN KEY (`gem_id3`) REFERENCES `data_gem` (`item_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ai_gem_id4` FOREIGN KEY (`gem_id4`) REFERENCES `data_gem` (`item_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ai_item_id` FOREIGN KEY (`item_id`) REFERENCES `data_item` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ai_random_property` FOREIGN KEY (`random_property_id`) REFERENCES `data_item_random_property` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3694 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_enchant` */

DROP TABLE IF EXISTS `data_enchant`;

CREATE TABLE `data_enchant` (
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  `stat_type1` tinyint(3) unsigned DEFAULT NULL,
  `stat_value1` smallint(5) unsigned DEFAULT NULL,
  `stat_type2` tinyint(3) unsigned DEFAULT NULL,
  `stat_value2` smallint(5) unsigned DEFAULT NULL,
  `stat_type3` tinyint(3) unsigned DEFAULT NULL,
  `stat_value3` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`expansion_id`,`id`),
  KEY `id` (`id`),
  KEY `dets_stat_type1` (`stat_type1`),
  KEY `dets_stat_type2` (`stat_type2`),
  KEY `dets_stat_type3` (`stat_type3`),
  CONSTRAINT `dets_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dets_stat_type1` FOREIGN KEY (`stat_type1`) REFERENCES `data_stat_type` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `dets_stat_type2` FOREIGN KEY (`stat_type2`) REFERENCES `data_stat_type` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `dets_stat_type3` FOREIGN KEY (`stat_type3`) REFERENCES `data_stat_type` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46852 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_expansion` */

DROP TABLE IF EXISTS `data_expansion`;

CREATE TABLE `data_expansion` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `de_localization_id` (`localization_id`),
  CONSTRAINT `de_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_gem` */

DROP TABLE IF EXISTS `data_gem`;

CREATE TABLE `data_gem` (
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `item_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `enchant_id` int(11) unsigned NOT NULL,
  `flag` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`expansion_id`,`item_id`),
  KEY `id` (`item_id`),
  KEY `dg_enchant_id` (`expansion_id`,`enchant_id`),
  CONSTRAINT `dg_enchant_id` FOREIGN KEY (`expansion_id`, `enchant_id`) REFERENCES `data_enchant` (`expansion_id`, `id`) ON UPDATE CASCADE,
  CONSTRAINT `dg_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dg_item_id` FOREIGN KEY (`expansion_id`, `item_id`) REFERENCES `data_item` (`expansion_id`, `id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49111 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_hero_class` */

DROP TABLE IF EXISTS `data_hero_class`;

CREATE TABLE `data_hero_class` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  `color` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dhc_localization_id` (`localization_id`),
  CONSTRAINT `dhc_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_hero_class_spec` */

DROP TABLE IF EXISTS `data_hero_class_spec`;

CREATE TABLE `data_hero_class_spec` (
  `hero_class_id` tinyint(3) unsigned NOT NULL,
  `index` tinyint(3) unsigned NOT NULL,
  `icon` smallint(5) unsigned NOT NULL,
  `localization_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`hero_class_id`,`index`),
  KEY `dhcp_localization_id` (`localization_id`),
  KEY `dhcp_icon` (`icon`),
  CONSTRAINT `dhcp_hero_class_id` FOREIGN KEY (`hero_class_id`) REFERENCES `data_hero_class` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `dhcp_icon` FOREIGN KEY (`icon`) REFERENCES `data_icon` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `dhcp_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_icon` */

DROP TABLE IF EXISTS `data_icon`;

CREATE TABLE `data_icon` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `icon` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `icon_unique` (`icon`)
) ENGINE=InnoDB AUTO_INCREMENT=5259 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item` */

DROP TABLE IF EXISTS `data_item`;

CREATE TABLE `data_item` (
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  `icon` smallint(5) unsigned NOT NULL,
  `quality` tinyint(3) unsigned NOT NULL,
  `inventory_type` tinyint(3) unsigned DEFAULT NULL,
  `class_id` tinyint(3) unsigned NOT NULL,
  `required_level` tinyint(3) unsigned DEFAULT NULL,
  `bonding` tinyint(3) unsigned DEFAULT NULL,
  `sheath` tinyint(3) unsigned DEFAULT NULL,
  `itemset` smallint(5) unsigned DEFAULT NULL,
  `max_durability` smallint(5) unsigned DEFAULT NULL,
  `item_level` smallint(5) unsigned DEFAULT NULL,
  `delay` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`,`expansion_id`),
  KEY `di_expansion_id` (`expansion_id`),
  KEY `di_quality` (`quality`),
  KEY `di_bonding` (`bonding`),
  KEY `di_sheath` (`sheath`),
  KEY `di_inventory_type` (`inventory_type`),
  KEY `di_class_id` (`class_id`),
  KEY `di_itemset` (`itemset`),
  KEY `di_localization_id` (`localization_id`),
  KEY `di_icon` (`icon`),
  CONSTRAINT `di_bonding` FOREIGN KEY (`bonding`) REFERENCES `data_item_bonding` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `di_class_id` FOREIGN KEY (`class_id`) REFERENCES `data_item_class` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `di_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `di_icon` FOREIGN KEY (`icon`) REFERENCES `data_icon` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `di_inventory_type` FOREIGN KEY (`inventory_type`) REFERENCES `data_item_inventory_type` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `di_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `di_quality` FOREIGN KEY (`quality`) REFERENCES `data_item_quality` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `di_sheath` FOREIGN KEY (`sheath`) REFERENCES `data_item_sheath` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56807 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_bonding` */

DROP TABLE IF EXISTS `data_item_bonding`;

CREATE TABLE `data_item_bonding` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dib_localization_id` (`localization_id`),
  CONSTRAINT `dib_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_class` */

DROP TABLE IF EXISTS `data_item_class`;

CREATE TABLE `data_item_class` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `item_class` tinyint(3) unsigned NOT NULL,
  `item_sub_class` tinyint(3) unsigned NOT NULL,
  `localization_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dic_class_unique` (`item_class`,`item_sub_class`),
  KEY `dic_localization_id` (`localization_id`),
  CONSTRAINT `dic_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_dmg` */

DROP TABLE IF EXISTS `data_item_dmg`;

CREATE TABLE `data_item_dmg` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `item_id` int(11) unsigned NOT NULL,
  `dmg_type` tinyint(3) unsigned DEFAULT NULL,
  `dmg_min` smallint(5) unsigned NOT NULL,
  `dmg_max` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `did_item_id` (`expansion_id`,`item_id`),
  KEY `did_dmg_type` (`dmg_type`),
  CONSTRAINT `did_dmg_type` FOREIGN KEY (`dmg_type`) REFERENCES `data_item_dmg_type` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `did_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `did_item_id` FOREIGN KEY (`expansion_id`, `item_id`) REFERENCES `data_item` (`expansion_id`, `id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9051 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_dmg_type` */

DROP TABLE IF EXISTS `data_item_dmg_type`;

CREATE TABLE `data_item_dmg_type` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `didt_localization_id` (`localization_id`),
  CONSTRAINT `didt_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_effect` */

DROP TABLE IF EXISTS `data_item_effect`;

CREATE TABLE `data_item_effect` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `item_id` int(11) unsigned NOT NULL,
  `spell_id` int(11) unsigned NOT NULL,
  `cooldown` int(11) NOT NULL,
  `charges` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `die2_spell_id` (`expansion_id`,`spell_id`),
  KEY `die2_item_id` (`expansion_id`,`item_id`),
  CONSTRAINT `die2_item_id` FOREIGN KEY (`expansion_id`, `item_id`) REFERENCES `data_item` (`expansion_id`, `id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `die2_spell_id` FOREIGN KEY (`expansion_id`, `spell_id`) REFERENCES `data_spell` (`expansion_id`, `id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56802 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_inventory_type` */

DROP TABLE IF EXISTS `data_item_inventory_type`;

CREATE TABLE `data_item_inventory_type` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `diit_localization_id` (`localization_id`),
  CONSTRAINT `diit_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_quality` */

DROP TABLE IF EXISTS `data_item_quality`;

CREATE TABLE `data_item_quality` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  `color` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `diq_localization_id` (`localization_id`),
  CONSTRAINT `diq_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_random_property` */

DROP TABLE IF EXISTS `data_item_random_property`;

CREATE TABLE `data_item_random_property` (
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `id` smallint(5) NOT NULL,
  `localization_id` int(11) unsigned NOT NULL,
  `enchant_id1` int(11) unsigned NOT NULL,
  `enchant_id2` int(11) unsigned DEFAULT NULL,
  `enchant_id3` int(11) unsigned DEFAULT NULL,
  `enchant_id4` int(11) unsigned DEFAULT NULL,
  `enchant_id5` int(11) unsigned DEFAULT NULL,
  `scaling_coefficient1` int(11) unsigned DEFAULT NULL,
  `scaling_coefficient2` int(11) unsigned DEFAULT NULL,
  `scaling_coefficient3` int(11) unsigned DEFAULT NULL,
  `scaling_coefficient4` int(11) unsigned DEFAULT NULL,
  `scaling_coefficient5` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`expansion_id`,`id`),
  KEY `id` (`id`),
  KEY `dirp_enchant_id1` (`enchant_id1`,`expansion_id`),
  KEY `dirp_enchant_id2` (`enchant_id2`,`expansion_id`),
  KEY `dirp_enchant_id3` (`enchant_id3`,`expansion_id`),
  KEY `dirp_enchant_id4` (`enchant_id4`,`expansion_id`),
  KEY `dirp_enchant_id5` (`enchant_id5`,`expansion_id`),
  KEY `dirp_localization_id` (`localization_id`),
  CONSTRAINT `dirp_enchant_id1` FOREIGN KEY (`enchant_id1`, `expansion_id`) REFERENCES `data_enchant` (`id`, `expansion_id`) ON UPDATE CASCADE,
  CONSTRAINT `dirp_enchant_id2` FOREIGN KEY (`enchant_id2`, `expansion_id`) REFERENCES `data_enchant` (`id`, `expansion_id`) ON UPDATE CASCADE,
  CONSTRAINT `dirp_enchant_id3` FOREIGN KEY (`enchant_id3`, `expansion_id`) REFERENCES `data_enchant` (`id`, `expansion_id`) ON UPDATE CASCADE,
  CONSTRAINT `dirp_enchant_id4` FOREIGN KEY (`enchant_id4`, `expansion_id`) REFERENCES `data_enchant` (`id`, `expansion_id`) ON UPDATE CASCADE,
  CONSTRAINT `dirp_enchant_id5` FOREIGN KEY (`enchant_id5`, `expansion_id`) REFERENCES `data_enchant` (`id`, `expansion_id`) ON UPDATE CASCADE,
  CONSTRAINT `dirp_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dirp_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_random_property_points` */

DROP TABLE IF EXISTS `data_item_random_property_points`;

CREATE TABLE `data_item_random_property_points` (
  `item_level` smallint(5) unsigned NOT NULL,
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `epic0` smallint(5) unsigned NOT NULL,
  `epic1` smallint(5) unsigned NOT NULL,
  `epic2` smallint(5) unsigned NOT NULL,
  `epic3` smallint(5) unsigned NOT NULL,
  `epic4` smallint(5) unsigned NOT NULL,
  `rare0` smallint(5) unsigned NOT NULL,
  `rare1` smallint(5) unsigned NOT NULL,
  `rare2` smallint(5) unsigned NOT NULL,
  `rare3` smallint(5) unsigned NOT NULL,
  `rare4` smallint(5) unsigned NOT NULL,
  `good0` smallint(5) unsigned NOT NULL,
  `good1` smallint(5) unsigned NOT NULL,
  `good2` smallint(5) unsigned NOT NULL,
  `good3` smallint(5) unsigned NOT NULL,
  `good4` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`item_level`,`expansion_id`),
  KEY `dirpp_expansion_id` (`expansion_id`),
  CONSTRAINT `dirpp_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_sheath` */

DROP TABLE IF EXISTS `data_item_sheath`;

CREATE TABLE `data_item_sheath` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dis3_localization_id` (`localization_id`),
  CONSTRAINT `dis3_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_socket` */

DROP TABLE IF EXISTS `data_item_socket`;

CREATE TABLE `data_item_socket` (
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `item_id` int(11) unsigned NOT NULL,
  `bonus` int(11) unsigned NOT NULL,
  `slot1` tinyint(3) unsigned NOT NULL,
  `slot2` tinyint(3) unsigned DEFAULT NULL,
  `slot3` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`expansion_id`,`item_id`),
  KEY `dis_bonus` (`bonus`,`expansion_id`),
  CONSTRAINT `dis2_item_id` FOREIGN KEY (`expansion_id`, `item_id`) REFERENCES `data_item` (`expansion_id`, `id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_item_stat` */

DROP TABLE IF EXISTS `data_item_stat`;

CREATE TABLE `data_item_stat` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `item_id` int(11) unsigned NOT NULL,
  `stat_type` tinyint(3) unsigned NOT NULL,
  `stat_value` smallint(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dis_unique` (`expansion_id`,`item_id`,`stat_type`),
  KEY `dis_item_id` (`expansion_id`,`item_id`),
  KEY `dis_stat_type` (`stat_type`),
  CONSTRAINT `dis_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dis_item_id` FOREIGN KEY (`expansion_id`, `item_id`) REFERENCES `data_item` (`expansion_id`, `id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dis_stat_type` FOREIGN KEY (`stat_type`) REFERENCES `data_stat_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=130758 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_itemset_effect` */

DROP TABLE IF EXISTS `data_itemset_effect`;

CREATE TABLE `data_itemset_effect` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `itemset_id` smallint(5) unsigned NOT NULL,
  `threshold` tinyint(3) unsigned NOT NULL,
  `spell_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `die_spell_id` (`expansion_id`,`spell_id`),
  KEY `die_itemset_id` (`expansion_id`,`itemset_id`),
  CONSTRAINT `die_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `die_itemset_id` FOREIGN KEY (`expansion_id`, `itemset_id`) REFERENCES `data_itemset_name` (`expansion_id`, `id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `die_spell_id` FOREIGN KEY (`expansion_id`, `spell_id`) REFERENCES `data_spell` (`expansion_id`, `id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2478 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_itemset_name` */

DROP TABLE IF EXISTS `data_itemset_name`;

CREATE TABLE `data_itemset_name` (
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `id` smallint(5) unsigned NOT NULL,
  `localization_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`expansion_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_language` */

DROP TABLE IF EXISTS `data_language`;

CREATE TABLE `data_language` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `language` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `short_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_localization` */

DROP TABLE IF EXISTS `data_localization`;

CREATE TABLE `data_localization` (
  `language_id` tinyint(3) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`,`language_id`),
  KEY `language_id` (`language_id`),
  CONSTRAINT `language_id` FOREIGN KEY (`language_id`) REFERENCES `data_language` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=119777 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_npc` */

DROP TABLE IF EXISTS `data_npc`;

CREATE TABLE `data_npc` (
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  `is_boss` binary(1) NOT NULL,
  `friend` tinyint(3) unsigned NOT NULL,
  `family` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`expansion_id`,`id`),
  KEY `id` (`id`),
  KEY `dn_localization_id` (`localization_id`),
  CONSTRAINT `dn_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dn_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=200421 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_profession` */

DROP TABLE IF EXISTS `data_profession`;

CREATE TABLE `data_profession` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  `icon` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dp_localization_id` (`localization_id`),
  KEY `dp_icon` (`icon`),
  CONSTRAINT `dp_icon` FOREIGN KEY (`icon`) REFERENCES `data_icon` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `dp_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=774 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_race` */

DROP TABLE IF EXISTS `data_race`;

CREATE TABLE `data_race` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  `faction` binary(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `dr_localization_id` (`localization_id`),
  CONSTRAINT `dr_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_server` */

DROP TABLE IF EXISTS `data_server`;

CREATE TABLE `data_server` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `server_name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `owner` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ds_expansion_id` (`expansion_id`),
  KEY `ds_owner` (`owner`),
  CONSTRAINT `ds_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `ds_owner` FOREIGN KEY (`owner`) REFERENCES `account_member` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_spell` */

DROP TABLE IF EXISTS `data_spell`;

CREATE TABLE `data_spell` (
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  `subtext_localization_id` int(11) unsigned NOT NULL,
  `cost` smallint(5) unsigned NOT NULL,
  `cost_in_percent` binary(1) NOT NULL DEFAULT '0',
  `power_type` tinyint(3) unsigned NOT NULL,
  `cast_time` int(11) unsigned NOT NULL DEFAULT 0,
  `school_mask` smallint(5) unsigned NOT NULL,
  `dispel_type` tinyint(3) unsigned NOT NULL,
  `range_max` int(11) unsigned NOT NULL,
  `cooldown` int(11) unsigned NOT NULL,
  `duration` int(11) NOT NULL DEFAULT 0,
  `icon` smallint(5) unsigned NOT NULL,
  `description_localization_id` int(11) unsigned NOT NULL,
  `aura_localization_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`expansion_id`,`id`),
  KEY `id` (`id`),
  KEY `dsp_dispel_type` (`dispel_type`),
  KEY `dps_subtext_localization_id` (`subtext_localization_id`),
  KEY `dsp_aura_localization_id` (`aura_localization_id`),
  KEY `dsp_description_localization_id` (`description_localization_id`),
  KEY `dsp_localization_id` (`localization_id`),
  KEY `dsp_power_type` (`power_type`),
  KEY `dsp_icon` (`icon`),
  CONSTRAINT `dps_subtext_localization_id` FOREIGN KEY (`subtext_localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `dsp_aura_localization_id` FOREIGN KEY (`aura_localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `dsp_description_localization_id` FOREIGN KEY (`description_localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `dsp_dispel_type` FOREIGN KEY (`dispel_type`) REFERENCES `data_spell_dispel_type` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `dsp_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dsp_icon` FOREIGN KEY (`icon`) REFERENCES `data_icon` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `dsp_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `dsp_power_type` FOREIGN KEY (`power_type`) REFERENCES `data_spell_power_type` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=301102 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_spell_dispel_type` */

DROP TABLE IF EXISTS `data_spell_dispel_type`;

CREATE TABLE `data_spell_dispel_type` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  `color` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dsdt_localization_id` (`localization_id`),
  CONSTRAINT `dsdt_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_spell_effect` */

DROP TABLE IF EXISTS `data_spell_effect`;

CREATE TABLE `data_spell_effect` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `expansion_id` tinyint(3) unsigned NOT NULL,
  `spell_id` int(11) unsigned NOT NULL,
  `points_lower` int(11) NOT NULL,
  `points_upper` int(11) NOT NULL,
  `chain_targets` smallint(5) unsigned NOT NULL,
  `radius` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`spell_id`),
  KEY `dse_spell_id` (`expansion_id`,`spell_id`),
  CONSTRAINT `dse_expansion_id` FOREIGN KEY (`expansion_id`) REFERENCES `data_expansion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=129789 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_spell_power_type` */

DROP TABLE IF EXISTS `data_spell_power_type`;

CREATE TABLE `data_spell_power_type` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  `color` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dspt_localization_id` (`localization_id`),
  CONSTRAINT `dspt_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_stat_type` */

DROP TABLE IF EXISTS `data_stat_type`;

CREATE TABLE `data_stat_type` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dst_localization_id` (`localization_id`),
  CONSTRAINT `dst_localization_id` FOREIGN KEY (`localization_id`) REFERENCES `data_localization` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `data_title` */

DROP TABLE IF EXISTS `data_title`;

CREATE TABLE `data_title` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `localization_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=673 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
