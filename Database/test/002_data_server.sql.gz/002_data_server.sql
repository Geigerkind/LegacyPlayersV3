/*!40101 SET NAMES utf8 */;

USE `main`;

insert into `data_server` (`id`, `expansion_id`, `server_name`, `owner`) values('1','1','Shino\'s Test Vanilla server',NULL);
insert into `data_server` (`id`, `expansion_id`, `server_name`, `owner`) values('2','2','Shino\'s Test TBC server',NULL);
insert into `data_server` (`id`, `expansion_id`, `server_name`, `owner`) values('3','3','Shino\'s Test WOTLK server',NULL);
