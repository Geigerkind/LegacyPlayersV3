local LSM = LibStub("LibSharedMedia-3.0")

LSM:Register("font", "TukUI Unitframes", [[Interface\Addons\ElvUI_Enhanced\Media\Fonts\uf_font.ttf]], LSM.LOCALE_BIT_ruRU + LSM.LOCALE_BIT_western)
LSM:Register("statusbar", "Bui OnePixel", [[Interface\AddOns\ElvUI_Enhanced\Media\Textures\BuiOnePixel.tga]])