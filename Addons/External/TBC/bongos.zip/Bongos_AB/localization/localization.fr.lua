--[[
	Bongos_Actionbar Localization
		French
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bongos3-AB', 'frFR')
if not L then return end

L.Columns = 'Colonnes'
L.Size = 'Tailles'
L.Vertical = 'Vertical'
L.OneBag = 'Un Sac'
L.Paging = 'Paging'
L.FriendlyTarget = 'Cible amie'
L.Modifier = 'Modifier'
L.Prowl = 'Prowl'
L.ShadowForm = "Forme d'ombre/Redemption"