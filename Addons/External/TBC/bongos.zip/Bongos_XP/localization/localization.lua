--[[
	Bongos XP Localization file
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bongos3-XP', 'enUS', true)

L.Height = 'Height'
L.Width = 'Width'
L.Vertical = 'Vertical'
L.VerticalPosition = 'Vertical Position'
L.HorizontalPosition = 'Horizontal Position'
L.AlwaysShow = 'Always Show'
L.AlwaysShowXP = 'Always Show Experience'
L.Text = 'Text'