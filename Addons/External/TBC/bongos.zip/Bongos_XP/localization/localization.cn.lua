--[[
	Bongos XP Localization file
		Chinese Simplified by ondh
		http://www.ondh.cn
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bongos3-XP', 'zhCN')
if not L then return end

L.Height = '高度'
L.Width = '长度'
L.Vertical = '垂直'