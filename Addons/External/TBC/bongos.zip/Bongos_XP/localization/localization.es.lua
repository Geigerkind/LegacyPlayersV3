﻿--[[
	Bongos_XPbar Localization
	Spanish by Ferroginu from Zul'jin
	¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡ SAVE in UTF-8 !!!!!!!!!!!!!!!!!!!!!!!!
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bongos3-XP', 'esES')
if not L then return end

L.Height = 'Altura'
L.Width = 'Anchura'
L.Vertical = 'Vertical'
L.AlwaysShowText = 'Mostrar siempre el texto'
L.TextPosition = 'Positión del texto'