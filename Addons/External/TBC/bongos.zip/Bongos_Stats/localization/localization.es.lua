﻿--[[
	Bongos_Stats Localization
	Spanish by Ferroginu from Zul'jin
	¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡ SAVE in UTF-8 !!!!!!!!!!!!!!!!!!!!!!!!
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bongos3-Stats', 'esES')
if not L then return end

L.ShowMemory = 'Mostrar la Memoria'
L.ShowFPS = 'Mostrar las Imagenes por Segundo'
L.ShowPing = 'Mostra la Latencia'
L.CPUUsage = 'Uso de UCP de los Añadidos'
L.MemUsage = 'Uso de Memoria de los Añadidos'
L.Total = 'Total'