--[[
	Bongos Stats Localization file
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bongos3-Stats', 'enUS', true)
L.ShowMemory = "Show Memory"
L.ShowFPS = "Show Framerate"
L.ShowPing = "Show Latency"
L.CPUUsage = "Addon CPU Usage"
L.MemUsage = "Addon Memory Usage"
L.Total = "Total"

L.BongosStats = "Bongos Stats"
L.ToggleBongosStats = "Toggle Bongos Stats"