--[[
	Bongos Stats Localization file
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bongos3-Stats', 'frFR')
if not L then return end

L.ShowMemory = 'Afficher la m�moire'
L.ShowFPS = 'Afficher Framerate'
L.ShowPing = 'Afficher Latence'
L.CPUUsage = 'Usage CPU des addon'
L.MemUsage = 'Usage m�moire des addon'
L.Total = 'Total'