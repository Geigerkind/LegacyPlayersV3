--[[
	Bongos CastBar Localization file
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bongos3-CastBar', 'enUS', true)
L.ShowTime = 'Show Time'