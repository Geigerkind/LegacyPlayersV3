﻿--[[
	Bongos_Castbar Localization
	Spanish by Ferroginu from Zul'jin
	¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡ SAVE in UTF-8 !!!!!!!!!!!!!!!!!!!!!!!!
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bongos3-CastBar', 'esES')
if not L then return end

L.ShowTime = 'Mostrar tiempo'