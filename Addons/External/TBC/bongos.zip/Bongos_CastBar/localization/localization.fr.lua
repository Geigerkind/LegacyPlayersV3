﻿--[[
	Bongos CastBar Localization file
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bongos3-CastBar', 'frFR')
if not L then return end

L.ShowTime = 'Montrer le temps'