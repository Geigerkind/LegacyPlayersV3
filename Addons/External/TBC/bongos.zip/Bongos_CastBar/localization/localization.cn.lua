﻿--[[
	Bongos CastBar Localization file
		Chinese Simplified by ondh
		http://www.ondh.cn
--]]
local L = LibStub('AceLocale-3.0'):NewLocale('Bongos3-CastBar', 'zhCN')
if not L then return end

L.ShowTime = '显示时间'