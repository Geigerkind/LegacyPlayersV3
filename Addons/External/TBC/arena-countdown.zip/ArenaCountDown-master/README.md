# ArenaCountDown
ArenaCountDown (as seen in patch 4.0+) ported to TBC 2.4.3
![image of countdown](http://i.imgur.com/PmROwSN.png)
