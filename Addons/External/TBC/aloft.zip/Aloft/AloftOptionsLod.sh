#!/bin/sh
rm -rf ../AloftOptions
mv Options ../AloftOptions

