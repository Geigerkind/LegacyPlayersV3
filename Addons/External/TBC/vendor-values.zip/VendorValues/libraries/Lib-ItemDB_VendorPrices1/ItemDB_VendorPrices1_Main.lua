

local o = ItemDB_VendorPrices1; if (o.SHOULD_LOAD == nil) then return; end


o.t_Init();


o.SHOULD_LOAD = nil;

