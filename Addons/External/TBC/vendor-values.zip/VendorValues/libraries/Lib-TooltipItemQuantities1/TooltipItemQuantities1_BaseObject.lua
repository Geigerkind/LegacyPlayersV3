

LoadLibrary1("TooltipItemQuantities", 121, nil, nil);

