

local didLoad, o = LoadLibrary1("SimpleSlash", 142, nil, nil);



if (didLoad == true) then
	o.Localization = { NOT_LOADED = true };
end

