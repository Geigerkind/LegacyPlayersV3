

LoadLibrary1("ConfigManager", 120, nil, nil, "EventsManager1");

