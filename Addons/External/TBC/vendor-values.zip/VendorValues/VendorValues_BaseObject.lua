

VendorValues = {
	Localization = { NOT_LOADED = true };
};

