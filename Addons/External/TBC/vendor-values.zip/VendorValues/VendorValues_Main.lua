

local o = VendorValues;


o.t_Config_Init();

o.Tooltips_RegisterTooltip(GameTooltip);
o.Tooltips_RegisterTooltip(ItemRefTooltip);

