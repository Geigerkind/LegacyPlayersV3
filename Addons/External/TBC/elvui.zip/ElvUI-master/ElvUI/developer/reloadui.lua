--[[
	Shortcut to ReloadUI
]]

SLASH_RELOADUI1 = "/rl"
SLASH_RELOADUI2 = "/reloadui"
SLASH_RELOADUI3 = "/reload"
SlashCmdList.RELOADUI = ReloadUI