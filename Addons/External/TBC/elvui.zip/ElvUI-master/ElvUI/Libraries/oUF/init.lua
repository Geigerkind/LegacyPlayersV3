oUF = {}

local ns = oUF
ns.oUF = {}
ns.oUF.Private = {}