-- Author      : Linty
------------------------Titan Pannel Mngr---------------------
iguard_titan_loaded=false

if not IsAddOnLoaded("Titan") then
	-- Do not load if Titanbar is not loaded
	return
end

--- Init 


function iguardTitanButton_load()

	--- !! Important ID must match Bottopn Name in XML (format : TitanPanel<ID>Button)

	this.registry = {
    id = "Iguard",
    menuText = "IGuard",
    tooltipTitle = "IGuard",
    tooltipTextFunction = "iguardTitanButton_getTooltipText",
    category = "Information",
    builtin = 1,
    icon = iguard.icons.mainIco,
    iconWidth = 16,
	iconButtonWidth = 16,    
    buttonTextFunction = "iguardTitanButton_getButtonText",
	savedVariables = {
			ShowIcon = 1,    
	},
  }

  iguard_titan_loaded=true
end


function iguardTitanButton_getButtonText()

	return iguard.titan.menuText
end

function iguardTitanButton_getTooltipText()
		local ttText=""


		local cnt=0
		for k, v in pairs(iguard.BuyBackCache) do
			if (v~=nil) then 
				  cnt=cnt+1
			end
		end
		
		ttText=ttText.."|TInterface\\Icons\\INV_misc_bag_07_red.blp:16|t You can buy back\t|cff30C0FF[".. cnt .."]|r\n"
		
		ttText=ttText.."\n|cffC0E0FFProtected:|r\n"
		txtProtect="|cffff0000No"
		if (iguard_data.options.ProtectEpicPlus) then txtProtect="|cff00FF00Yes" end
		
		ttText=ttText.."|TInterface\\Icons\\inv_jewelcrafting_nightseye_03.blp:16|t Epic+ Items\t"..txtProtect.."|r\n"

		
		txtProtect="|cffff0000No"
		if (iguard_data.options.ProtectRare) then txtProtect="|cff00FF00Yes" end
		
		ttText=ttText.."|TInterface\\Icons\\inv_jewelcrafting_starofelune_03.blp:16|t Rare Items\t"..txtProtect.."|r\n"
	
		local cnt=0
		for k, v in pairs(iguard_data.AlwaysProtect) do
			if (v~=nil) then 
				  cnt=cnt+1
			end
		end
		ttText=ttText.."|TInterface\\Icons\\inv_misc_gem_diamond_05.blp:16|t Custom Items\t|cff30C0FF[".. cnt.."]|r\n"

		ttText=ttText.."\n|cffC0E0FFProtection:|r\n"
		
		txtProtect="|cffff0000No"
		if (iguard_data.options.RestoreProtected) then txtProtect="|cff00FF00Yes" end
		
		ttText=ttText.."|TInterface\\Icons\\INV_misc_bag_17.blp:16|t Stop Vendor Sales\t"..txtProtect.."|r\n"
		

		ttText=ttText.."\n|cff30C0FFHint: Left Click lists buyback &|r"
		ttText=ttText.."\n|cff30C0FFRight Click for Options.|r"

	return ttText
end


function TitanPanelRightClickMenu_PrepareIguardMenu()

  TitanPanelRightClickMenu_AddTitle("IGuard");

  TitanPanelRightClickMenu_AddCommand("Buyback List [chat]", Nil, "iguard_cmd_buyback");
  TitanPanelRightClickMenu_AddCommand("Custom Item Protection [chat]", Nil, "iguard_cmd_custom");
  TitanPanelRightClickMenu_AddCommand("History [chat]", Nil, "iguard_cmd_history");
  TitanPanelRightClickMenu_AddSpacer();
  -- Add toggle for Enable/disable
  info = {};
     info.text = "Enabled";
     info.func = iguard_cmd_enableToggle;
     info.checked = iguard_data.options.RestoreProtected;
     info.keepShownOnClick = 1;
  UIDropDownMenu_AddButton(info);
  
  TitanPanelRightClickMenu_AddCommand("Configure..", Nil, "iguard_cmd_config");
  TitanPanelRightClickMenu_AddSpacer();
  TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, "Iguard", TITAN_PANEL_MENU_FUNC_HIDE);
end

function iguardTitanButton_OnClick(button)
	if (button == "LeftButton") then
          iguard_cmd_buyback()
     end
end
