﻿--Russian localization file
--Translated by StingerSoft
if ( GetLocale() == "ruRU") then

XPERL_MSG_PREFIX				= "|c00C05050X-Perl|r "

XPERL_TOOLTIP_ASSISTING			= "Поддержка игрока:"
XPERL_TOOLTIP_HEALERS			= "Целители нацелившись в меня:"
XPERL_TOOLTIP_ALLONME			= "Все нацелы:"
XPERL_TOOLTIP_ENEMYONME			= "Враг нацелившись в меня:"
XPERL_TOOLTIP_HELP				= "Кликни для открытия вида в реальном времени"
XPERL_TOOLTIP_PET				= "%s's пет"

XPERL_LOC_DEAD					= "Мёртв"

XPERL_BUTTON_TOGGLE_LABELS		= "Переключить метка цели"
XPERL_BUTTON_TOGGLE_MTTARGETS	= "Переключить отображение ГТ целей их цели"
XPERL_BUTTON_TOGGLE_SHOWMT		= "Переключить отображение Главных Танков"
XPERL_BUTTON_HELPER_PIN			= "Закрепить Окно"

XPERL_XS_TARGET					= "%s's цель"
XPERL_NO_TARGET					= "нет цели"

XPERL_TITLE_MT_LONG				= "Цели ГТ"
XPERL_TITLE_MT_SHORT			= "ГТ"
XPERL_TITLE_WARRIOR_LONG		= "Цели Войнов"
XPERL_TITLE_WARRIOR_SHORT		= "Танки"

XPERL_HELPER_NEEDPROMOTE		= "У вас не достаточно полномочий для установки Главной поддержки"
XPERL_HELPER_MASET				= "Главная поддержка %s"
XPERL_HELPER_MACLEAR			= "Главная поддержка |c00FF0000очищено!"
XPERL_HELPER_MAREMOVED			= "Главная поддержка %s не нашла танка в списке - удалено!"
XPERL_HELPER_MAREMOTESET		= "%s главная поддержка заданна %s"

XPERL_HELPER_FINDFOUND			= "Используйте НАЙТИ для подходящей цели. ('|c00007F00/xp find|r' для очистки)."
XPERL_HELPER_FINDCLEARED		= "Найти |c00FF0000очищен!|r"
XPERL_HELPER_FINDSET			= "Найти установлен на %s. ('|c00007F00/xp find|r' для очистки)."

XPERL_AGGRO_PLAYER				= "- АГГРО -"
XPERL_AGGRO_PET					= "- АГГРО НА ПИТОМЦЕ -"
XPERL_AGGRO_DRAGTIP				= "Переместить местоположение предупреждения о аггро"

end
