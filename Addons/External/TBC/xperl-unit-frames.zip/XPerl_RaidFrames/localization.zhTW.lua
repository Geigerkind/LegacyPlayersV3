-- Localizations

if (GetLocale() == "zhTW") then


end
