﻿--Файл локализации для ruRU
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("ElvUI", "ruRU")
if not L then return end

L["Player SwingBar"] = true
L["Swing Bar"] = true