﻿-- English localization file for enGB.
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("ElvUI", "enUS", true)
if not L then return end

L["Player SwingBar"] = true
L["Swing Bar"] = true