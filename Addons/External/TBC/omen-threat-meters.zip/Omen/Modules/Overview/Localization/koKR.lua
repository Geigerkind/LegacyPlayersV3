local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("Omen_Overview", "koKR")
if not L then return end

L["Overview Mode"] = "전체 모드"
L["Show raid icons"] = "공격대 아이콘 표시"
L["Overview Mode\n|cffffffffShows an overview of high-threat raid members|r"] = "전체 모드\n|cffffffff높은 어그로를 획득한 공격대원을 표시합니다.|r"
