local locals = KC_ITEMS_LOCALS.modules.iteminfo
local map = KC_ITEMS_LOCALS.maps.enabled
