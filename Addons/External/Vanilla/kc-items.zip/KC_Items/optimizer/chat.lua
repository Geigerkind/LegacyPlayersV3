local locals = KC_ITEMS_LOCALS.modules.optimizer
local map = KC_ITEMS_LOCALS.maps.enabled
