if (GetLocale() == "enUS") then
	BINDING_HEADER_TARGETFC = "Target flag carrier";
	BINDING_NAME_TARGET_ENEMY_FC = "Target enemy flag carrier";
	BINDING_NAME_TARGET_ALLY_FC = "Target ally flag carrier";

elseif (GetLocale() == "frFR") then
	BINDING_HEADER_TARGETFC = "";
	BINDING_NAME_TARGET_ENEMY_FC = "";
	BINDING_NAME_TARGET_ALLY_FC = "";

elseif (GetLocale() == "deDE") then
	BINDING_HEADER_TARGETFC = "";
	BINDING_NAME_TARGET_ENEMY_FC = "";
	BINDING_NAME_TARGET_ALLY_FC = "";
end


