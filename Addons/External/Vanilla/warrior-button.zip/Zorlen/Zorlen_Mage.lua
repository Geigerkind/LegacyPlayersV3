--[[
  Zorlen Library - Started by Marcus S. Zarra

  3.00  Rewrite by Wynn (Bleeding Hollow), break units into class functions.
		  
--]]


