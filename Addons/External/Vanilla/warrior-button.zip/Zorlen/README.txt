Zorlen

A tremendous amount of work has gone into this Library by others as well as myself.  I would like to thank all of those who helped me compile these functions for everyone to use and enjoy.  If you contributed and I forgot to put your name on this list, please accept my apologies and shoot me and email.  I will correct it at once.

Andrew Young
Kunderack
Turtle of Proudmoore
Truelove
Mooferd of Llane
Christopher Schlager
Tom Martin
BigRedBrent
Trevor
Bear
Leica
chazz
Jayphen
Nuckin
Malnyth of Ravencrest
