This addon will return an emote for an emote given. You can set it to where when someone slaps you, you belch, or if someone pokes you, you fart, etc. You can set it up to your heart's desire.

Modification
The only code you may want to change to add new emotes and replies is the emotes table in the LUA file. You have a trigger emote and a reply emote. Every single emote token is set up as a constant, and every single text trigger is set up as a constant. (constants not listed here, but are in the file). Listed here are the default entries into the table when you download it.

EXAMPLE

table.insert(Emotes, { Trigger = POKE, Reply = TOKEN_FART});   -- if someone pokes my character, he/she farts
table.insert(Emotes, { Trigger = HUG, Reply = TOKEN_HELPME}); -- if someone hugs my character, he/she calls for help
table.insert(Emotes, { Trigger = KISS, Reply = TOKEN_DROOL}); 
table.insert(Emotes, { Trigger = SLAP, Reply = TOKEN_BURP}); 
table.insert(Emotes, { Trigger = COWER, Reply = TOKEN_CHICKEN}); 
table.insert(Emotes, { Trigger = FLEX, Reply = TOKEN_GOLFCLAP}); 
table.insert(Emotes, { Trigger = LOL, Reply = TOKEN_GUFFAW}); 
table.insert(Emotes, { Trigger = CRIES, Reply = TOKEN_VIOLIN}); 
table.insert(Emotes, { Trigger = SEXY, Reply = TOKEN_GRIN}); 
table.insert(Emotes, { Trigger = YAWN, Reply = TOKEN_THREATEN});