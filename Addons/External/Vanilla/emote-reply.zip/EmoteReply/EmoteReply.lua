--This addon returns an emote for an emote
--
--
--

--CONSTANTS
--

--EMOTE SEARCHES


--EMOTE TOKENS
TOKEN_AGREE="AGREE"
TOKEN_AMAZE="AMAZE"
TOKEN_ATTACKMYTARGET="ATTACKMYTARGET"
TOKEN_BRB="BRB"
TOKEN_BARK="BARK"
TOKEN_BASHFUL="BASHFUL"
TOKEN_BECKON="BECKON"
TOKEN_BEG="BEG"
TOKEN_BITE="BITE"
TOKEN_BLINK="BLINK"
TOKEN_BLEED="BLEED"
TOKEN_BLUSH="BLUSH"
TOKEN_BOGGLE="BOGGLE"
TOKEN_BORED="BORED"
TOKEN_BOUNCE="BOUNCE"
TOKEN_BOW="BOW"
TOKEN_APPLAUD="APPLAUD"
TOKEN_BURP="BURP"
TOKEN_CACKLE="CACKLE"
TOKEN_CALM="CALM"
TOKEN_CHARGE="CHARGE"
TOKEN_CHEER="CHEER"
TOKEN_CHUCKLE="CHUCKLE"
TOKEN_CLAP="CLAP"
TOKEN_COLD="COLD"
TOKEN_COMFORT="COMFORT"
TOKEN_COMMEND="COMMEND"
TOKEN_CONFUSED="CONFUSED"
TOKEN_CONGRATULATE="CONGRATULATE"
TOKEN_COUGH="COUGH"
TOKEN_CRACK="CRACK"
TOKEN_CRINGE="CRINGE"
TOKEN_CUDDLE="CUDDLE"
TOKEN_CURIOUS="CURIOUS"
TOKEN_CURTSEY="CURTSEY"
TOKEN_DANCE="DANCE"
TOKEN_FROWN="FROWN"
TOKEN_BONK="BONK"
TOKEN_DRINK="DRINK"
TOKEN_DROOL="DROOL"
TOKEN_DUCK="DUCK"
TOKEN_EAT="EAT"
TOKEN_TALKEX="TALKEX"
TOKEN_EYE="EYE"
TOKEN_FART="FART"
TOKEN_COWER="COWER"
TOKEN_FIDGET="FIDGET"
TOKEN_FLEE="FLEE"
TOKEN_FLEX="FLEX"
TOKEN_FLIRT="FLIRT"
TOKEN_FLOP="FLOP"
TOKEN_FOLLOW="FOLLOW"
TOKEN_GAST="GAST"
TOKEN_GAZE="GAZE"
TOKEN_GIGGLE="GIGGLE"
TOKEN_GLARE="GLARE"
TOKEN_GLOAT="GLOAT"
TOKEN_BYE="BYE"
TOKEN_GREET="GREET"
TOKEN_GROAN="GROAN"
TOKEN_GROVEL="GROVEL"
TOKEN_GROWL="GROWL"
TOKEN_GUFFAW="GUFFAW"
TOKEN_HAIL="HAIL"
TOKEN_HAPPY="HAPPY"
TOKEN_HEALME="HEALME"
TOKEN_HELLO="HELLO"
TOKEN_HELPME="HELPME"
TOKEN_HUG="HUG"
TOKEN_HUNGRY="HUNGRY"
TOKEN_INCOMING="INCOMING"
TOKEN_INTRODUCE="INTRODUCE"
TOKEN_JOKE="JOKE"
TOKEN_JK="JK"
TOKEN_KISS="KISS"
TOKEN_KNEEL="KNEEL"
TOKEN_LAUGH="LAUGH"
TOKEN_ROFL="ROFL"
TOKEN_LISK="LISK"
TOKEN_LAYDOWN="LAYDOWN"
TOKEN_LISTEN="LISTEN"
TOKEN_LOST="LOST"
TOKEN_LOVE="LOVE"
TOKEN_ANGRY="ANGRY"
TOKEN_OOM="OOM"
TOKEN_MASSAGE="MASSAGE"
TOKEN_MOAN="MOAN"
TOKEN_MOCK="MOCK"
TOKEN_MOO="MOO"
TOKEN_MOON="MOON"
TOKEN_INSULT="INSULT"
TOKEN_MOURN="MOURN"
TOKEN_NO="NO"
TOKEN_NOD="NOD"
TOKEN_OPENFIRE="OPENFIRE"
TOKEN_PANIC="PANIC"
TOKEN_PAT="PAT"
TOKEN_PEER="PEER"
TOKEN_SHOO="SHOO"
TOKEN_NOSEPICK="NOSEPICK"
TOKEN_PITY="PITY"
TOKEN_PLEAD="PLEAD"
TOKEN_POINT="POINT"
TOKEN_POKE="POKE"
TOKEN_PONDER="PONDER"
TOKEN_POUNCE="POUNCE"
TOKEN_PRAISE="PRAISE"
TOKEN_PRAY="PRAY"
TOKEN_PURR="PURR"
TOKEN_PUZZLE="PUZZLE"
TOKEN_TALKQ="TALKQ"
TOKEN_RAISE="RAISE"
TOKEN_READY="READY"
TOKEN_ROAR="ROAR"
TOKEN_RASP="RASP"
TOKEN_SALUTE="SALUTE"
TOKEN_SCARED="SCARED"
TOKEN_SCRATCH="SCRATCH"
TOKEN_SEXY="SEXY"
TOKEN_SHAKE="SHAKE"
TOKEN_SHIMMY="SHIMMY"
TOKEN_SHIVER="SHIVER"
TOKEN_SHRUG="SHRUG"
TOKEN_SHY="SHY"
TOKEN_SIGH="SIGH"
TOKEN_SLAP="SLAP"
TOKEN_SLEEP="SLEEP"
TOKEN_SMILE="SMILE"
TOKEN_SMIRK="SMIRK"
TOKEN_SNICKER="SNICKER"
TOKEN_SNIFF="SNIFF"
TOKEN_SNUB="SNUB"
TOKEN_SOOTHE="SOOTHE"
TOKEN_APOLOGIZE  ="APOLOGIZE  "
TOKEN_SPIT="SPIT"
TOKEN_STAND="STAND"
TOKEN_STARE="STARE"
TOKEN_STINK="STINK"
TOKEN_CHICKEN="CHICKEN"
TOKEN_SURPRISED="SURPRISED"
TOKEN_SURRENDER="SURRENDER"
TOKEN_TALK="TALK"
TOKEN_TAP="TAP"
TOKEN_TAUNT="TAUNT"
TOKEN_TEASE="TEASE"
TOKEN_THANK="THANK"
TOKEN_THIRSTY="THIRSTY"
TOKEN_TICKLE="TICKLE"
TOKEN_TIRED="TIRED"
TOKEN_TRAIN="TRAIN"
TOKEN_GOLFCLAP="GOLFCLAP"
TOKEN_VETO="VETO"
TOKEN_VICTORY="VICTORY"
TOKEN_VIOLIN="VIOLIN"
TOKEN_WAIT="WAIT"
TOKEN_WAVE="WAVE"
TOKEN_CRY="CRY"
TOKEN_WELCOME="WELCOME"
TOKEN_WHINE="WHINE"
TOKEN_WHISTLE="WHISTLE"
TOKEN_GRIN="GRIN"
TOKEN_WINK="WINK"
TOKEN_WORK="WORK"
TOKEN_THREATEN="THREATEN"
TOKEN_YAWN="YAWN"

--search strings
AGREE="agree"
AMAZE="amaze"
ATTACKTARGET="attack"
BRB="back"
BARK="bark"
BASHFUL="bashful"
BECKON="beckon"
BEG="beg"
BITE="bite"
BLINK="blink"
BLOOD="blood"
BLUSH="blush"
BOGGLE="boggle"
BORED="bored"
BOUNCE="bounce"
BOW="bow"
BRAVO="bravo"
BURP="burp"
CACKLE="cackle"
CALM="calm"
CHARGE="charge"
CHEER="cheer"
CHUCKLE="chuckle"
CLAP="clap"
COLD="cold"
COMFORT="comfort"
COMMEND="commend"
CONFUSED="confused"
CONG="cong"
COUGH="cough"
COWER="cowers"
CRACK="crack"
CRIES="cries"
CRINGE="cringe"
CUDDLE="cuddle"
CURIOUS="curious"
CURTSEY="curtsey"
DANCE="dance"
DISAPPOINTED="disappointed"
DOH="doh"
SHINDIG="drink"
DROOL="drool"
DUCK="duck"
FEAST="eat"
EXCITED="excited"
EYE="eye"
FART="fart"
FEAR="fear"
FIDGET="fidgets"
FLEE="flees"
FLEX="flexes"
FLIRT="flirt"
FLOP="flop"
FOLLOWME="follow"
GASP="gasp"
GAZE="gaze"
GIGGLE="giggle"
GLARE="glare"
GLOAT="gloat"
GOODBYE="goodbye"
GREET="greet"
GROAN="groan"
GROVEL="grovel"
GROWL="growl"
GUFFAW="guffaw"
HAIL="hail"
YAY="happiness"
HEALME="healing"
HI="hello"
HELPME="help"
HUG="hug"
PIZZA="hungry"
INCOMING="incoming"
INTRODUCE="introduce"
SILLY="joke"
JK="kidding"
KISS="kiss"
KNEEL="kneel"
LOL="laughs"
ROFL="laughing"
LICK="lick"
LIE="lie"
LISTEN="listen"
LOST="lost"
LOVE="love"
MAD="mad"
OOM="mana"
MASSAGE="massage"
MOAN="moan"
MOCK="mock"
MOO="Mooooooooooo"
MOON="moon"
INSULT="motherless"
MOURN="mourn"
NO="Not going to happen"
YES="nod"
OPENFIRE="openfire"
PANIC="panic"
PAT="pat"
PEER="peer"
PEST="pest"
PICK="pick"
PITY="pity"
PLEAD="plead"
POINT="point"
POKE="poke"
PONDER="ponder"
POUNCE="pounce"
PRAISE="praise"
PRAY="pray"
PURR="purr"
PUZZLED="puzzled"
QUESTION="question"
RAISE="raise"
RDY="ready"
ROAR="roar"
RASP="rude"
SALUTE="salute"
SCARED="scared"
SCRATCH="scratch"
SEXY="sexy"
SHAKE="shake"
SHIMMY="shimmy"
SHIVER="shiver"
SHRUG="shrug"
SHY="shy"
SIGH="sigh"
SLAP="slap"
SLEEP="sleep"
SMILE="smile"
SMIRK="snarl"
SNICKER="snicker"
SNIFF="sniff"
SNUB="snub"
SOOTHE="soothe"
SORRY="sorry"
SPIT="spit"
STAND="stand"
STARE="stare"
STINK="stink"
STRUT="strut"
SURPRISED="surprised"
SURRENDER="surrender"
TALK="talk"
TAP="tap"
TAUNT="taunt"
TEASE="tease"
THANK="thank"
THIRSTY="thirsty"
TICKLE="tickle"
TIRED="tired"
TRAIN="train"
GOLFCLAP="unimpressed"
VETO="veto"
VICTORY="victory"
VIOLIN="violin"
WAIT="wait"
WAVE="wave"
WEEP="weep"
WELCOME="welcome"
WHINE="whine"
WHISTLE="whistle"
WICKED="wicked"
WINK="wink"
WORK="work"
WRATH="wrath"
YAWN="yawn"




--TABLES ---------------
--
Emotes = {};
table.insert( Emotes,{ Trigger = YES, Reply = TOKEN_AGREE});table.insert( Emotes,{ Trigger = YAY, Reply = TOKEN_AMAZE});table.insert( Emotes,{ Trigger = YAWN, Reply = TOKEN_ANGRY});table.insert( Emotes,{ Trigger = WRATH, Reply = TOKEN_APOLOGIZE  });table.insert( Emotes,{ Trigger = WORK, Reply = TOKEN_APPLAUD});table.insert( Emotes,{ Trigger = WINK, Reply = TOKEN_ATTACKMYTARGET});table.insert( Emotes,{ Trigger = WICKED, Reply = TOKEN_BARK});table.insert( Emotes,{ Trigger = WHISTLE, Reply = TOKEN_BASHFUL});table.insert( Emotes,{ Trigger = WHINE, Reply = TOKEN_BECKON});table.insert( Emotes,{ Trigger = WELCOME, Reply = TOKEN_BEG});table.insert( Emotes,{ Trigger = WEEP, Reply = TOKEN_BITE});table.insert( Emotes,{ Trigger = WAVE, Reply = TOKEN_BLEED});table.insert( Emotes,{ Trigger = WAIT, Reply = TOKEN_BLINK});table.insert( Emotes,{ Trigger = VIOLIN, Reply = TOKEN_BLUSH});table.insert( Emotes,{ Trigger = VICTORY, Reply = TOKEN_BOGGLE});table.insert( Emotes,{ Trigger = VETO, Reply = TOKEN_BONK});table.insert( Emotes,{ Trigger = TRAIN, Reply = TOKEN_BORED});table.insert( Emotes,{ Trigger = TIRED, Reply = TOKEN_BOUNCE});table.insert( Emotes,{ Trigger = TICKLE, Reply = TOKEN_BOW});table.insert( Emotes,{ Trigger = THIRSTY, Reply = TOKEN_BRB});table.insert( Emotes,{ Trigger = THANK, Reply = TOKEN_BURP});table.insert( Emotes,{ Trigger = TEASE, Reply = TOKEN_BYE});table.insert( Emotes,{ Trigger = TAUNT, Reply = TOKEN_CACKLE});table.insert( Emotes,{ Trigger = TAP, Reply = TOKEN_CALM});table.insert( Emotes,{ Trigger = TALK, Reply = TOKEN_CHARGE});table.insert( Emotes,{ Trigger = SURRENDER, Reply = TOKEN_CHEER});table.insert( Emotes,{ Trigger = SURPRISED, Reply = TOKEN_CHICKEN});table.insert( Emotes,{ Trigger = STRUT, Reply = TOKEN_CHUCKLE});table.insert( Emotes,{ Trigger = STINK, Reply = TOKEN_CLAP});table.insert( Emotes,{ Trigger = STARE, Reply = TOKEN_COLD});table.insert( Emotes,{ Trigger = STAND, Reply = TOKEN_COMFORT});table.insert( Emotes,{ Trigger = SPIT, Reply = TOKEN_COMMEND});table.insert( Emotes,{ Trigger = SORRY, Reply = TOKEN_CONFUSED});table.insert( Emotes,{ Trigger = SOOTHE, Reply = TOKEN_CONGRATULATE});table.insert( Emotes,{ Trigger = SNUB, Reply = TOKEN_COUGH});table.insert( Emotes,{ Trigger = SNIFF, Reply = TOKEN_COWER});table.insert( Emotes,{ Trigger = SNICKER, Reply = TOKEN_CRACK});table.insert( Emotes,{ Trigger = SMIRK, Reply = TOKEN_CRINGE});table.insert( Emotes,{ Trigger = SMILE, Reply = TOKEN_CRY});table.insert( Emotes,{ Trigger = SLEEP, Reply = TOKEN_CUDDLE});table.insert( Emotes,{ Trigger = SLAP, Reply = TOKEN_CURIOUS});table.insert( Emotes,{ Trigger = SILLY, Reply = TOKEN_CURTSEY});table.insert( Emotes,{ Trigger = SIGH, Reply = TOKEN_DANCE});table.insert( Emotes,{ Trigger = SHY, Reply = TOKEN_DRINK});table.insert( Emotes,{ Trigger = SHRUG, Reply = TOKEN_DROOL});table.insert( Emotes,{ Trigger = SHIVER, Reply = TOKEN_DUCK});table.insert( Emotes,{ Trigger = SHINDIG, Reply = TOKEN_EAT});table.insert( Emotes,{ Trigger = SHIMMY, Reply = TOKEN_EYE});table.insert( Emotes,{ Trigger = SHAKE, Reply = TOKEN_FART});table.insert( Emotes,{ Trigger = SEXY, Reply = TOKEN_FIDGET});table.insert( Emotes,{ Trigger = SCRATCH, Reply = TOKEN_FLEE});table.insert( Emotes,{ Trigger = SCARED, Reply = TOKEN_FLEX});table.insert( Emotes,{ Trigger = SALUTE, Reply = TOKEN_FLIRT});table.insert( Emotes,{ Trigger = ROFL, Reply = TOKEN_FLOP});table.insert( Emotes,{ Trigger = ROAR, Reply = TOKEN_FOLLOW});table.insert( Emotes,{ Trigger = RDY, Reply = TOKEN_FROWN});table.insert( Emotes,{ Trigger = RASP, Reply = TOKEN_GAST});table.insert( Emotes,{ Trigger = RAISE, Reply = TOKEN_GAZE});table.insert( Emotes,{ Trigger = QUESTION, Reply = TOKEN_GIGGLE});table.insert( Emotes,{ Trigger = PUZZLED, Reply = TOKEN_GLARE});table.insert( Emotes,{ Trigger = PURR, Reply = TOKEN_GLOAT});table.insert( Emotes,{ Trigger = PRAY, Reply = TOKEN_GOLFCLAP});table.insert( Emotes,{ Trigger = PRAISE, Reply = TOKEN_GREET});table.insert( Emotes,{ Trigger = POUNCE, Reply = TOKEN_GRIN});table.insert( Emotes,{ Trigger = PONDER, Reply = TOKEN_GROAN});table.insert( Emotes,{ Trigger = POKE, Reply = TOKEN_GROVEL});table.insert( Emotes,{ Trigger = POINT, Reply = TOKEN_GROWL});table.insert( Emotes,{ Trigger = PLEAD, Reply = TOKEN_GUFFAW});table.insert( Emotes,{ Trigger = PIZZA, Reply = TOKEN_HAIL});table.insert( Emotes,{ Trigger = PITY, Reply = TOKEN_HAPPY});table.insert( Emotes,{ Trigger = PICK, Reply = TOKEN_HEALME});table.insert( Emotes,{ Trigger = PEST, Reply = TOKEN_HELLO});table.insert( Emotes,{ Trigger = PEER, Reply = TOKEN_HELPME});table.insert( Emotes,{ Trigger = PAT, Reply = TOKEN_HUG});table.insert( Emotes,{ Trigger = PANIC, Reply = TOKEN_HUNGRY});table.insert( Emotes,{ Trigger = OPENFIRE, Reply = TOKEN_INCOMING});table.insert( Emotes,{ Trigger = OOM, Reply = TOKEN_INSULT});table.insert( Emotes,{ Trigger = NO, Reply = TOKEN_INTRODUCE});table.insert( Emotes,{ Trigger = MOURN, Reply = TOKEN_MOON});table.insert( Emotes,{ Trigger = MOON, Reply = TOKEN_JOKE});table.insert( Emotes,{ Trigger = MOO, Reply = TOKEN_KISS});table.insert( Emotes,{ Trigger = MOCK, Reply = TOKEN_KNEEL});table.insert( Emotes,{ Trigger = MOAN, Reply = TOKEN_LAUGH});table.insert( Emotes,{ Trigger = MASSAGE, Reply = TOKEN_LAYDOWN});table.insert( Emotes,{ Trigger = MAD, Reply = TOKEN_LISK});table.insert( Emotes,{ Trigger = LOVE, Reply = TOKEN_LISTEN});table.insert( Emotes,{ Trigger = LOL, Reply = TOKEN_LOST});table.insert( Emotes,{ Trigger = LOST, Reply = TOKEN_LOVE});table.insert( Emotes,{ Trigger = LISTEN, Reply = TOKEN_MASSAGE});table.insert( Emotes,{ Trigger = LIE, Reply = TOKEN_MOAN});table.insert( Emotes,{ Trigger = LICK, Reply = TOKEN_MOCK});table.insert( Emotes,{ Trigger = KNEEL, Reply = TOKEN_MOO});table.insert( Emotes,{ Trigger = KISS, Reply = TOKEN_MOON});table.insert( Emotes,{ Trigger = JK, Reply = TOKEN_MOURN});table.insert( Emotes,{ Trigger = INTRODUCE, Reply = TOKEN_NO});table.insert( Emotes,{ Trigger = INSULT, Reply = TOKEN_NOD});table.insert( Emotes,{ Trigger = INCOMING, Reply = TOKEN_NOSEPICK});table.insert( Emotes,{ Trigger = HUG, Reply = TOKEN_OOM});table.insert( Emotes,{ Trigger = HI, Reply = TOKEN_OPENFIRE});table.insert( Emotes,{ Trigger = HELPME, Reply = TOKEN_PANIC});table.insert( Emotes,{ Trigger = HEALME, Reply = TOKEN_PAT});table.insert( Emotes,{ Trigger = HAIL, Reply = TOKEN_PEER});table.insert( Emotes,{ Trigger = GUFFAW, Reply = TOKEN_PITY});table.insert( Emotes,{ Trigger = GROWL, Reply = TOKEN_PLEAD});table.insert( Emotes,{ Trigger = GROVEL, Reply = TOKEN_POINT});table.insert( Emotes,{ Trigger = GROAN, Reply = TOKEN_POKE});table.insert( Emotes,{ Trigger = GREET, Reply = TOKEN_PONDER});table.insert( Emotes,{ Trigger = GOODBYE, Reply = TOKEN_POUNCE});table.insert( Emotes,{ Trigger = GOLFCLAP, Reply = TOKEN_PRAISE});table.insert( Emotes,{ Trigger = GLOAT, Reply = TOKEN_PRAY});table.insert( Emotes,{ Trigger = GLARE, Reply = TOKEN_PURR});table.insert( Emotes,{ Trigger = GIGGLE, Reply = TOKEN_PUZZLE});table.insert( Emotes,{ Trigger = GAZE, Reply = TOKEN_RAISE});table.insert( Emotes,{ Trigger = GASP, Reply = TOKEN_RASP});table.insert( Emotes,{ Trigger = FOLLOWME, Reply = TOKEN_READY});table.insert( Emotes,{ Trigger = FLOP, Reply = TOKEN_ROAR});table.insert( Emotes,{ Trigger = FLIRT, Reply = TOKEN_ROFL});table.insert( Emotes,{ Trigger = FLEX, Reply = TOKEN_SALUTE});table.insert( Emotes,{ Trigger = FLEE, Reply = TOKEN_SCARED});table.insert( Emotes,{ Trigger = FIDGET, Reply = TOKEN_SCRATCH});table.insert( Emotes,{ Trigger = FEAST, Reply = TOKEN_SEXY});table.insert( Emotes,{ Trigger = FEAR, Reply = TOKEN_SHAKE});table.insert( Emotes,{ Trigger = FART, Reply = TOKEN_SHIMMY});table.insert( Emotes,{ Trigger = EYE, Reply = TOKEN_SHIVER});table.insert( Emotes,{ Trigger = EXCITED, Reply = TOKEN_SHOO});table.insert( Emotes,{ Trigger = DUCK, Reply = TOKEN_SHRUG});table.insert( Emotes,{ Trigger = DROOL, Reply = TOKEN_SHY});table.insert( Emotes,{ Trigger = DOH, Reply = TOKEN_SIGH});table.insert( Emotes,{ Trigger = DISAPPOINTED, Reply = TOKEN_SLAP});table.insert( Emotes,{ Trigger = DANCE, Reply = TOKEN_SLEEP});table.insert( Emotes,{ Trigger = CURTSEY, Reply = TOKEN_SMILE});table.insert( Emotes,{ Trigger = CURIOUS, Reply = TOKEN_SMIRK});table.insert( Emotes,{ Trigger = CUDDLE, Reply = TOKEN_SNICKER});table.insert( Emotes,{ Trigger = CRINGE, Reply = TOKEN_SNIFF});table.insert( Emotes,{ Trigger = CRIES, Reply = TOKEN_SNUB});table.insert( Emotes,{ Trigger = CRACK, Reply = TOKEN_SOOTHE});table.insert( Emotes,{ Trigger = COWER, Reply = TOKEN_SPIT});table.insert( Emotes,{ Trigger = COUGH, Reply = TOKEN_STAND});table.insert( Emotes,{ Trigger = CONG, Reply = TOKEN_STARE});table.insert( Emotes,{ Trigger = CONFUSED, Reply = TOKEN_STINK});table.insert( Emotes,{ Trigger = COMMEND, Reply = TOKEN_SURPRISED});table.insert( Emotes,{ Trigger = COMFORT, Reply = TOKEN_SURRENDER});table.insert( Emotes,{ Trigger = COLD, Reply = TOKEN_TALK});table.insert( Emotes,{ Trigger = CLAP, Reply = TOKEN_TALKEX});table.insert( Emotes,{ Trigger = CHUCKLE, Reply = TOKEN_TALKQ});table.insert( Emotes,{ Trigger = CHEER, Reply = TOKEN_TAP});table.insert( Emotes,{ Trigger = CHARGE, Reply = TOKEN_TAUNT});table.insert( Emotes,{ Trigger = CALM, Reply = TOKEN_TEASE});table.insert( Emotes,{ Trigger = CACKLE, Reply = TOKEN_THANK});table.insert( Emotes,{ Trigger = BURP, Reply = TOKEN_THIRSTY});table.insert( Emotes,{ Trigger = BRB, Reply = TOKEN_THREATEN});table.insert( Emotes,{ Trigger = BRAVO, Reply = TOKEN_TICKLE});table.insert( Emotes,{ Trigger = BOW, Reply = TOKEN_TIRED});table.insert( Emotes,{ Trigger = BOUNCE, Reply = TOKEN_TRAIN});table.insert( Emotes,{ Trigger = BORED, Reply = TOKEN_VETO});table.insert( Emotes,{ Trigger = BOGGLE, Reply = TOKEN_VICTORY});table.insert( Emotes,{ Trigger = BLUSH, Reply = TOKEN_VIOLIN});table.insert( Emotes,{ Trigger = BLOOD, Reply = TOKEN_WAIT});table.insert( Emotes,{ Trigger = BLINK, Reply = TOKEN_WAVE});table.insert( Emotes,{ Trigger = BITE, Reply = TOKEN_WELCOME});table.insert( Emotes,{ Trigger = BEG, Reply = TOKEN_WHINE});table.insert( Emotes,{ Trigger = BECKON, Reply = TOKEN_WHISTLE});table.insert( Emotes,{ Trigger = BASHFUL, Reply = TOKEN_WINK});table.insert( Emotes,{ Trigger = BARK, Reply = TOKEN_WORK});table.insert( Emotes,{ Trigger = ATTACKTARGET, Reply = TOKEN_YAWN});


--loaded when the lua file is loaded
--
function EmoteReply_OnLoad()

	this:RegisterEvent("CHAT_MSG_TEXT_EMOTE");
	this:RegisterEvent("CHAT_MSG_WHISPER");

	--display on load
	--
	DEFAULT_CHAT_FRAME:AddMessage("Emote Reply Version 1.05 Loaded");

end


function EmoteReply_OnEvent()
	if (event == "CHAT_MSG_TEXT_EMOTE") then
		foreach(Emotes, 
			function(k,v)
				if (string.find(arg1, v.Trigger)) then
					if (string.find(arg1, "you")) then
						DoEmote(v.Reply,true);
					end
					return;
				end
			end
		);
	end
end