-- 
local L = AceLibrary("AceLocale-2.0"):new("BuddySync")
-- 
L:RegisterTranslations("frFR", function()
    return {
        ["BS_PLAYER_NOT_FOUND_A"] = " ... semble ne plus exister sur ",
        ["BS_PLAYER_NOT_FOUND_B"] = " et a \195\169t\195\169 effac\195\169 de la base. ",
        ["BS_PLAYER_NOT_FOUND_I"] = " ... n'est pas en ligne, ou plus sur ",
    }
end)
-- -- 
--    � : \195\160    � : \195\168    � : \195\172    � : \195\178    � : \195\185   � : \195\132
--    � : \195\161    � : \195\169    � : \195\173    � : \195\179    � : \195\186   � : \195\150
--    � : \195\162    � : \195\170    � : \195\174    � : \195\180    � : \195\187   � : \195\156
--    � : \195\163    � : \195\171    � : \195\175    � : \195\181    � : \195\188   � : \195\159
--    � : \195\164                    � : \195\177    � : \195\182
--    � : \195\166                                    � : \195\184
--    � : \195\167
-- -- 