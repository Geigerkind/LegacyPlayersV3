-- Chinese text strings

if(GetLocale()=="zhCN") then

MAILTO_TOOLTIP =    "点击选择收件人";
MAILTO_CLEARED =    "收件人列表已被清除";
MAILTO_LISTEMPTY =  "空的收件人列表";
MAILTO_LISTFULL =   "警告:收件人列表已满";
MAILTO_ADDED =      " 添加到收件人列表";
MAILTO_REMOVED =    "从收件人列表中移除";
MAILTO_F_ADD =      "(添加 %s)";
MAILTO_F_REMOVE =   "(移除 %s)";
MAILTO_YOU =        "你";
MAILTO_DELIVERED =  "已发送.";
MAILTO_DUE =        "%d 分钟之前.";
MAILTO_SENT =       "%s 发送给 %s , 发送自 %s , %s";
MAILTO_LOGEMPTY =   "邮件日志是空的.";
MAILTO_NODATA =     "收件箱里没有信件.";
MAILTO_NOITEMS =    "收件箱里没有物品.";
MAILTO_INBOX =      "#%d, %s, 发送自 %s";
MAILTO_EXPIRES =    " 时效 ";

end
