-- Version : German ( by Isakur )
-- last update : 

if ( GetLocale() == "deDE" ) then
	ISMOUNTED_SPEED_INCREASED_BY = "Erh\195\182ht Tempo um (%d+)%%.";
end