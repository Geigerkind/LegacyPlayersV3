# Postal

> Postal for easier mailbox management in WoW.

## Features

* Auto mail opening
* Multiple attachments

## Authors

shirsig
