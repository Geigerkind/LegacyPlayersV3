-- Version : Chinese

if ( GetLocale() == "zhCN" ) then

CLICKHEAL_BANDAGE = {

  ActionTypeText = '绷带';

  LinenBandage          = '亚麻绷带';
  HeavyLinenBandage     = '厚亚麻绷带';
  WoolBandage           = '绒线绷带';
  HeavyWoolBandage      = '厚绒线绷带';
  SilkBandage           = '丝质绷带';
  HeavySilkBandage      = '厚丝质绷带';
  MageweaveBandage      = '魔纹绷带';
  HeavyMageweaveBandage = '厚魔纹绷带';
  RuneclothBandage      = '符文布绷带';
  HeavyRuneclothBandage = '厚符文布绷带';

  MsgNoBandageFound     = '没发现有绷带。';

};

end
