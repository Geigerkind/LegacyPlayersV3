-- Version : Chinese

if ( GetLocale() == "zhTW" ) then

CLICKHEAL_BANDAGE = {

  ActionTypeText = '繃帶';

  LinenBandage          = '亞麻繃帶';
  HeavyLinenBandage     = '厚亞麻繃帶';
  WoolBandage           = '絨線繃帶';
  HeavyWoolBandage      = '厚絨線繃帶';
  SilkBandage           = '絲質繃帶';
  HeavySilkBandage      = '厚絲質繃帶';
  MageweaveBandage      = '魔紋繃帶';
  HeavyMageweaveBandage = '厚魔紋繃帶';
  RuneclothBandage      = '符文布繃帶';
  HeavyRuneclothBandage = '厚符文布繃帶';

  MsgNoBandageFound     = '沒發現有繃帶。';

};

end
