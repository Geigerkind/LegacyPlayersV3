-- Version : French

if ( GetLocale() == "frFR" ) then

CLICKHEAL_BANDAGE = {

  ActionTypeText = 'Bandage';

  LinenBandage          = 'Bandage en lin';
  HeavyLinenBandage     = 'Bandage \195\169pais en lin';
  WoolBandage           = 'Bandage en laine';
  HeavyWoolBandage      = 'Bandage \195\169pais en laine';
  SilkBandage           = 'Bandage en soie';
  HeavySilkBandage      = 'Bandage \195\169pais en soie';
  MageweaveBandage      = 'Bandage en tissu de mage';
  HeavyMageweaveBandage = 'Bandage \195\169pais en tissu de mage';
  RuneclothBandage      = 'Bandage en \195\169toffe runique';
  HeavyRuneclothBandage = 'Bandage \195\169pais en \195\169toffe runique';

  MsgNoBandageFound     = 'Aucun bandage trouv\195\169.';
};

-- localization fr
end
