-- Version : English

CLICKHEAL_BANDAGE = {

  ActionTypeText = 'Bandage';

  LinenBandage          = 'Linen Bandage';
  HeavyLinenBandage     = 'Heavy Linen Bandage';
  WoolBandage           = 'Wool Bandage';
  HeavyWoolBandage      = 'Heavy Wool Bandage';
  SilkBandage           = 'Silk Bandage';
  HeavySilkBandage      = 'Heavy Silk Bandage';
  MageweaveBandage      = 'Mageweave Bandage';
  HeavyMageweaveBandage = 'Heavy Mageweave Bandage';
  RuneclothBandage      = 'Runecloth Bandage';
  HeavyRuneclothBandage = 'Heavy Runecloth Bandage';

  MsgNoBandageFound     = 'No bandage found.';

};
