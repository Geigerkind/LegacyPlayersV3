-- Version : German

if ( GetLocale() == "deDE" ) then

CLICKHEAL_BANDAGE = {

  ActionTypeText = 'Bandage';

  LinenBandage          = 'Leinenverband';
  HeavyLinenBandage     = 'Schwerer Leinenverband';
  WoolBandage           = 'Wollverband';
  HeavyWoolBandage      = 'Schwerer Wollverband';
  SilkBandage           = 'Seidenverband';
  HeavySilkBandage      = 'Schwerer Seidenverband';
  MageweaveBandage      = 'Magiestoffverband';
  HeavyMageweaveBandage = 'Schwerer Magiestoffverband';
  RuneclothBandage      = 'Runenstoffverband';
  HeavyRuneclothBandage = 'Schwerer Runenstoffverband';

  MsgNoBandageFound     = 'Keine Verb\195\164nde vorhanden!';

};

-- localization deDE
end
