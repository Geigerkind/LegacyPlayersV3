-- Version : Korean

if (GetLocale() == "koKR") then
	CLICKHEAL_BANDAGE = {

	  ActionTypeText = '붕대';

	  LinenBandage          = '리넨 붕대';
	  HeavyLinenBandage     = '두꺼운 리넨 붕대';
	  WoolBandage           = '양모 붕대';
	  HeavyWoolBandage      = '두꺼운 양모 붕대';
	  SilkBandage           = '비단 붕대';
	  HeavySilkBandage      = '두꺼운 비단 붕대';
	  MageweaveBandage      = '마법 붕대';
	  HeavyMageweaveBandage = '두꺼운 마법 붕대';
	  RuneclothBandage      = '룬매듭 붕대';
	  HeavyRuneclothBandage = '두꺼운 룬매듭 붕대';

	  MsgNoBandageFound     = '붕대가 없습니다.';

	};
end
