-- Version : French

if ( GetLocale() == "frFR" ) then

CLICKHEAL_SHAPESHIFT = {

  ActionTypeText = 'Shapeshift';

  -- the labels of the drop down
  FormBear       = "Forme d\'ours (redoutable)";
  FormCat        = "Forme de f\195\169lin";
  FormAquatic    = "Forme aquatique";
  FormTravel     = "Forme de voyage";

  -- regular expression for the buff names
  PatternBear    = "ours";
  PatternCat     = "f\195\169lin";
  PatternAquatic = "aquatique";
  PatternTravel  = "voyage";

};

-- localization fr
end
