-- Version : English

CLICKHEAL_SHAPESHIFT = {

  ActionTypeText = 'Shapeshift';

  -- the labels of the drop down
  FormBear       = "(Dire) Bear Form";
  FormCat        = "Cat Form";
  FormAquatic    = "Aquatic Form";
  FormTravel     = "Travel Form";

  -- regular expression for the buff names
  PatternBear    = "Bear";
  PatternCat     = "Cat";
  PatternAquatic = "Aquatic";
  PatternTravel  = "Travel";

};
