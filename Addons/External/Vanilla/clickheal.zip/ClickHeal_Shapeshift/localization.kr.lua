-- Version : Korean

if (GetLocale() == "koKR" ) then

CLICKHEAL_SHAPESHIFT = {

  ActionTypeText = '변신';

  -- the labels of the drop down
  FormBear       = "(광포한) 곰 변신";
  FormCat        = "표범 변신";
  FormAquatic    = "물개 변신";
  FormTravel     = "치타 변신";

  -- regular expression for the buff names
  PatternBear    = "곰 변신";
  PatternCat     = "표범 변신";
  PatternAquatic = "물개 변신";
  PatternTravel  = "치타 변신";

};

end
