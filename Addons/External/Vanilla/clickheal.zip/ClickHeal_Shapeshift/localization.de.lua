-- Version : German

if ( GetLocale() == "deDE" ) then

CLICKHEAL_SHAPESHIFT = {

  ActionTypeText = 'Gestaltwandel';

  -- the labels of the drop down
  FormBear       = "(Terror) B\195\164rengestalt";
  FormCat        = "Katzengestalt";
  FormAquatic    = "Wassergestalt";
  FormTravel     = "Reisegestalt";

  -- regular expression for the buff names
  PatternBear    = "B\195\164r";
  PatternCat     = "Katze";
  PatternAquatic = "Wasser";
  PatternTravel  = "Reise";

};

-- localization deDE
end
