-- Version : Chinese

if ( GetLocale() == "zhTW" ) then

CLICKHEAL_TOTEMKILLER = {

  ActionTypeText = '圖騰殺手';

  MsgNoWandEquipped = '不能移除圖騰，沒有裝備魔杖';
  MsgNoBowEquipped = '不能移除圖騰，沒有裝備弓/槍或是投擲武器';

};

end
