-- Version : French

if ( GetLocale() == "frFR" ) then

CLICKHEAL_TOTEMKILLER = {

  ActionTypeText = 'Totem Killer';

  MsgNoWandEquipped = 'Impossible de d\195\169truire le totem, aucune baguette \195\169quip\195\169e.';
  MsgNoBowEquipped = 'Impossible de d\195\169truire le totem, no bow, gun or thrown weapon equipped.';

};

-- localization fr
end
