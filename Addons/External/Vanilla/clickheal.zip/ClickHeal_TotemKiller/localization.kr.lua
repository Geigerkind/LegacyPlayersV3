-- Version : Korean

if (GetLocale() == "koKR") then

CLICKHEAL_TOTEMKILLER = {

	ActionTypeText = '토템 킬러';

	MsgNoWandEquipped = '토템을 부실 수 없습니다. 마법봉을 착용하고 있지 않습니다.';
	MsgNoBowEquipped = '토템을 부실 수 없습니다. 활,총 등의 원거리 무기를 착용하기 있지 않습니다.';
};

end
