-- Version : English

CLICKHEAL_TOTEMKILLER = {

  ActionTypeText = 'Totem Killer';

  MsgNoWandEquipped = 'Cannot nuke totem, no wand equipped.';
  MsgNoBowEquipped = 'Cannot nuke totem, no bow, gun or thrown weapon equipped.';

};
