-- Version : German

if ( GetLocale() == "deDE" ) then

CLICKHEAL_TOTEMKILLER = {

  ActionTypeText = 'Totem Killer';

  MsgNoWandEquipped = 'Totem kann nicht angegriffen werden, kein Zauberstab angelegt.';
  MsgNoBowEquipped = 'Totem kann nicht angegriffen werden, kein Bogen, Schusswaffe oder Wurfwaffe angelegt.';

};

-- localization deDE
end
