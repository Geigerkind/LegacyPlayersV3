-- Version : French ( by Sasmira )
-- Last Update : 04/03/2005


if ( GetLocale() == "frFR" ) then

CT_SHIELDMOD_MODNAME = "Bouclier";
CT_SHIELDMOD_SUBNAME = "Sauver les Info";
CT_SHIELDMOD_TOOLTIP = "Permet \195\160 celui-ci de sauver les Informations sur les dommages subits";

end