-- default strings
TITAN_WHISPERCAST_BUTTON_LABEL = "WhisperCast: ";
TITAN_WHISPERCAST_BUTTON_NO_LABEL = " ";
TITAN_WHISPERCAST_TOOLTIP_HINTS = "Left-click to Cast\nShift left-click to Clear";
TITAN_WHISPERCAST_TOOLTIP_QUEUE_EMPTY = "Queue Empty";

if ( GetLocale() == "deDE" ) then

elseif ( GetLocale() == "frFR" ) then

end