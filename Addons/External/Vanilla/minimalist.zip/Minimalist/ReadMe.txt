Minimalist by Grennon

I try to credit the original sources as much as possible in the comments around functions.

Here is a list of some mods I borrowed from:
Tweaks
kr_gryphons
AutoRepair
ct_questlevels
goodinspect
Reputation
Autorez
idMinimap
idChat
ChatScroll by Random


Minimalist is meant to be the core of a UI for UI Minimalists like myself. The working compilation as of now is:

General Tweaks:
Minimalist
StopTheLagness
Catalyst
DuctTape

Bags:
MyBags
KC_Items:Inventory,Bank

Item Links:
ItemDB

Raiding:
oRa
WitchHunt
DamageMeters

Equipment Sets:
AceWardrobe

Unit Frames:
LucenUnitFrames

Libraries:
Ace
AceGUI
Timex

The compilation is meant to be the bare minimum for a good raiding experience and general gameplay to which class, profession, and other specialized mods can be added by the user.

