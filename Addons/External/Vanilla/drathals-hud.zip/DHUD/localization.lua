DHUD_locale = {};

DHUD_TYPE_HUMANOID = "Humanoid"; -- not needed yet

if ( GetLocale() == "frFR" ) then
    DHUD_TYPE_HUMANOID = "Humanoide"; -- not needed yet
end

if ( GetLocale() == "koKR" ) then
end

if ( GetLocale() == "deDE") then
    DHUD_TYPE_HUMANOID = "Humanoid"; -- not needed yet
end