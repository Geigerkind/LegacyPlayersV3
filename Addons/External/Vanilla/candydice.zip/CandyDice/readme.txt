CandyDice - Timer bars for rogue skills

This will show a timer bar for the duration of several rogue
abilities, as well as a second timer bar for the cooldown.

See the /cdice slash command for options. 

The timer bar can be placed centered or anchored and moved wherever
you want it, the cooldown bar is always anchored.

While CandyDice can be 100% configured via the slash commands, I highly reccomend getting DeuceCommander
or a similiar Ace2 menu mod, as it is much more convenient. A future version will include an optional FuBar/minimap icon for configuration

TODO:
	More sophisticated positioning (Allow setting the point and relative point, relative frame to anything)
	More defaults
	More CC timers
	Item cooldowns
	Better fix for the stealth timer thing.
	FuBar plugin. I'm so damn lazy.