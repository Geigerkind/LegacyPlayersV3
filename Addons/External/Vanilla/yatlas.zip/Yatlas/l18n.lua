
YATLAS_TITLE = "Yatlas";
YATLAS_VERSION = "0.5";

YATLAS_TAB_DATA = "Show Data";
YATLAS_TAB_OPTIONS = "Options";

YATLAS_BUTTON_TOOLTIP1 = "Yatlas";
YATLAS_BUTTON_TOOLTIP2 = "- Click to open the Yatlas";
YATLAS_BUTTON_TOOLTIP3 = "- Right-click and drag to move the minimap button.";
YATLAS_PLAYERJUMP = "Goto Player";

YATLAS_OPTIONS_BUTTONPOS = "Button Position";
YATLAS_OPTIONS_BUTTONPOS_TIP = "%d degrees";
YATLAS_OPTIONS_ENABLEBUTTON = "Enable Button";
YATLAS_OPTIONS_ALPHA = "Transparency";

YATLAS_UNKNOWN_ZONE = "Unknown";

YATLAS_BIGDRAGMESSAGE = "Click on map and drag to move view."

BINDING_NAME_YATLAS_TOGGLE = "Toggle Yatlas Frame";
BINDING_HEADER_YATLAS = YATLAS_TITLE;
