--[[
	Bagnon Spot's localization file
--]]

BAGNON_SPOT_TOOLTIP = "<Double-Click> to search.";

if ( GetLocale() == "deDE" ) then
	return;
end

if ( GetLocale() == "frFR" ) then
	return;
end