FOM_Emotes = {

	["any"] = {
		"Yum!",
		"Mmm, good stuff.",
	},
	
	["male"] = {
		"Good boy!",
	},
	["female"] = {
		"Good girl!",
	},
	
	["Zesty Clam Meat"] = {
		"Mmm, zesty!",
	},
	["Heaven Peach"] = {
		"Movin' to the country...",
	},
	["Mystery Meat"] = {
		"Tastes like chicken.",
	},
	["Dragonbreath Chili"] = {
		"Yow, spicy!",
	},
	
	["Bat"] = { },
	["Bear"] = { },
	["Boar"] = { 
		"Good piggy!"
	},
	["Carrion Bird"] = { },
	["Cat"] = { 
		"Nice kitty!", 
	},
	["Crab"] = { },
	["Crocolisk"] = { },
	["Gorilla"] = { },
	["Hyena"] = { 
		"Good dog!", 
	},
	["Owl"] = { },
	["Raptor"] = { },
	["Scorpid"] = { },
	["Spider"] = { },
	["Tallstrider"] = { },
	["Turtle"] = { },
	["Wind Serpent"] = { },
	["Wolf"] = { 
		"Good dog!", 
	},
};
