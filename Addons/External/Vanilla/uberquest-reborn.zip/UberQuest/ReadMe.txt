UberQuest Reborn 1.11.9

Drop in replacement for Blizzards QuestLog providing a dualpane view, 
full panes for the questlisting and a second full pane for the quest description itself.
Contains integrated "Quest Minion" with the following:
 *) No lockups at login, or at least I haven't had any!
 *) Locking QuestMinion window - When locked, mouse "clickthrough" to the 3d world behind.
 *) Color selector for background.

Modded by: Ban-Man
Woosleyt@gmail.com
Orignal Author: Marc aka Saien on Hyjal
WOWSaien@gmail.com
http://64.168.251.69/wow


Change Log
 2006.08.22
  Updated TOC For 1.12 Patch
  French Translation Added by Malkom

 2006.08.01
  Cosmetic changes and code optimization, made by Dark Imakuni
  You can now hide the 'No Quests in Minion' text when you have no quests in the Minion

 2006.07.29
  Dark Imakuni fixed the UI problem :) thanks

 2006.07.04
  Minion Reset Button Added

 2006.06.29
  Dressing room now works
  Mail works now too

 2006.06.28
  Added MyAddon 2.5 support and is now an optional dependency

 2006.06.27
  Ok I swear everything works now

 2006.06.27
  Now in German (please tell me if I need to change the translations because mein Deutch ist nicht so gut.)
  Quest Log is now moveable (it's still one window though)
  Added code in that Maischter posted and Detritis sent me (note I haven't tested all the features)
  Corrected the version Number

 2006.06.26
  Added Minion Scaling finally
  Added a key binding to toggle the minion for RonvO

 2006.06.26
  Slight UI changes (Quest Levels)

 2006.06.24
  TOC update to 1.11
  Fixed minor bugs

 2006.01.04
  TOC update to 1.9
  Fix Scrollbar changes in 1.9

 2005.10.10
  TOC update to 1.8

 2005.09.21
  Quest minion will not initialize for 10 seconds after login. This should finally 
   squash any problems during login and unintended auto adding of quests when add 
   new quest config is selected.
  Removed speed quest option as it's now part of Blizzard UI

 2005.09.13
  New TOC 1700 and adjust to 1.7 changes

 2005.08.07
  Maintenance change: Timing during login, to hopefully improve perceived lockups
  New TOC 1600

 2005.06.07
  Fixed bug introduced by Blizzard patch 1.5
  Updated to now show how many party members have that quest as well. Just like Blizzards does
  New TOC 1500

 2005.03.27
  Speed quest display option
  TOC update to 1300

 2005.03.05
  Fix bug in config when prior to bg color being set for the first time
  Colorizing for quest objectives is in.
  Updated TOC to 4216

 2005.02.20
  Updated toc to 4211
  Improved "new quest" handling
  Added color selecting, including alpha, to config
