[pre]Mendeleev is best known for his work on the periodic table;
[quote]arranging the 63 known elements into a Periodic Table based on atomic mass,
which he published in Principles of Chemistry in 1869. Dmitri Mendeleev was born at Tobolsk,
Siberia in 1834 and died in 1907[/quote]


Dependencies : Ace and Periodic Table(included)


The features I had planned for 0.6 are not all included yet but i decided to push out this update anyway and include the rest 
in a 6.1 later.

Hopefully 6.1 will add
KCI tooltip integration
EnhTooltip integration
Disenchant information for items.(really looking forward to this one)

License: This addon is licensed under the creative commons license, read license.html for more information,
you hereby have permission to use any and all code in this addon without ane form of attribution.

Credit
Tekkub for making PT and adding the IteminSets function. also for redoing the PT calling system
Kaelten for KCI so i could rip out your hooking code
Kergoth for colours and the new tooltip look

Version
0.3 First public verion
0.3.1 Toc changes
0.4.0 Major feature changes
0.4.1 Localisation changes
0.4.2 toc changes
0.5.0 Major amount of features added
0.5.1 Features added
0.5.2 Features added
0.6.0 Major amount of features added, toc change, optimising.

Changes
0.3.1 Toc changes

0.4.0 Added food and zul'gurub categories
Changed Colours
Changed Tooltip layout
Optimized some small things

0.4.1 Exported all strings to Globals for localizing

0.4.2 Changed toc UI number to 10900 stupid mistake on my part

0.5.0 Changed the way the tooltip information is fetched from PT to make it more effecient
Added Caching Mendeleev will not longer cause up to 300kb/s memory incrase when hovering over a item rather it will drop to 0 after the first tooltip update
Attempted to catch up to the gigahutastick amout of information tekkub keep adding too PeriodicTable
The following information is now available:
	Drop location from loot in the following instances
	Diremaul
	Scholomance
	Stratholme
	Blackrockspire
	Blackrockdepths
	Maraudon
	Molten Core
	Blackwing Lair
	Onyxia's Lair
	Zul'Gurub
The Boss from who an item drops (huge list one put it here)
Trade recipies you know(YOU MUST OPEN THE PANEL FOR THE TRADE SKILL EVERY SESSION, DONT LIKE IT, TALK TO TEKKUB)
Minor changse (added lockpicking items with lockpick value, booze with value etc)

0.5.1 More bosses and instances added, PT has had a number of wrong items fixed Added localizings for zhCN and deDE.
Stack size for items is now displayed. The shiftclicking and item readding the information has been fixed. 

0.5.2 Finally chat commands make an introduction. Use /mendeleev or /mend to acces them. 
	/mend report will show you what categories are on/off
	/mend toggle will allow you to toggle the categories on and off

[b]0.6.0
       AQ data added.
       ZG data fixed, showing enchant information seperatly
       Major memory use inprovements
       Gem data added ( think gemonologist)[/b]


Download
[url=http://www.curse-gaming.com/mod.php?addid=2999]Curse[/url](Yes i have a version on curse 
[url=http://www.wowinterface.com/downloads/fileinfo.php?id=4470]WoWi[/url][/pre]