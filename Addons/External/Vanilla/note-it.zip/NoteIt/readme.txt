NoteIt 1.05
by Zugreg

With Player Notes you can write down and manage notes about players and items. The note is displayed in the players or items tooltip. To create a note use the /noteit /ni command to open the note input dialog.

Features:
-You can create a key binding to open the note input dialog.

-By shift clicking on a name tag inside the chat window the note will printed to the default chat frame.

-When you have a player or NPC selected and open the note input dialog the selected units name will be put into the name input text field.

-When having the note input dialog open and shift clicking on an inventory item the items name will be put into the name input text field.

-You can browse the alphabetically ordered list and search notes alphabetically.

-The input dialog is fully draggable.

-You can add the players clan tag to the tooltip when you mouse over him.

-A sound can be played when you mouseover a player or npc with a note.

Known issues:
There may be issues with addons, which change somthing to the tooltips.
