-- Binding Configuration
BINDING_HEADER_RESTEDBONUS     = "Rested Bonus";
BINDING_NAME_RESTEDBONUSSELF = "Display rested bonus";
BINDING_NAME_RESTEDBONUSSERVER  = "Display rested bonus for server";
BINDING_NAME_RESTEDBONUSALL  = "Display rested bonus for all";
