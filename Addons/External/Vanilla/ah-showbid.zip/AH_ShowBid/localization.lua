--------------------------------------------------------------------------------------------------
-- Localized messages and options in German and English
--------------------------------------------------------------------------------------------------

if ( GetLocale() == "deDE" ) then
-- German

   AH_SHOWBID_BID = "Geb.";

else
-- English or unsupported

   AH_SHOWBID_BID = "bid";

end