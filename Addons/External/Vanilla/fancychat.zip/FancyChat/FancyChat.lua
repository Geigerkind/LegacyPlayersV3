FCDNDNOTE=''

OldSendChatMessage = SendChatMessage
function SendChatMessage(msg,chat,lang,chan)
	if (msg) then
		msg = string.gsub(msg,"INV","invite")
		
		px, py = GetPlayerMapPosition('player')
		msg = string.gsub(msg,"%%c",(math.floor(px*100)/1)..','..(math.floor(py*100)/1))
		msg = string.gsub(msg,"$c",(math.floor(px*100)/1)..','..(math.floor(py*100)/1))
		
		msg = string.gsub(msg,"%%m",UnitName("mouseover") or "<no mouseover>")
		msg = string.gsub(msg,"$m",UnitName("mouseover") or "<no mouseover>")
		msg = string.gsub(msg,"%%t",UnitName("target") or "<no target>")
		msg = string.gsub(msg,"$t",UnitName("target") or "<no target>")
		msg = string.gsub(msg,"%%n",UnitName("target") or "<no target>")
		msg = string.gsub(msg,"$n",UnitName("target") or "<no target>")
		msg = string.gsub(msg,"%%p",UnitName("player") or "<no player>")
		msg = string.gsub(msg,"$p",UnitName("player") or "<no player>")
		msg = string.gsub(msg,"%%l",GetMinimapZoneText())
		msg = string.gsub(msg,"$l",GetMinimapZoneText())
		if not string.find(msg,"/run") and not string.find(msg,"www") and not string.find(msg,"http") and string.sub(msg,1,1) ~= " " then
			
			-- TYPOS
			msg = string.gsub(msg," +"," ")
			msg = string.gsub(msg,"%s$","")
			msg = string.gsub(msg," teh "," the ")
			msg = string.gsub(msg," hte "," the ")
			msg = string.gsub(msg,"abd ","and ")
			msg = string.gsub(msg,"releae","release")
			msg = string.gsub(msg,"rouge","rouge")
			msg = string.gsub(msg,"warior","warrior")
			msg = string.gsub(msg,"waht","what")
			msg = string.gsub(msg,"sekurity","security")
			msg = string.gsub(msg,"autokorekt","autocorrect")
			msg = string.gsub(msg,"autocorekt","autocorrect")
			msg = string.gsub(msg,"autokorect","autocorrect")
			msg = string.gsub(msg,"autocorect","autocorrect")
			msg = string.gsub(msg,"auto correct","autocorrect")
			msg = string.gsub(msg,"aviable","available")
			msg = string.gsub(msg,"desperatly","desperately")
			msg = string.gsub(msg,"taht","that")
			msg = string.gsub(msg,"lsat","last")			
			msg = string.gsub(msg,"plaed","placed")
			msg = string.gsub(msg,"cua","cya")
			msg = string.gsub(msg,'wnat','want')
			msg = string.gsub(msg,' ur ',' your')
			msg = string.gsub(msg,'goup ','group ')
			msg = string.gsub(msg,'geat ','great ')
			msg = string.gsub(msg,"i'll","i will")
			msg = string.gsub(msg,'onxya','onyxia')
			msg = string.gsub(msg,'onxyia','onyxia')
			msg = string.gsub(msg,'ÅÅ','^^')
			msg = string.gsub(msg,"Teh ","The ")
			msg = string.gsub(msg,"afkk","afk")
			msg = string.gsub(msg,"bugget","bugged")
			msg = string.gsub(msg,"aply","apply")
			msg = string.gsub(msg,"helo ","Hello ")
			msg = string.gsub(msg,"ello ","Hello ")
			msg = string.gsub(msg,"theer","there")
			msg = string.gsub(msg,"heer","here")
			msg = string.gsub(msg,"gretings","greetings")
			msg = string.gsub(msg,"tis","this")
			msg = string.gsub(msg,"tempel","temple")
			msg = string.gsub(msg,"ahve","have")
			msg = string.gsub(msg," em "," them ")
			msg = string.gsub(msg,"ficus","focus")
			msg = string.gsub(msg,"focis","focus")
			msg = string.gsub(msg,"studing","studying")
			msg = string.gsub(msg,"tommorrow","tomorrow")
			msg = string.gsub(msg,"becuse","because")
			msg = string.gsub(msg,"haveing","having")
			msg = string.gsub(msg,"writting","writing")		
			msg = string.gsub(msg,"instalation","installation")	
			msg = string.gsub(msg,"conection","connection")
			msg = string.gsub(msg,"comon","common")
			msg = string.gsub(msg,"facepam","facepalm")
			msg = string.gsub(msg,"zzzz","zZzZ")
			msg = string.gsub(msg,"zepelin","zeppelin")
			
			
			--Custom Emotes
			

			
			-- RUSSIAN TO ENGLISH
			
			msg = string.gsub(msg,'!ищу людей','lfm')
			msg = string.gsub(msg,'!ищу группу','lfg')
			msg = string.gsub(msg,'!ищу рейд','lfr')
			msg = string.gsub(msg,'!продам','wts')
			msg = string.gsub(msg,'!обменяю','wtt')
			msg = string.gsub(msg,'!куплю','wtb')
			msg = string.gsub(msg,'!извините','sorry')
			msg = string.gsub(msg,'!помогите','help')
			msg = string.gsub(msg,'!привет','hello')
			msg = string.gsub(msg,'!лучше','better')
			msg = string.gsub(msg,'!меня зовут','my name is')
			msg = string.gsub(msg,'!дамагер','dps')
			msg = string.gsub(msg,'!урон','damage')
			msg = string.gsub(msg,'!хилер','healer')
			msg = string.gsub(msg,'!исцелять','heal')
			msg = string.gsub(msg,'!танковать','tanking')
			msg = string.gsub(msg,'!танк','tank')
			msg = string.gsub(msg,'!аггро','aggro')
			msg = string.gsub(msg,'!атаковать','attack')
			msg = string.gsub(msg,'!стоп','stop')
			msg = string.gsub(msg,'!хватит','stop')
			msg = string.gsub(msg,'!остановись','stop')
			msg = string.gsub(msg,'!я не понимая по-английски','i dont understand english')
			msg = string.gsub(msg,'!ты меня понимаешь','can you understand me')
			msg = string.gsub(msg,'!да','yes')
			msg = string.gsub(msg,'!нет','no')
			msg = string.gsub(msg,'!подожди','wait')
			msg = string.gsub(msg,'!дайте попить','mana break')
			msg = string.gsub(msg,'!стоп, хватит, остановись','stop')
			msg = string.gsub(msg,'!заряд','charge')
			msg = string.gsub(msg,'!хаха','haha')
			msg = string.gsub(msg,'!лол','lol')
			msg = string.gsub(msg,'!я использую аддон для конвертации русског ов английский','i am using an addon to convert russian to english')
			msg = string.gsub(msg,'!лучший','best')
			msg = string.gsub(msg,'!лучше','best')
			msg = string.gsub(msg,'!хорошо','good')
			msg = string.gsub(msg,'!великолепно','great')
			msg = string.gsub(msg,'!замечательно','great')
			msg = string.gsub(msg,'!приятный','nice')
			msg = string.gsub(msg,'!убивайте','kill')
			msg = string.gsub(msg,'!убей','kill')
			msg = string.gsub(msg,'!умереть','die')
			msg = string.gsub(msg,'!вайп','wipe')
			msg = string.gsub(msg,'!смерть','death')
			msg = string.gsub(msg,'!баг','bug')
			msg = string.gsub(msg,'!дисконнект','dc')
			msg = string.gsub(msg,'!ддос','ddos')
			msg = string.gsub(msg,'!аддон','addon')
			msg = string.gsub(msg,'!почему','why')
			msg = string.gsub(msg,'!серьезно','realy')
			msg = string.gsub(msg,'!мне, я','me')
			msg = string.gsub(msg,'!ты','you')
			msg = string.gsub(msg,'!ему','him')
			msg = string.gsub(msg,'!ее','her')
			msg = string.gsub(msg,'!их','them')
			msg = string.gsub(msg,'!им','them')
			msg = string.gsub(msg,'!гильдия','guild')
			msg = string.gsub(msg,'!присоединиться','join')
			msg = string.gsub(msg,'!покинуть','leave')
			msg = string.gsub(msg,'!ливнуть','leave')
			msg = string.gsub(msg,'!выйти','exit')
			msg = string.gsub(msg,'!войти','enter')
			msg = string.gsub(msg,'!встречаться где-либо','meet')
			msg = string.gsub(msg,'!встречающий','meeting')
			msg = string.gsub(msg,'!ты уверен','are you sure')
			msg = string.gsub(msg,'!я уверен','i am sure')
			msg = string.gsub(msg,'!дирижабль','zeppelin')
			msg = string.gsub(msg,'!корабль','ship')
			msg = string.gsub(msg,'!оргримар','orgrimmar')
			msg = string.gsub(msg,'!оргри','orgrimmar')
			msg = string.gsub(msg,'!андерсити','undercity')
			msg = string.gsub(msg,'!андер','undercity')
			msg = string.gsub(msg,'!тандер блафф','thunder bluff')
			msg = string.gsub(msg,'!тандер','thunder bluff')
			msg = string.gsub(msg,'!штормвинд','stormwind')
			msg = string.gsub(msg,'!шторм','stormwind')
			msg = string.gsub(msg,'!иронфордж','ironforge')
			msg = string.gsub(msg,'!ты не понмиаешь','you are misunderstanding')
			msg = string.gsub(msg,'!я не понимаю','i misunderstood')
			msg = string.gsub(msg,'!извини, я не понимаю тебя','sorry i misunderstood you-')
			msg = string.gsub(msg,'!работать','work')
			msg = string.gsub(msg,'!работа','job')
			msg = string.gsub(msg,'!сервер','server')
			msg = string.gsub(msg,'!пожалуйста','please')
			msg = string.gsub(msg,'!БФД','Blackfathom Deeps')
			msg = string.gsub(msg,'!сова','owl')
			msg = string.gsub(msg,'!кот','cat')
			msg = string.gsub(msg,'!кошка','cat')
			msg = string.gsub(msg,'!киса','kitty')
			msg = string.gsub(msg,'!медведь','bear')
			msg = string.gsub(msg,'!медвед','bear')
			msg = string.gsub(msg,'!совух','moonkin')
			msg = string.gsub(msg,'!свет','light')
			msg = string.gsub(msg,'!отхил','heal')
			msg = string.gsub(msg,'!яд','poison')
			msg = string.gsub(msg,'!кот','cat')
			msg = string.gsub(msg,'!полет','flight')
			msg = string.gsub(msg,'!полетка','flight')
			msg = string.gsub(msg,'!полететь','fly')
			msg = string.gsub(msg,'!лететь','fly')
			msg = string.gsub(msg,'!выстрел','shot')
			msg = string.gsub(msg,'!стреляй','fire')
			msg = string.gsub(msg,'!патрон','shot')
			msg = string.gsub(msg,'!патроны','shots')
			msg = string.gsub(msg,'!патронов','shots')
			msg = string.gsub(msg,'!стрела','arrow')
			msg = string.gsub(msg,'!стрел','arrows')
			msg = string.gsub(msg,'!стрелы','arrows')
			msg = string.gsub(msg,'!лок','warlock')
			msg = string.gsub(msg,'!замок','lock')
			msg = string.gsub(msg,'!трава','herb')
			msg = string.gsub(msg,'!руда','ore')
			msg = string.gsub(msg,'!ткань','cloth')
			msg = string.gsub(msg,'!рыбалка','fishing')
			msg = string.gsub(msg,'!кв','quest')
			msg = string.gsub(msg,'!ги','guild')
			msg = string.gsub(msg,'!репа','rep')
			msg = string.gsub(msg,'!кидала','scam')
			msg = string.gsub(msg,'!опыт','xp')
			msg = string.gsub(msg,'!опыта','xp')
			msg = string.gsub(msg,'!много','many')
			msg = string.gsub(msg,'!ур','level')
			msg = string.gsub(msg,'!уровень','level')
			msg = string.gsub(msg,'!урка','horde')
			msg = string.gsub(msg,'!урки','hordes')
			msg = string.gsub(msg,'!алый','alliance')
			msg = string.gsub(msg,'!алые','alliances')
			msg = string.gsub(msg,'!алени','alliance')
			msg = string.gsub(msg,'!кто','who')
			msg = string.gsub(msg,'!что','what')
			msg = string.gsub(msg,'!где','where')
			msg = string.gsub(msg,'!когда','when')

			-- Dungeon/Raid
			
			msg = string.gsub(msg,'!БРД','Blackrock Depths')
			msg = string.gsub(msg,'!ЛБРС','Blackrock Spire (Lower)')
			msg = string.gsub(msg,'!УБРС','Blackrock Spire (Upper)')
			msg = string.gsub(msg,'!БВЛ','blackwing Lair')
			msg = string.gsub(msg,'!Мертвые копи','The Deadmines')
			msg = string.gsub(msg,'!ДМ Ист','Dire Maul (East)')
			msg = string.gsub(msg,'!ДМ Норд','Dire Maul (North)')
			msg = string.gsub(msg,'!ДМ Вест','Dire Maul (West)')
			msg = string.gsub(msg,'!Кузня крови','HC: The Blood Furnaces ')
			msg = string.gsub(msg,'!Разрушенные залы','HC: The Shattered Halls')
			msg = string.gsub(msg,'!Марадон','Maraudon')
			msg = string.gsub(msg,'!МК','Molten Core')
			msg = string.gsub(msg,'!Накс','Naxxramas')
			msg = string.gsub(msg,'!Оня','Onyxias Lair')
			msg = string.gsub(msg,'!РФЧ','Ragefire Chasm')
			msg = string.gsub(msg,'!РФД','Razorfen Downs')
			msg = string.gsub(msg,'!РФК','Razorfen Kraul')
			msg = string.gsub(msg,'!АК20','The Ruins of Ahn Qiraj')
			msg = string.gsub(msg,'!СМ','Scarlet Monastery')
			msg = string.gsub(msg,'!Шоло','Scholomance')
			msg = string.gsub(msg,'!СФК','Shadowfang Keep')
			msg = string.gsub(msg,'!Тюрьма','The Stockade')
			msg = string.gsub(msg,'!Стокады','The Stockade')
			msg = string.gsub(msg,'!Страт уд','Stratholme undead')
			msg = string.gsub(msg,'!Страт лив','Stratholme living')
			msg = string.gsub(msg,'!СТ','The Sunken Temple')
			msg = string.gsub(msg,'!АК40','The Temple of Ahn Qiraj')
			msg = string.gsub(msg,'!Ульдаман','Uldaman')
			msg = string.gsub(msg,'!ульда','Uldaman')
			msg = string.gsub(msg,'!ВК','Wailing Caverns')
			msg = string.gsub(msg,'!ЗФ','Zul Farrak')
			msg = string.gsub(msg,'!ЗГ','Zul Gurub')
			
			-- Czesh to English
			
			msg = string.gsub(msg,'!hledám grupu','lfg')
			msg = string.gsub(msg,'!hledám raid','lfr')
			msg = string.gsub(msg,'!prodám','wts')
			msg = string.gsub(msg,'!vyměním','wtt')
			msg = string.gsub(msg,'!koupím','wtb')
			msg = string.gsub(msg,'!promin','sorry')
			msg = string.gsub(msg,'!pomoct','help')
			msg = string.gsub(msg,'!ahoj','hello') --it could be -- cau, dobry den...
			msg = string.gsub(msg,'!jmenuji se','my name is')
			msg = string.gsub(msg,'!damager','dps')
			msg = string.gsub(msg,'!tankovat','tanking')
			msg = string.gsub(msg,'!utok','attack')
			msg = string.gsub(msg,'!stuj','stop')
			msg = string.gsub(msg,'!nerozumim anglicky','i dont understand english')
			msg = string.gsub(msg,'!rozumismi','can you understand me')
			msg = string.gsub(msg,'!ano','yes')
			msg = string.gsub(msg,'!ne','no')
			msg = string.gsub(msg,'!pockej','wait')
			msg = string.gsub(msg,'!stuj','stop')
			msg = string.gsub(msg,'!pouzivam addon ktery preklada muj text do anglictiny','i am using an addon to convert czech to english')
			msg = string.gsub(msg,'!nejlepsi','best')
			msg = string.gsub(msg,'!lepsi','better')
msg = string.gsub(msg,'!dobry','good')
msg = string.gsub(msg,'!skvele','great')
msg = string.gsub(msg,'!vyborne','great')
msg = string.gsub(msg,'!vytecne','nice')
msg = string.gsub(msg,'!zabij','kill')
msg = string.gsub(msg,'!zabit','kill')
msg = string.gsub(msg,'!chcipni','die')
msg = string.gsub(msg,'!smrt','death')
msg = string.gsub(msg,'!баг','bug')
msg = string.gsub(msg,'!proc','why')
msg = string.gsub(msg,'!opravdu','realy')
msg = string.gsub(msg,'!on','him')
msg = string.gsub(msg,'!ona','her')
msg = string.gsub(msg,'!oni','them')
msg = string.gsub(msg,'!oni','them')
msg = string.gsub(msg,'!guilda','guild')
msg = string.gsub(msg,'!pripojit','join')
msg = string.gsub(msg,'!leavnout','leave')
msg = string.gsub(msg,'!leavni','leave')
msg = string.gsub(msg,'!exit','exit')
msg = string.gsub(msg,'!vstup','enter')
msg = string.gsub(msg,'!setkame se','meet')
msg = string.gsub(msg,'!setkani','meeting')
msg = string.gsub(msg,'!jsi si jisty','are you sure')
msg = string.gsub(msg,'!jsem si jisty','i am sure')
msg = string.gsub(msg,'!zeppelin, vzducholod','zeppelin')
msg = string.gsub(msg,'!lod','ship')
msg = string.gsub(msg,'!nerozumis mi','you are misunderstanding')
msg = string.gsub(msg,'!nepochopil jsem','i misunderstood')
msg = string.gsub(msg,'!promin nepochopil jsem te','sorry i misunderstood you-')
msg = string.gsub(msg,'!prace','work')
msg = string.gsub(msg,'!prace','job')
msg = string.gsub(msg,'!prosim','please')

 -- Dungeon/Raid
 
msg = string.gsub(msg,'!Кузня крови','HC: The Blood Furnaces')
msg = string.gsub(msg,'!Разрушенные залы','HC: The Shattered Halls')



			
			

				
				
			-- English to Alliance

			msg = string.gsub(msg,'!no','17') -- no
			msg = string.gsub(msg,'!no kill','j c 108 d') -- n o kil l
			msg = string.gsub(msg,'!ha','as') -- ha
			msg = string.gsub(msg,'!muhaha','27 11 11') -- mu ha ha
			msg = string.gsub(msg,'!kill','123') -- kil
			msg = string.gsub(msg,'!lol','d c d') -- l o l
			msg = string.gsub(msg,'!hi','Ÿ ð') -- h i
				
				
			-- COMMAND TYPOS
			
			msg = string.gsub(msg,'/Reloadui','/Console Reloadui')
			msg = string.gsub(msg,'/join gobal','/join global')
			msg = string.gsub(msg,'/join wold','/join world')
			msg = string.gsub(msg,'/join gobal','/join global')
			msg = string.gsub(msg,'stay on ed','leave ed')
			msg = string.gsub(msg,'stay on ED','leave ED')
			
			-- LOCATIONS
			msg = string.gsub(msg,"IF","Ironforge")
			msg = string.gsub(msg,"SW","Stormwind")
			msg = string.gsub(msg,"ORG","Orgrimmar")
			msg = string.gsub(msg,"UC","Undercity")
			msg = string.gsub(msg,"TBC","The Burning Crusade")
			msg = string.gsub(msg,"TB","Thunder Bluff")
			msg = string.gsub(msg,"AV","Alterac Valley")
			msg = string.gsub(msg,"WSG","Warsong Gulch")
			msg = string.gsub(msg,"RFC","Ragefire Chasm")
			msg = string.gsub(msg,"DM","Dead Mines")
			msg = string.gsub(msg,"BWL","Blackwing Lair")
			msg = string.gsub(msg,"MC","Molten Core")
			msg = string.gsub(msg,"AQ40","Temple of Ahn'Qiraj")
			msg = string.gsub(msg,"AQ20","Ruins of Ahn'Qiraj")
			msg = string.gsub(msg,"AB","Arathi Basin")
			msg = string.gsub(msg,"ZG","Zul'Gurub")
			msg = string.gsub(msg,"ZF","Zul'Farrak")
			msg = string.gsub(msg,"Mara","Maraudon")
			msg = string.gsub(msg,"RFK","Razorfen Kraul")
			msg = string.gsub(msg,"SM","Scarlet Monastery")
			msg = string.gsub(msg,"SFK","Shadowfang Keep")
			msg = string.gsub(msg,"WC","Wailing Caverns")
			msg = string.gsub(msg,"Ulda","Uldaman")
			msg = string.gsub(msg,"Gnomer","Gnomeregan")
			msg = string.gsub(msg,"BFD","Blackfathom Deeps")
			msg = string.gsub(msg,"Scholo","Scholomance")
			msg = string.gsub(msg,"STV","Stranglethorn Vale")
			msg = string.gsub(msg,"BRD","Blackrock Depths")
			msg = string.gsub(msg,"UBRS","Upper Blackrock Spire")
			msg = string.gsub(msg,"LBRS","Lower Blackrock Spire")
			msg = string.gsub(msg,"BRS","Blackrock Spire")
			msg = string.gsub(msg,"NAXX","Naxxramas")
			msg = string.gsub(msg,"STRAT","Stratholme")
			msg = string.gsub(msg,'DM east','Dire Maul (East)')
            msg = string.gsub(msg,'DM north','Dire Maul (North)')
            msg = string.gsub(msg,'DM west','Dire Maul (West)')
			msg = string.gsub(msg,'Stoky','The Stockade')
			msg = string.gsub(msg,'OL','Onyxias Lair')
			
			--LOCATION Common Location Typos
			msg = string.gsub(msg,"Ironfoge","Ironforge")
			msg = string.gsub(msg,"Ironfore","Ironforge")
			msg = string.gsub(msg,"Ionforge","Ironforge")
			msg = string.gsub(msg,"ironforge","Ironforge")
			msg = string.gsub(msg,"orgrimmar","Orgrimmar")
			msg = string.gsub(msg,"orgimmar","Orgrimmar")
			msg = string.gsub(msg,"Altarac Valley","Alterac Valley")
			msg = string.gsub(msg,"Altarec Valley","Alterac Valley")
			msg = string.gsub(msg,"altarac valley","Alterac Valley")
			msg = string.gsub(msg,"Altarac Vallay","Alterac Valley")
			msg = string.gsub(msg,"Zul Gurub","Zul'Gurub")
			msg = string.gsub(msg,"Zul Farrak","Zul'Farrak")
			msg = string.gsub(msg,"Waling Caverns","Wailing Caverns")
			
			-- NORMAL WORDS
			msg = string.gsub(msg,"Cronos","Kronos")
			msg = string.gsub(msg,"IRL","in real life")
			msg = string.gsub(msg,"MBing","Multiboxing")
			msg = string.gsub(msg,"MBer","Multiboxer")
			msg = string.gsub(msg,"MB","Mana Break!")
			msg = string.gsub(msg,"PLS","Please!")
			msg = string.gsub(msg,"TY","Thank You!")
			msg = string.gsub(msg,"THX","Thanks!")
			msg = string.gsub(msg,"SRY","sorry")
			msg = string.gsub(msg,"WB","Welcome Back")
			msg = string.gsub(msg,"BTW","by the way")
			msg = string.gsub(msg,"BRB","Be Right Back")
			msg = string.gsub(msg,"OMW","on my way")
			msg = string.gsub(msg,"OMG","oh my God")
			msg = string.gsub(msg,"OMFG","oh my fückin' God")
			msg = string.gsub(msg,"ETC","etcetera")
			msg = string.gsub(msg,"FFS","For Fücks Sake")
			msg = string.gsub(msg,"FU","fück you")
			msg = string.gsub(msg,"SRSLY","Seriously")
			msg = string.gsub(msg,"OOM","Out Of Mana!")
			msg = string.gsub(msg,"WP","Well Played")
			msg = string.gsub(msg,"GJ","Good Job")
			msg = string.gsub(msg,"Shit","Shít")
			msg = string.gsub(msg,"Fuck","Fück")
			msg = string.gsub(msg,"AH","Auction House")
			
			
			-- FIX SYNTAX
			msg = FixSyntax(msg)			
			
			msg = string.gsub(msg,"!wsmiley","☺")
			msg = string.gsub(msg,"!bsmiley","☻")
			msg = string.gsub(msg,"!heart","♥")
			

		end
				
		msg = string.gsub(msg,"<link>(%S*)</link>","|||c|Hplayer:%1|hlickable link|h|r||||")
		msg = string.gsub(msg,"<a href=\"(%S*)\">(.*)</a>","|cff66BBFF|Hplayer:%1|h%2|h|r")
	end			
	OldSendChatMessage(msg,chat,lang,chan)
end

-- WHISPERS
function ChatEdit_ExtractTellTarget(editBox, msg)
	
	local target = gsub(msg, "(%s*)([^%s]+)(.*)", "%2", 1);
	if ( strlen(target) <= 0 ) then
		return;
	end
			
	target = string.gsub(target,"%%m",UnitName("mouseover") or "<no mouseover>")
	target = string.gsub(target,"%%t",UnitName("target") or "<no target>")
	target = string.gsub(target,"%%n",UnitName("target") or "<no target>")
	target = string.gsub(target,"%%p",UnitName("player") or "<no player>")
			
	msg = strsub(msg, strlen(target) + 2);
	editBox.tellTarget = target;
	editBox.chatType = "WHISPER";
	editBox:SetText(msg);
	ChatEdit_UpdateHeader(editBox);
end

FancyChatChatFrame_OnEvent = ChatFrame_OnEvent
function ChatFrame_OnEvent(event)
	if ( strsub(event, 1, 8) == "CHAT_MSG" ) and arg1 then
		if not string.find(arg1,"\124%S*http://%S*") then
			arg1 = string.gsub(arg1,"(http://%S+)","|cff66BBFF|Hurl:%1|h%1|h|r")
		end
		if (event == "CHAT_MSG_GUILD" and string.find(string.lower(arg1),string.lower(UnitName('player'))) and FCDNDNOTE ~= '') then
			SendChatMessage("I'm DND: "..FCDNDNOTE,"GUILD",nil,nil)
		end
--		PLAYER NAME HIGHLIGHT
--		local name = UnitName("player")
--		colorname = "\124cffFFFF00\124h"..name.."\124h\124r"
--		
--		if not string.find(arg1,"http://%S*"..name) then
--			arg1 = string.gsub(arg1,name,colorname)
--		end
--		if not string.find(arg1,"http://%S*"..string.lower(name)) then
--			arg1 = string.gsub(arg1,string.lower(name),colorname)
--		end
--		if not string.find(arg1,"http://%S*"..string.upper(name)) then
--			arg1 = string.gsub(arg1,string.upper(name),colorname)
--		end	
	end
	FancyChatChatFrame_OnEvent(event)
end

function FixSyntax(msg)

	msg = string.upper(string.sub(msg,1,1))..string.sub(msg,2)
	msg = string.gsub(msg,"(.*)%s*$","%1")
	if (not string.find(msg,"(.*%p)$") and string.gsub(msg,"%s",'') ~= '') then
		msg = msg..""																	----- if you want to add something such as ! or ? or simply a sentence that you want to be said whenever you say something add it in between the "".
	end
	msg = string.gsub(msg," i "," I ")
	msg = string.gsub(msg,"(%.%s+%S)",string.upper)
	msg = string.gsub(msg,"(%?%s+%S)",string.upper)
	msg = string.gsub(msg,"(%!%s+%S)",string.upper)
	return msg
end

FancyChatSetItemRef = SetItemRef
function SetItemRef(link, text, button) 
	if string.sub(link,1,3) == 'url' then
		ChatFrame_OpenChat(string.sub(link,5),DEFAULT_CHAT_FRAME)	
	else
		FancyChatSetItemRef(link,text,button)
	end
end
-- Reload UI
--SlashCmdList["FANCYCHAT_SENDLINK_COMMAND"] = function(flag)
--	local words = {};
--	for word in string.gfind(flag, "[^%s]+") do
--		table.insert(words, word);
--	end
--	if table.getn(words) == 2 then
--		local name = words[1]
--		local msg = words[2]
--	end
--end
--SLASH_FANCYCHAT_SENDLINK_COMMAND1 = "/link";

SlashCmdList["CHAT_DND"] = function(msg)
	SendChatMessage(msg, "DND");
	if (msg == 'You are no longer marked DND') then
		FCDNDNOTE = ''
	else
		FCDNDNOTE = msg
	end 
end