-------------------------------------------------------------------------------
--                               TitanCritLine                               --
-------------------------------------------------------------------------------

if ( GetLocale() == "deDE" ) then
	TitanCritLine_LocalizeDE();
elseif ( GetLocale() == "frFR" ) then
	TitanCritLine_LocalizeFR();
else		
	TitanCritLine_LocalizeEN();	
end