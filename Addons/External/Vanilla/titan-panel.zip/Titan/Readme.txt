Whats in version 2.19.1
Fixed Weapon Quick swap dependancy

Whats in version 2.19
Updated for patch 1.11

Whats in version 2.18
Titan Zonespeed added (after reviewing multiplt zone speed enhancements I felt Titan required one due to the large amount of data manipulated)
Fixed casting bar blur issue
Added new version of Titan Repair
Added new performance enhancements

Whats in version 2.17.1
Fixed overlap issue
New version of TitanRepair that increases performance
New version of BonusScanner that fixes perfromance issue (not formal released version by Author)

Whats in version 2.17
Enhanced Performance overall
Fixed TitanRepair Performance lag (Thank you Archarodim)
Added option to turn off Inventory damage checking in TitanRepair (major performance increase if off)
Massive performace increase when using Automatic Equipment changers
Fixed typo's in French locals

Whats in version 2.16.3
Fixed lag issue
Added in some french translations

Whats in version 2.16.2
Fixed error is register event in TitanBag

Whats in version 2.16.1
Fixed SCT Error for Honor+
Increased zone in performace by a lot
Fixed durabiltiy information changing for no apparent reason
Added new German Locals
Fixed screen Adjust problem

Whats in version 2.16
Fixed Auto Join bug
Fixed Rider display issue

Whats in version 2.15.5
Fixed 'late night' user coding error
Rider will now unequip items

Whats in version 2.15.4
Disabled Rider in flight
Added new BonusScanner from AJC
Corrected function call to SCT
Replaced Auto Join Functin for BG (From released Titan Honor)

Whats in version 2.15.3
Resolved trinket issue in TitanRider
Updated .TOC of bonusScanner

Whats in version 2.15.2
TitanRider not using rider enchants has been fixed
TitanRepair not showing items or percent
BonusScanner (Temp fix until author fixes problem)

Whats in version 2.15.1
Fixed overlap issue

Whats in version 2.15
Fixed battlefield auto join issue
Added small fixes for typos
Added Profession bags
Fixed issue with shard bags
Made compatable with version 1.10 of WoW
Cleaned up new structure of files and tooltips
Varies minor errors fixed

Whats in version 2.14.2
Removed Titan Naked to save confusion users wil lnow have to run off addons from the addons control to remove items

Whats in version 2.14.1
Fixed graphics error

Whats in version 2.14
Fixed issue that prevented TitanRider being turned off
Moved all addons to there own folders to enable disabling
Added soul bags to ignore list
Fixed auto join bug for battlegrounds
Fixed death bug in battlegrounds
Added my Titan StanceSets as a built in Addon (can be disbaled)
Added option to turn on/off the casting bar movement
Added cleanMiniMap fix
Added French translations

Whats in version 2.13.1
Removed debug errors

Whats in version 2.13
Fixed issue with battle field auto jion
Fixed issue with auto release in battlefield
Added German locals for Titan Rider
Added ability to turn off tooltips

Whats in version 2.12
Fixes for Tooltips being offscreen

Whats in version 2.11
Fixes for TitanRider to work with 1.9

Whats in version 2.10
Patch 1.9 Fixes
TitanRider fixes that prevented riding equipment being removed
Minor fixes to small bugs
Ability to turn off TitanRider

Whats in version 2.09
Fixed bug that prevented Regen labels being turned on or off
TitanRider - a New addon which will enable the user to have there Riding gear auto equip and unequip
Added version 1.03 of Titan Repair
Corrected German localization for Quivers
Added sublocation information
Fixed issue with TitanClock

Whats in version v2.08
Added check to see if a specified moveable frame has been moved by the user to prevent Titan from overriding user settings
Added check into TitanMoney for a nil value when you bring up the money pickup window
Localization fixes for both German and French
Fixed issue with bottom double bar being invisable in some cases
Fixed issue with bottom tooltips sometimes being offscreen
Fixed an issue that prevented Menus from scaling correctly
Added a patch to bypass buttons if a 'nil' is supplied

Whats in version v2.07
Really Fixed conflict between CT_TickMod and Titan Regen
Moved 'Load Settings' menu up 1 level and added a breakdown by server to cater for players with many alts

Whats in version v2.06
Fixed issue with Battleground MiniMap
Fixed conflict between CT_TickMod and Titan Regen
Fixed Cosmos/Titan Cast bar issue
Fixed issue with 24hr clock not displaing leading '0'
Added ability to set Timezones in 1/2 hr increments

Whats in version v2.05
Center text will now work when you have the double bar showing.
Adding an addon to a bar in auto hide mode will no longer put the addon on another bar
Server Time offset fix is now included
Added check for duplicate plugins and issue a warning if a duplicate if found
Revamp of the graphics to enhance Titan's look - Thank you sdwwraith
Fixed issue with the clock not being able to be displayed on left
Fixed issue with clock attempting to anchor to itself
Users will now be able to drag and drop addons to the location of there choice on any bar
TitanRepair now has an option to turn off the popup for repair

Whats in version v2.04
Fixed Flashing on Tooltips
Fixed no vanishing bottom bar
Fixed issue with auto hide and menus

Whats in version v2.03

New options Menu, all the options will have moved to there own sub menu
Added new option to turn off the font scaler as some folks are having issues with it
Added the ability for Mod authors to categorize there addon
  -This will enable mods to appear under there own menu category
  -There will be some initial categories, this shoudl help with the limitation on menu sizing
Fixed an issue in TitanMoney
Fixed an issue in TitanXp
Added version number to the plugin menu
Added flag to turn the version number on/off
Added new version of Item Bonuses
Added French localization provided by Carlton - Thank you
Cleaned up TitanScaler to display all information
TitanRegen now fully intergrated into base addon and will now be added to inside base addon only
TitanRepair is now fully intergrated into the base addon
Updated graphics for double bar

MOD Authors
Added registration variable 'category'
Added registration variable 'version'

Both are optional, but supplying the category will move your plugin into a sub menu and should help prevent plugins not being shown in the list.  If no category is supplied the plugin will default to 'General'


