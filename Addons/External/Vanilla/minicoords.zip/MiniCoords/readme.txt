Many people search a handy mod like this, I think. Few bigger mod have this option,
 but those are much larger and more functionallity with map using. Someone just use this option only,
 to put coords on Minimap.
So, that's what this mod doing. 

Usage: Just install the addon, and the coords will be on your minimap.
 You can drag the coords with your left mousebutton. If You are typeing,
 You can insert the location in chateditbox with shift-leftmousebutton.