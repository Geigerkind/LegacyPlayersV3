# Outfitter
Added an option to the special (riding) outfits - Disable when in instance (AQ20, AQ40, ZG20)

![Outfitter](https://i.imgur.com/iAixuvG.png)
