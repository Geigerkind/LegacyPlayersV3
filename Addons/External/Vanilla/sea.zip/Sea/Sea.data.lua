--[[
--
--	Sea.data
--
--	Useful WoW data that must be compiled by hand
--
--]]

Sea.data = {

	-- Item Data
	item = {};

	-- Spell Data
	spell = {};

	-- Ability
	ability = {};
};
