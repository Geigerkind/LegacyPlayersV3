ChatCast 1.4 Triggers for buffs/other spells:

PRIEST
Power Word: Fortitude = "fort", "single fort", "fortitude", "stam", "sta", "stamina"
Prayer of Fortitude = "group fort", "group fortitude", "group stam", "group stamina"
Shadow Protection = "shadow"
Divine Spirit = "spirit", "wis", "ds"
Power Word: Shield = "shield"
Dispel Magic = "dispel"
Abolish Disease = "cure disease", "disease"
Cure Disease = "cure disease", "disease"
Resurrection = "rez", "res", "ress"
Flash Heal = "heal", "heals"
Fear Ward = "fear", "ward"

MAGE
Arcane Intellect = "ai", "int"
Arcane Brilliance = "ab", "group ai", "group int", "brilliance"
Dampen Magic = "dampen"
Amplify Magic = "amplify"
Remove Lesser Curse = "remove curse", "curse"
Conjure/Trade Water = "water"

DRUID
Mark of the Wild = "motw", "mark"
Gift of the Wild = "gotw", "gift", "group mark"
Thorns = "thorns"
Innervate = "innervate"
Remove Curse = "remove curse", "curse"
Abolish Poison = "cure poison", "poison"
Cure Poison = "cure poison", "poison"
Rebirth = "rez", "res", "ress"
Regrowth = "heal", "heals"

PALADIN
Blessing of Might = "might", "bom"
Blessing of Wisdom = "wisdom", "wis", "bow"
Blessing of Freedom = "freedom"
Blessing of Light = "light"
Blessing of Sacrifice = "sacrifice"
Blessing of Kings = "kings", "king", "bok"
Blessing of Salvation = "salvation", "bos"
Blessing of Sanctuary = "sanctuary", "bosa"
Blessing of Protection = "protection"
Cleanse = "cleanse", "dispel", "cure"
Purify = "purify", "poison", "disease"
Redemption = "rez", "res", "ress"
Flash of Light = "heal", "heals"
Greater Blessings = "gbom", "gbow", "gbok", "gbos", "gbosa"

SHAMAN
Cure Poison = "cure poison", "poison"
Cure Disease = "cure disease", "disease"
Water Breathing = "water breath*"
Ancestral Spirit = "rez", "res", "ress"
Lesser Healing Wave = "heal", "heals"
Water Walking = "water walk*"

WARLOCK
Unending Breath = "water breath*"
Detect Greater Invisibility = "detect invis", "invis", "invisible"
Ritual of Summoning = "summon"
Create/Trade Healthstone = "healthstone", "hs"
Create/Use Soulstone = "soulstone", "ss"