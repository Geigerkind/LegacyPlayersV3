Accountant 2.0 
--------------------------------------------
v 2.3
* Updated UI Version Number
* Localization file included
_____
v 2.2
* Localization file included 
* Will now track share gold loot while in party.( thanks too Rophy for the awesome code.)
* cleaned up some codes
_____
v 2.1 
* Updated UI Version Number 
* Localization file included 
* Fixed Typos in program. 
_____ 
v 2.0 
* Updated UI Version Number 
* Localization file included