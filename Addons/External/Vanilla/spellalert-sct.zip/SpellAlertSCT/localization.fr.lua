if (GetLocale()=="frFR") then
	-- French
	SA_PTN_SPELL_BEGIN_CAST = "(.+) commence \195\160 lancer (.+).";
	SA_PTN_SPELL_GAINS_X = "(.+) gagne (%d+) (.+).";
	SA_PTN_SPELL_GAINS = "(.+) gagne (.+).";
	SA_PTN_SPELL_TOTEM = "(.+) invoque le Totem (.+).";
	SA_PTN_SPELL_FADE = "(.+) dispara\195\174t de (.+).";
	
	SA_WOTF = "Volont\195\169 du R\195\169prouv\195\169";
	SA_BERSERKER_RAGE = "Rage du Berserker";
	SA_EMOTE_DEEPBREATH = "prend une profonde respiration...";
	SA_AFFLICT_LIVINGBOMB = "Vous subissez les effets de la Bombe Vivante.";
end
