AuldLangSyne combines the functions of CT_PlayerNotes and FriendsFacts.

It will remember information about friends and display it in your friends list while they are offline.

It also allows you to write short notes about these friends.

Type /auld for a (very minimal) command listing.

If you already use CT_PlayerNotes, load the game with both addons enabled, and type "/auld ctimport" to load its notes.  (Due to the way CT_PlayerNotes stores its data, you will have to do this once for each character whose friends you have made notes on.)

TODO:
-Add notes to the ignore and guild panels?
-Streamline display of friend data in friend list.

FAQ:
Q: WTF is the name AuldLangSyne, d00d?
A: Well, Timmy, Auld Lang Syne is the name of a song, mostly sung around New Years Eve, whose opening line goes "should auld acquaintance be forgot, and never brought to mind."  (Literally, "auld lang syne' translates from Scots as "old long since", but may be better rendered as "times gone by".)
In this, as in all things, Wikipedia shall be your guide: http://en.wikipedia.org/wiki/Auld_Lang_Syne
I didn't expect this to be so little known.  ;_;