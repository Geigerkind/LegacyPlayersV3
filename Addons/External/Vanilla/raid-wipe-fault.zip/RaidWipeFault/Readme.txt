Finding Fault for a Raid Wipe (RAID)
1. Be in a raid group 
2. Type /rwf

Finding Fault in a Group Wipe (GROUP)
1. Be in a group 
2. Type /gwf

Not In Zone
This feature finds the current zone of the SELECTED raid member and lists out to the raid the members who are NOT in that zone.
1. Target a raid member 
2. Type /niz

AFK Check  (THIS DOESN'T WORK IN VANILLA)
Checks members of the raid for AFK 
1. Be in a raid 
2. Type /rafk

Raid Roles
Lists the assigned roles of the raid members 
1. Be in a raid 
2. Type /rr

Notes
I added more put-downs to the raid and group wipe generator with version 1.03. 

IF YOU WANT TO CHANGE THE WORDING OF THE BLAME!!!

There are a number of tables with "parts" of the message. Here is the format of the complete message:

WhoDidIt + randomly-selected character from raid/group + "is at fault for wiping the raid. You may be a good" + SPACE + Player's Class + SPACE + Random Newb Zone + COMMA + SPACE + FinishIt.


The two tables you want to add to are:
WhoDidIt and FinishIt

Here are the current tables. Change them in the LUA if you wish:

WhoDidIt = {
"After careful consideration, including a calculation of DPS, Heals, Absolute Tankage, etc... we have determined that",
"We hired a private investigator, Winstonism. LOLUMAD?! He said that",
"Well, the nincompoop",
"Ancient Chinese mystics said that",
"I pulled a fortune out of a cookie that said",
"My puppy told me that",
"Thaddius was positive (lawl) that",
"The Raid Wipe Wall of Shame states that",
"President Obama declares that",
"Ronald Weasley's tea leaves indicate",
"When I sat my sticky butt cheeks down on the canvas, it revealed that",
"The NERD RAGE Committee declares that",
"After watching some ownage and some suckage, it appears that"   --no comma after last item
}


FinishIt = {
"but here you suck!",
"but this ain't your momma's basement!",
"but we ain't serving up Hogger here!",
"but there ain't no Murlocs here!",
"but you may want to start skinning bunny rabbits!",
"so why do you wanna newb up our adventure?",
"but practice on lower levels things, like pincherbugs!",
"but you suck so much, you make Hoover look bad!",
"but you may want your little sister to play next time!",
"but six-year-olds can lay more smackdown than you!",
"but none of the fan boys want your autograph here!"   --no comma after last item
}

