--This add-on picks a random person from the raid and claims that they are the 
--fault for the raid wipe. The test sent ot to the raid will be in four parts:
--
--  WhoDidIt[] + <character's name> + ISATFAULT + <character's class> + NewbZones[] + FinishIt[]
--
--

--constant for the middle part of the message
--
RAID_ISATFAULT = "is at fault for wiping the raid. You may be a good";
GROUP_ISATFAULT = "is at fault for wiping the group. You may be a good";


--other text constants
--
SPACE = " ";
COMMASPACE = ", ";
SPACEINSPACE =  " in ";
OFFLINE = "Offline";


--TABLES ---------------
--

--This table holds the first parts of the message
--add, remove, or modify these to your heart's content
--
WhoDidIt = {
"After careful consideration, including a calculation of DPS, Heals, Absolute Tankage, etc... we have determined that",
"We hired a private investigator, Winstonism. LOLUMAD?! He said that",
"Well, the nincompoop",
"Ancient Chinese mystics said that",
"I pulled a fortune out of a cookie that said",
"My puppy told me that",
"Thaddius was positive (lawl) that",
"The Raid Wipe Wall of Shame states that",
"President Obama declares that",
"Ronald Weasley's tea leaves indicate",
"When I sat my sticky butt cheeks down on the canvas, it revealed that",
"The NERD RAGE Committee declares that",
"After watching some ownage and some suckage, it appears that"   --no comma after last item
}

--This table holds the newb zones listing
--add, remove, or modify these to your heart's content
--
NewbZones = {
"Elwynn Forest",
"Dun Morogh",
"Exedra",
"Tirisfal Glades ",
"Eversong Woods",
"Azuremyst Isle",
"Durotar",
"Teldrassil",
"Mulgore"  --no comma after last item
}

--This table holds the last part of the message
--add, remove, or modify these to your heart's content
--
FinishIt = {
"but here you suck!",
"but this ain't your momma's basement!",
"but we ain't serving up Hogger here!",
"but there ain't no Murlocs here!",
"but you may want to start skinning bunny rabbits!",
"so why do you wanna newb up our adventure?",
"but practice on lower levels things, like pincherbugs!",
"but you suck so much, you make Hoover look bad!",
"but you may want your little sister to play next time!",
"but six-year-olds can lay more smackdown than you!",
"but none of the fan boys want your autograph here!"   --no comma after last item
}


--This table holds the items you wish the 
--item counter to check for
--
MyItems = {
"Crystalized Earth",
"Crystalized Air",
"Crystalized Water",
"Crystalized Fire",
"Crystalized Shadow"
}

--loaded when the lua file is loaded
--
function RaidWipeFault_OnLoad()

	--set up the raid wipe fault slash command
	--
	SlashCmdList["RAIDWIPEFAULT"] = RaidWipeFault_SlashCmdHandler;
	SlashCmdList["NOTINZONE"] = NotInZone_SlashCmdHandler;
	SlashCmdList["GROUPWIPEFAULT"] = GroupWipeFault_SlashCmdHandler;
	SlashCmdList["RAIDROLES"] = RaidRoles__SlashCmdHandler;
	SlashCmdList["RAIDAFK"] = RaidAFK__SlashCmdHandler;
	
	SlashCmdList["INVENTORYCOUNT"] = InventoryCount__SlashCmdHandler;
--100
	SLASH_RAIDWIPEFAULT1 = "/rwf";
	SLASH_NOTINZONE1 = "/niz";
	SLASH_NOTINZONE2 = "/rniz";
	SLASH_GROUPWIPEFAULT1 = "/gwf";
	SLASH_RAIDROLES1 = "/rr";
	--SLASH_RAIDAFK1 = "/rafk";  does not work in vanilla

	--SLASH_INVENTORYCOUNT1 = "/icl";  does not work in vanilla


	--this:RegisterEvent("CHAT_MSG_TEXT_EMOTE");
	--this:RegisterEvent("CHAT_MSG_WHISPER");

	--display on load
	--
	DEFAULT_CHAT_FRAME:AddMessage("Raid Wipe Fault Version 1.05 Loaded");

end


--this function provides a list of specific selected 
--inventory items
--
--called when /icl is invoked
--
function InventoryCount__SlashCmdHandler()

	--DEFAULT_CHAT_FRAME:AddMessage("Selective Inventory List", 0.1, 0.6, 0.1);
	for i=1, table.getn(MyItems) do

		DEFAULT_CHAT_FRAME:AddMessage(MyItems[i] .. ": " .. GetItemCount(MyItems[i],true), 0.1, 0.6, 0.1);

	end

end



--Blaming for raid wipe
--
--called when /rwf is invoked
--
--place the blame!
--
function RaidWipeFault_SlashCmdHandler()

	--get the name and class of a random raid member
	--
	local numRaidMembers = GetNumRaidMembers();
	if (numRaidMembers == 0) then
		return;
	end

	local strFaultyCharName, _, _, _, strFaultyClass = GetRaidRosterInfo(math.random(numRaidMembers));

	--generate and display the message
	--
	SendChatMessage(WhoDidIt[math.random(table.getn(WhoDidIt))] .. SPACE .. strFaultyCharName .. SPACE .. RAID_ISATFAULT .. SPACE .. strFaultyClass .. SPACEINSPACE .. NewbZones[math.random(table.getn(NewbZones))] .. COMMASPACE .. FinishIt[math.random(table.getn(FinishIt))] , "RAID");  

end

--Blaming for group wipe
--
--called when /gwf is invoked
--
--place the blame!
--
function GroupWipeFault_SlashCmdHandler()

	--get the name and class of a random group member
	--
	local numMembers = GetNumPartyMembers() + 1;
	local numMemberSelected = math.random(numMembers);
	--local numMember = 0;
	local strFaultyCharName = "";
	local strFaultyClass = "";

	if (numMemberSelected == numMembers) then
		strFaultyCharName = UnitName("player");
		strFaultyClass = UnitClass("player");
	else
		strFaultyCharName = UnitName("party" .. numMemberSelected);
		strFaultyClass = UnitClass("party" .. numMemberSelected);
	end	
 
	--if (numMembers ~= nil) then
	--local numMember = math.random(numMembers);	
	--SendChatMessage("numMembers: " .. numMemberSelected, "PARTY"); 
	--SendChatMessage("numMember: " .. numMember, "PARTY"); 

			

	--generate and display the message
	--
	SendChatMessage(WhoDidIt[math.random(table.getn(WhoDidIt))] .. SPACE ..strFaultyCharName .. SPACE .. GROUP_ISATFAULT .. SPACE .. strFaultyClass .. SPACEINSPACE .. NewbZones[math.random(table.getn(NewbZones))] .. COMMASPACE .. FinishIt[math.random(table.getn(FinishIt))] , "PARTY");  

end


--What is your raid role?
--
function RaidRoles__SlashCmdHandler()

	local RAIDLEADER = 2;
	local RAIDASSIST = 1;	

	local strMessage = "test";
	local blnHasARole = false;

	local strName = "";
	local intRank = 0;
	local intSubGroup = 0;
	local strPlayerRole = "";
	local blnIsMasterLooter = false;

	local strCommaSpot = "";
	local intNumRaidMembers = GetNumRaidMembers();


	SendChatMessage("Raid Roles Are As Follows", "RAID"); --, CURRENTLANG,"RAID");

	for i=1, intNumRaidMembers do

		strMessage = "";
		blnHasARole = false;
		strCommaSpot = "";

		strName, intRank, intSubGroup, _, strClass, _, _, _, _, strPlayerRole, blnIsMasterLooter = GetRaidRosterInfo(i);
		
		strMessage = strName .. ": ";
		
		--if (strRank ~= 0) then 

			if (intRank == RAIDLEADER) then
				strMessage = strMessage .. "Raid Leader";
				blnHasARole = true;
				strCommaSpot = ", ";
			elseif (intRank == RAIDASSIST) then
				strMessage = strMessage .. "Raid Assist";
				blnHasARole = true;
				strCommaSpot = ", ";
			end

		--end 

		--SendChatMessage(strMessage, "RAID"); 

		if (strPlayerRole ~= nil) then 
			strMessage = strMessage .. strCommaSpot .. strPlayerRole;
			blnHasARole = true;
			strCommaSpot = ", ";
		end
 
		--SendChatMessage(strMessage, "RAID"); 
		if (blnIsMasterLooter) then 
			strMessage = strMessage .. strCommaSpot .. "Master Looter";
			blnHasARole = true;
		end 
		
		if (blnHasARole) then
			SendChatMessage(strMessage, "RAID"); 
		end

	end

end


--Are you AFK???
--
--called when /rafk invoked
--
--checks to see who all is in the zone of the selected character
--
function RaidAFK__SlashCmdHandler()


	--get the targeted person's name
	--
	local character = UnitName("target");

	local strCharName = "";	
	local strZone = "";
	local strCharNameCheck = "";	
	local strZoneCheck = "";
	local blnSomeoneAFK = false;

	local blnAFK = false;	

	--if nothing selected
	--get out
	if (character == "") then
		return;
	end


	--send initial chat
	--
	SendChatMessage("Checking for AFK's...", "RAID"); 

	--now we know what zone to check for, loop through the 
	--raid members again to completion
	--
	for j=1, GetNumRaidMembers() do

		--get the next char and zone
		--
		strCharNameCheck, _, _, _, _, _, strZoneCheck = GetRaidRosterInfo(j);
			
		--not in the required zone?
		--send the message
		blnAFK = UnitIsAFK(strCharNameCheck);
		if (blnAFK) then
			blnSomeoneAFK = true;
			SendChatMessage(strCharNameCheck .. " is AFK in " .. strZoneCheck, "RAID"); 
		end
	end

	--if there were folks not in the zone...
	if (blnSomeoneAFK) then
		SendChatMessage("If your name was mentioned, please wake up!", "RAID"); 
	else
		SendChatMessage("Nice! Nobody is AFK!" .. strZone , "RAID"); --, CURRENTLANG,"RAID");
	end

end




--Are you in the zone???
--
--called when /niz invoked
--
--checks to see who all is in the zone of the selected character in RAID
--
function NotInZone_SlashCmdHandler()

	--get the targeted person's name
	--
	local character = UnitName("target");

	local strCharName = "";	
	local strZone = "";
	local strCharNameCheck = "";	
	local strZoneCheck = "";
	local blnSomeoneNotThere = false;	

	--if nothing selected
	--get out
	if (character == "") then
		return;
	end

	--loop through the players in the raid
	--
	for i=1, GetNumRaidMembers() do

		--get the name and zone
		--
		strCharName, _, _, _, _, _, strZone = GetRaidRosterInfo(i);

		--if the current character's name matches the selected character's name
		--
		if (character == strCharName) then

			--send initial chat
			--
			SendChatMessage("Checking to see if folks are in " .. strZone .. " as they should be...", "RAID"); 

			--now we know what zone to check for, loop through the 
			--raid members again to completion
			--
			for j=1, GetNumRaidMembers() do

				--get the next char and zone
				--
				strCharNameCheck, _, _, _, _, _, strZoneCheck = GetRaidRosterInfo(j);
			
				--not in the required zone?
				--send the message
				if (strZoneCheck ~= strZone) then
					blnSomeoneNotThere = true;
					if (strZoneCheck == OFFLINE) then
						SendChatMessage(strCharNameCheck .. " is " .. strZoneCheck, "RAID"); 
					else
						SendChatMessage(strCharNameCheck .. " is in " .. strZoneCheck, "RAID"); 
					end
				end
			end

			--if there were folks not in the zone...
			if (blnSomeoneNotThere) then
				SendChatMessage("If your name was mentioned, please get to " .. strZone .. " ASAP!" , "RAID"); 
			else
				SendChatMessage("Nice! Everyone is here in " .. strZone , "RAID"); --, CURRENTLANG,"RAID");
			end
			return;
		end
	end


end
