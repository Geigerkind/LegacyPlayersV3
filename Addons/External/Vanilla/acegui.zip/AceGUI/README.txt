_____________________________________________________________________________________

AceGUI

Author:   Turan (turan@wowace.com)
Version:  0.100
Release:  10/09/2005
Website:  http://www.wowace.com
_____________________________________________________________________________________


AceGUI is a toolkit for creating and working with GUI components.

_____________________________________________________________________________________

FEATURES
_____________________________________________________________________________________

- Creates an object model XML objects so they are more easily manipulated.
- Default templates.
- A replacement dropdown template that implements a scrollbox and isn't limited to
  32 elements in the list.

_____________________________________________________________________________________

VERSION HISTORY
_____________________________________________________________________________________

[2005-10-09] 0.100
- Test release
