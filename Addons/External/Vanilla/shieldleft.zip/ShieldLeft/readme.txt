ShieldLeft by VincentGdG
------------------------

This addon is based on CT_SHIELDMOD, but greatly enhanced.

What does it do?

Priests, Warlocks and Mages have shields that absorb any damage they would take upto a certain amount.
Unfortunately all you see when you activate the shield is how long it will last IF it is not "used up" by getting hit from a mob.

Upon logging in this addon scans the spell book for the shield spell of this character and reads the damage the shield can take from the tooltip. When playing a warlock it rescans everytime a demon is cast.
A rescan is also done when you learn a new spell.

Then whenever a mob hits you, the medium strength for melee and ranged hits is calculated and stored.
In verbose mode you will see the calculated new medium whenever there is a new one.

When you activate your shield, a small frame showing the shield charge left comes up near your minimap.
Whenever a stored mob hits the shield the charge left for the shied is reduced by the median that is stored for this mob/attack.

So you always know how long your shield will last.


Slash commands:
---------------
/shieldleft reset - deletes all saved data
/shieldleft info - shows the verbose mode, the shield strength and all stored mobs with their medium hits.
/shieldleft verbose - toggles verbose mode
/shieldleft debug - toggles debug mode
