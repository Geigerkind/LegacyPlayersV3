Simple Self Cast 1.10
by Zugreg

-- English --
This mod is an easy solution for casting heals and buffs on yourself.
Whenever you would get a target selction cursor without this mod, the spell is cast on yourself with this mod. So, if you have a friendly target selected you will cast the spell on the target, else you will cast the spell on yourself.

This mod works with all language versions of World of Warcraft.

You have the following command options:
/ssc - Toggles self casting.
/ssc help - Displays this message.
/ssc enable - Enables self casting.
/ssc disable - Disables self casting.
/ssc nosplash - Prevents the splash message from being displayed.
/ssc splash - Displays the splash message at each startup.

-- German --
Simple Self Cast ist ein Mod um Buff- oder Heilzauber ohne den Auswahlcursor auf sich selber zu zaubern.

Immer wenn ihr, ohne dieses Mod, einen Auswahlcursor bekommen w�rdet, wird der Zauber mit Simple Self Cast auf euch gezaubert.

Das Mod kann man mit folgenden Befehlen steuern:
/ssc - Umkehren des Self Cast Modus.
/ssc help - Diese Nachricht.
/ssc enable - Aktivieren des Self Cast Modus.
/ssc disable - Deaktivieren des Self Cast Modus.
/ssc nosplash - Die Begr��ungsnachricht wird nicht dagestellt.
/ssc splash - Die Begr��ungsnachricht wird dagestellt.

-- Versions --
v1.10
-changed the targeting behaviour a little bit:
 When targeting a friendly unit which is too far away the spell isnt cast on yourself. 
 You get a targeting cursor instead.(thanks to Wackee for the idea)
v1.01
-now checking if messages can be printed
v1.0
-initial Version
