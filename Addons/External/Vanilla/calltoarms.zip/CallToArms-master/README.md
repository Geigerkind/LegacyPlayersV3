# CallToArms
Group Hosting, Finding Addon for WoW (vanilla)

## Options
`/cta` or use the minimap icon to show UI

## FuBar plugin 
Optional FuBar plugin available at [FuBar_CTAFu](https://github.com/Road-block/FuBar_CTAFu)  
If the FuBar plugin is enabled it will automatically hide the CTA minimap icon.
