LazyRogue README

Please visit http://ithilyn.com/pmwiki/index.php?n=LazyRogue.LazyRogue
for a full set of documentation for LazyRogue.

Thanks,

Ithilyn

