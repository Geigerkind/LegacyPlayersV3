--german translation 09.05.05

if( GetLocale() == "deDE" ) then

FRIENDSX_BUTTON_LABEL = "Freunde X: ";
FRIENDSX_MENU_TEXT = "Freunde X";
FRIENDSX_BUTTON_TEXT = "%s"..TitanUtils_GetHighlightText("/").."%s"..(" (").."%s"..(")");
FRIENDSX_TOOLTIP = "Freunde X"; 
FRIENDSX_NOBODY_ONLINE_BUTTON = "o";
FRIENDSX_NOBODY_ONLINE_TOOLTIP = "Sicher das du auch Freunde hast? ;)";
FRIENDSX_FRIENDS = "Freunde";
FRIENDSX_GUILD = "Gilde";
FRIENDSX_FRIENDS_OPTIONS = "Freunde Optionen";
FRIENDSX_FRIENDS_OPTIONS_SHOW_ONLINE_TOOLTIP = "Zeige online Freunde im Tooltip";
FRIENDSX_FRIENDS_OPTIONS_COUNT = "Freunde z\195\164hlen";
FRIENDSX_FRIENDS_OPTIONS_MARK_AREA = "Markiere Freunde in der gleichen Gegend";
FRIENDSX_GUILD_OPTIONS = "Gilde Optionen";
FRIENDSX_GUILD_OPTIONS_COUNT = "Gilde z\195\164hlen";
FRIENDSX_GUILD_OPTIONS_SHOW_ONLINE_TOOLTIP = "Zeige online Gilden Mitglieder im Tooltip"; 
FRIENDSX_GUILD_OPTIONS_MARK_AREA = "Markiere Gilden Mitglieder in der gleichen Gegend";



end