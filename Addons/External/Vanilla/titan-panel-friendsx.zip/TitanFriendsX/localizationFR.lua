--frensh translation UPDATED 09.05.05
--thanks MoKo :))

if( GetLocale() == "frFR" ) then

FRIENDSX_BUTTON_LABEL = "Amis X: ";
FRIENDSX_MENU_TEXT = "Amis X";
FRIENDSX_BUTTON_TEXT = "%s"..TitanUtils_GetHighlightText("/").."%s"..(" (").."%s"..(")");
FRIENDSX_TOOLTIP = "Amis X"; 
FRIENDSX_NOBODY_ONLINE_BUTTON = "o";
FRIENDSX_NOBODY_ONLINE_TOOLTIP = "Etes-vous certain d'avoir des amis ?";
FRIENDSX_FRIENDS = "Amis";
FRIENDSX_GUILD = "Guilde";
FRIENDSX_FRIENDS_OPTIONS = "Options de Friends";
FRIENDSX_FRIENDS_OPTIONS_SHOW_ONLINE_TOOLTIP = "Afficher les amis en ligne dans la fen\195\170tre";
FRIENDSX_FRIENDS_OPTIONS_COUNT = "Compter les amis";
FRIENDSX_FRIENDS_OPTIONS_MARK_AREA = "Mark friends in same area";
FRIENDSX_GUILD_OPTIONS = "Guild Options";
FRIENDSX_GUILD_OPTIONS_COUNT = "Count guild member";
FRIENDSX_GUILD_OPTIONS_SHOW_ONLINE_TOOLTIP = "Show online guild member in tooltip";
FRIENDSX_GUILD_OPTIONS_MARK_AREA = "Mark guild members in same area";

end