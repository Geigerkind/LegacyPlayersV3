--english translation 29.04.05

FRIENDSX_BUTTON_LABEL = "Friends X: ";
FRIENDSX_MENU_TEXT = "Friends X";
FRIENDSX_BUTTON_TEXT = "%s"..TitanUtils_GetHighlightText("/").."%s"..(" (").."%s"..(")");
FRIENDSX_TOOLTIP = "Friends X"; 
FRIENDSX_NOBODY_ONLINE_BUTTON = "o";
FRIENDSX_NOBODY_ONLINE_TOOLTIP = "Sure you have any friends? ;)";
FRIENDSX_FRIENDS = "Friends";
FRIENDSX_GUILD = "Guild";
FRIENDSX_FRIENDS_OPTIONS = "Friend Options";
FRIENDSX_FRIENDS_OPTIONS_SHOW_ONLINE_TOOLTIP = "Show online friends in Tooltip";
FRIENDSX_FRIENDS_OPTIONS_COUNT = "Count Friends";
FRIENDSX_FRIENDS_OPTIONS_MARK_AREA = "Mark friends in same area";
FRIENDSX_GUILD_OPTIONS = "Guild Options";
FRIENDSX_GUILD_OPTIONS_COUNT = "Count guild member";
FRIENDSX_GUILD_OPTIONS_SHOW_ONLINE_TOOLTIP = "Show online guild member in tooltip";
FRIENDSX_GUILD_OPTIONS_MARK_AREA = "Mark guild members in same area";