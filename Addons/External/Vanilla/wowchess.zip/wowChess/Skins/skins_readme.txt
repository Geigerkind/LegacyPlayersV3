The chess board skinning method relies on file names.

wowChess/Skins/Standard/wowChess_bd.tga

This is the file that contains the black bishop, b=bishop d=dark.

p = pawn
r = rook
n = knight
b = bishop
q = queen
k = king
t = texture for board

d = dark
l = light

Each file is a 64x64 32-bit RLE-compressed TGA.

Each skin folder may have a Sounds folder with files in the format:


wowChess/Skins/Warcraft2/Sounds/wowChess_bd_down1.wav

where "up" is for picking the piece, and "down" is for moving it. You can have up to 8 sounds numbered 1 thru 8.