﻿BANANALOC_RESET_BUTTON_POSITIONS = "Reset button positions";

BANANA_LAYOUT1 = "8 buttons in a horizontal line"
BANANA_LAYOUT2 = "2 lines 4 colums"
BANANA_LAYOUT3 = "4 lines 2 colums"
BANANA_LAYOUT4 = "8 buttons testin a vertical line"
BANANA_LAYOUT5 = "8 free moveable buttons"
