FuBar - DamageMetersFu v1.2.1

Author: chuckg (chuckg@blindmuse.com)
Realm: Blindchuck <Ropetown>, Burning Legion
Website: http://chuckg.wowinterface.com
Date: 2006-05-27 02:07:46

DamageMetersFu provides DamageMeters data to FuBar which was 
previously unavailable unless the DamageMeters window was open.  
One of the advantages is that it allows you display multiple "types" 
of damage in relationship to the player, rather than just one at a time.

The idea was taken from the TitanDamageMeters mod which is packaged 
with DamageMeters, though the code has been completely re-written; 
it was done with performance in mind.  It has been tested to work 
with version 4.2.1 and 4.3.0 (Beta 5).

Leave a message for me in the Ropetown (ropetown.com) forums or 
at WoWInterface bug report if you have any issues/ideas/updates/etc. 
to share with me.

TO INSTALL: Put the FuBar_MoneyFu folder into
	\World of Warcraft\Interface\AddOns\

You will need a working version of DamageMeters, which can be
found at the following address: http://www.curse-gaming.com/mod.php?addid=791