-- Translate everything within ""-characters (for example Quest Levels in the text "Quest Levels")

CT_QUESTLEVELS_MODNAME = "Quest Levels";
CT_QUESTLEVELS_SUBNAME = "On/Off Toggle";
CT_QUESTLEVELS_TOOLTIP = "Shows quest levels in the Quest Log.";

CT_QUESTLEVELS_ON = "<CTMod> Quest levels are now shown in the Quest Log.";
CT_QUESTLEVELS_OFF = "<CTMod> Quest levels are no longer shown in the Quest Log.";
