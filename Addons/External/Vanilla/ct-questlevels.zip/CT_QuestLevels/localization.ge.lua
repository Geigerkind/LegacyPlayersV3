if ( GetLocale() == "deDE" ) then
	-- Credits to Hj�rvar�r for these

	CT_QUESTLEVELS_MODNAME = "Quest Levels";
	CT_QUESTLEVELS_SUBNAME = "Ein/Aus Umschalter";
	CT_QUESTLEVELS_TOOLTIP = "Zeigt die Quest-Stufen im Quest-Log an.";

	CT_QUESTLEVELS_ON = "<CTMod> Die Quest-Stufen werden nun im Quest-Log angezeigt.";
	CT_QUESTLEVELS_OFF = "<CTMod> Die Quest-Stufen werden nicht mehr im Quest-Log angezeigt.";

end