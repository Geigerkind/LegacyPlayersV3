if not StrategosBattleground_Localizations then
    StrategosBattleground_Localizations = {}
end

-- Translation by Alexis Chu aka Zando from Nostalgeek server

StrategosBattleground_Localizations.frFR = {
    WARSONG_FLAG_GROUND = "À TERRE",
    ARATHI_BOARD_STALL = "Égalité",
    ARATHI_BOARD_WINNING_FACTION0 = "La Horde gagne dans : %time",
    ARATHI_BOARD_WINNING_FACTION1 = "L'Alliance gagne dans : %time",
    ARATHI_BOARD_WIN_FACTION0 = "La Horde remporte la victoire !",
    ARATHI_BOARD_WIN_FACTION1 = "L'Alliance remporte la victoire !",
    WARSONG_LOWHEALTH_CHAT_WARN0 = "\124cffff0000\124Hplayer:%pname\124h[Horde Flag Carrier]\124h\124r a moins de %health% de vie !",
    WARSONG_LOWHEALTH_CHAT_WARN1 = "\124cff00b0ff\124Hplayer:%pname\124h[Alliance Flag Carrier]\124h\124r a moins de %health% de vie !",
    WARSONG_LOWHEALTH_CHAT_WARN0_ALT = "Le porteur de la Horde a moins de %health% de vie !",
    WARSONG_LOWHEALTH_CHAT_WARN1_ALT = "Le porteur de l'Alliance a moins de %health% de vie !",
    BG_START_IN_CHAT = "Début dans : %time",
    BG_START_IN_UI = "[BG] Début dans ",
    SETTINGS_TITLE = "Paramètres Strategos Battleground",
    SETTINGS_GENERAL_SECTION = "Général",
    SETTINGS_AUTO_JOIN = "Inscription automatique",
    SETTINGS_AUTO_JOIN_GROUP = "Inscription en groupe automatique",
    SETTINGS_WSG_SECTION = "Goulet des Warsong",
    SETTINGS_WSG_CARRIERS_SIDE = "Position du cadre du porteur :",
    SETTINGS_WSG_CARRIERS_SIDE_LEFT = "Gauche",
    SETTINGS_WSG_CARRIERS_SIDE_RIGHT = "Droite",
    SETTINGS_WSG_CARRIERS_HEALTH_STYLE = "Affichage de la santé du porteur :",
    SETTINGS_WSG_CARRIERS_HEALTH_STYLE_COLOR = "Couleur",
    SETTINGS_WSG_CARRIERS_HEALTH_STYLE_BAR = "Barre",
    SETTINGS_WSG_CARRIERS_HEALTH_WARNS = "Avertissements santé du porteur :",
    SETTINGS_WSG_CARRIERS_HEALTH_WARNS_ENABLED = "ON",
    SETTINGS_WSG_CARRIERS_HEALTH_WARNS_DISABLED = "OFF",
    SETTINGS_WSG_CARRIERS_HEALTH_WARNS_NO_LINK = "Noms des joueurs en lien"
}
