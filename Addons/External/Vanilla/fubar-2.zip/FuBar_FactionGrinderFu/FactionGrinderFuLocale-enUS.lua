local L = AceLibrary("AceLocale-2.0"):new("FuBar_ArgentDawnGrinderFu")

L:RegisterTranslations("enUS", function() return {

} end)
