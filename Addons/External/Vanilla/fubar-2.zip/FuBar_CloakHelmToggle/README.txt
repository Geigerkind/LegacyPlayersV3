FuBar - CloakHelmToggle v0.4.0

Author: brotherhobbes (brotherhobbes@gmail.com)
Release Date: 2006-05-12

Toggles player's Cloak and Helm display.

TO INSTALL: Put the FuBar_ExampleFu folder into
	\World of Warcraft\Interface\AddOns\

If you find _any_ bugs, feel free to submit them at
http://www.wowinterface.com/

If you want to request any features, feel free to submit your ideas at
http://www.wowinterface.com/