FactionItemsFu v2.0.1 $Revision: 16363 $ 
 
Author: lordrhys (lordrhystower@gmail.com) 

$Date: 2006-11-08 15:56:22 -0500 (Wed, 08 Nov 2006) $  

Optional Dependencies: Ace2,FuBar  
Embedded Libraries: TabletLib-2.0 , DewDrop-2.0 ,Crayon-2.0, AceEvent-2.0,AceLibrary,AceDB-2.0,
AceAddon-2.0,AceConsole-2.0,FuBarPlugin-2.0

Optional Addons: ADGrinder	


TO INSTALL: Put the FuBar_FactionItemsFu folder into 	
\World of Warcraft\Interface\AddOns\  


------------------------------------------------------------------------------- 
This is an release version for Ace2. 
-------------------------------------------------------------------------------

This is an Addon to keep track of Items you have for Faction Quests, 
Checks items for various factions like Wildhammer Clan - Troll Necklaces, Timbermaw Clan - Winterfall 
Beads and Headresses, various tokens, coins, and other things needed for Cenarion Circle and Zandalar 
Quest rewards. You can add or remove the available factions from the list of monitored factions in the 
addon's FuBar menu.Currently you just select Faction you want to monitor items for.


 Items are tracked by your current faction rating so you will only have items 
in your list that are useful to the level of faction that you're in (i.e. once past neutral with Darkmoon Faire
you won't see all the low level items just what you can turn in.).

The panel display can be configured to display an icon only, icon with addon name, icon with addon name and a progressive
count of items in 4 formats (bags, bank, bags + bank, or bank/bags).


If you have Argent Dawn Grinder installed you can click on Panel display and it will open the ADGrinder options frame.


Future:
	Future plans include similar displays to ADGrinder for other factions, also if you can craft items for 
Darkmoon Faire it will display that capability.

