﻿--[[ THIS FILE IS ENCODED IN UTF-8 ]]--

--[[
	Bagnon Localization file
	
	TODO:
		Add some frame strings and other things
		I could probably Babelfish the translation, but most likely it would insult someone's 
			mother or something.
--]]

--[[
	Chinese (Traditional)   by   che
--]]

if ( GetLocale() == "zhTW" ) then
	--fifth return for GetItemInfo(id)
	BAGNON_ITEMTYPE_CONTAINER = "容器";
	
	--sixth return for GetItemInfo(id)
	BAGNON_SUBTYPE_SOULBAG = "靈魂碎片背包";
	BAGNON_SUBTYPE_BAG = "容器";
end