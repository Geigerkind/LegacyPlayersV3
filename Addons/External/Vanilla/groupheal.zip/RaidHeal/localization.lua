RaidHeal_Strings = {};

RaidHeal_Strings.NONE = "None";
RaidHeal_Strings.LEFTTOP = "Left Side - Top";
RaidHeal_Strings.LEFTBOTTOM = "Left Side - Bottom";
RaidHeal_Strings.RIGHTTOP = "Right Side - Top";
RaidHeal_Strings.RIGHTBOTTOM = "Right Side - Bottom";
RaidHeal_Strings.SPACING_OPTIONS = "Button Spacing Options";
RaidHeal_Strings.AUTOMATIC = "Automatic";
