INSTALLATION
Unzip the LootFilter folder in your AddOns directory.

USAGE
/lf or /lfr or /lootfilter , brings up the control panel
/lf help , to view the commandline options
