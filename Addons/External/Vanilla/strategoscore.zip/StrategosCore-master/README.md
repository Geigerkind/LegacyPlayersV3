# Strategos

## Intro:

Strategos is an addon for Vanilla World of Warcraft (1.12).
