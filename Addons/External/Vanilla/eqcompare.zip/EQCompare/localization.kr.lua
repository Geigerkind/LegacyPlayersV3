--[[ $Id: localization.kr.lua 13753 2006-10-13 00:31:40Z fenlis $ ]]--

if (GetLocale() == "koKR") then
	INVTYPE_GUN="총"
	INVTYPE_CROSSBOW="석궁"
	INVTYPE_WAND="마법봉"
	INVTYPE_THROWN="투척 무기"
	INVTYPE_GUNPROJECTILE="투사체"
	INVTYPE_BOWPROJECTILE="투사체"

	EQCompare_KEY_DESC="사용자 키가 눌려진 동안에만 비교 툴팁이 표시됩니다.."
	EQCompare_RESET_DESC="모든 설정을 초기화합니다."
	EQCompare_RESET="모든 설정이 초기화 되었습니다."
	EQCompare_HOVERLINK_DESC="대화창에 링크위에 마우스를 올렸을 때 툴팁을 표시합니다."
	EQCompare_HOVERLINK_SAFE_DESC="링크 툴팁을 위해 안전 모드를 사용합니다."
end
