﻿--[[ $Id: localization.lua 13542 2006-10-10 20:04:56Z hshh $ ]]--

INVTYPE_GUN="Gun"
INVTYPE_CROSSBOW="Crossbow"
INVTYPE_WAND="Wand"
INVTYPE_THROWN="Thrown"
INVTYPE_GUNPROJECTILE="Projectile"
INVTYPE_BOWPROJECTILE="Projectile"

EQCompare_KEY_DESC="Only display compare tooltip while holding custom key."
EQCompare_RESET_DESC="Reset All settings."
EQCompare_RESET="All settings are resetted."
EQCompare_HOVERLINK_DESC="Enable display tooltip while hovering hyperlink in ChatFrame."
EQCompare_HOVERLINK_SAFE_DESC="Use safe mode to display hovering hyperlink."
