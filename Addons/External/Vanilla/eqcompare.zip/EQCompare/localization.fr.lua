﻿--[[ $Id: localization.fr.lua 13507 2006-10-10 09:12:24Z hshh $ ]]--

if (GetLocale() == "frFR") then
	INVTYPE_GUN = "Arme \195\160 feu"
	INVTYPE_CROSSBOW="Arbal\195\168te"
	INVTYPE_WAND = "Baguette"
	INVTYPE_THROWN = "Armes de jet"
	INVTYPE_GUNPROJECTILE="Projectile"
	INVTYPE_BOWPROJECTILE="Projectile"
end
