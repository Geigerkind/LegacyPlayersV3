--[[ $Id: localization.cn.lua 13542 2006-10-10 20:04:56Z hshh $ ]]--

if (GetLocale() == "zhCN") then
	INVTYPE_GUN = "枪械"
	INVTYPE_CROSSBOW="弩"
	INVTYPE_WAND = "魔杖"
	INVTYPE_THROWN = "投掷武器"
	INVTYPE_GUNPROJECTILE = "弹药"
	INVTYPE_BOWPROJECTILE = "弹药"

	EQCompare_KEY_DESC="当按住设定的按键时才显示对比信息."
	EQCompare_RESET_DESC="重置所有选项."
	EQCompare_RESET="所有选项已重置."
	EQCompare_HOVERLINK_DESC="当鼠标移动到聊天窗口的超链接时自动显示信息."
	EQCompare_HOVERLINK_SAFE_DESC="使用安全模式显示鼠标所在处超链接信息."
end
