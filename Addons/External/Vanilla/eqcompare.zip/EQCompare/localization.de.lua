﻿--[[ $Id: localization.de.lua 13507 2006-10-10 09:12:24Z hshh $ ]]--

if (GetLocale() == "deDE") then
	INVTYPE_GUN = "Schusswaffe"
	INVTYPE_CROSSBOW="Armbrust"
	INVTYPE_WAND = "Zauberstab"
	INVTYPE_THROWN = "Geworfen"
	INVTYPE_GUNPROJECTILE="Projektil Kugel"
	INVTYPE_BOWPROJECTILE="Projektil Pfeil"
end
