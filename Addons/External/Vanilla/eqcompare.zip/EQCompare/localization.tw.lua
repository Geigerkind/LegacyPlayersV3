--[[ $Id: localization.tw.lua 13507 2006-10-10 09:12:24Z hshh $ ]]--

if (GetLocale() == "zhTW") then
	INVTYPE_GUN = "槍械";
	INVTYPE_WAND = "魔杖";
	INVTYPE_CROSSBOW = "弩";
	INVTYPE_THROWN = "投擲武器";
	INVTYPE_GUNPROJECTILE = "彈藥";
	INVTYPE_BOWPROJECTILE = "箭";
end
