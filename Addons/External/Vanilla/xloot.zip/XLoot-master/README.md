# Xloot

THIS ADDON IS NO LONGER GETTING UPDATED SINCE pfUI GOT IT'S OWN LOOTFRAME IMPLEMENTED

You can get it here: https://github.com/shagu/pfUI

Xloot for 1.12 Shagu Style
This is a modified version of Xloot to make it more in style with Shagu's addons like pfUI.

Rename the addon to just Xloot without the "-master" and put it in .../World of Warcraft/Interface/Addons.

Please note that I dont take credit for either art or code.

<a href="http://imgur.com/3ahNHHe"><img src="http://i.imgur.com/3ahNHHe.png" title="source: imgur.com" /></a>
