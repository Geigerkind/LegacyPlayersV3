if ( GetLocale() == "frFR" ) then
	ANKHCT_LOCAL_SHAMAN = "Chaman"
	ANKHCT_LOCAL_ANKH = "Ankh"
	ANKHCT_LOCAL_REINCARNATION = "R\195\169incarnation"
	ANKHCT_LOCAL_IMPROVED_REINCARNATION = "R\195\169incarnation am\195\169lior\195\169e"
	ANKHCT_LOCAL_TOTEM_OF_REBIRTH = "Totem de renaissance"
end