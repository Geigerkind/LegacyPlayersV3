if ( GetLocale() == "deDE" ) then
	ANKHCT_LOCAL_SHAMAN = "Schamane"
	ANKHCT_LOCAL_ANKH = "Ankh"
	ANKHCT_LOCAL_REINCARNATION = "Reinkarnation"
	ANKHCT_LOCAL_IMPROVED_REINCARNATION = "Verbesserte Reinkarnation"
	ANKHCT_LOCAL_TOTEM_OF_REBIRTH = "Totem der Wiedergeburt"
end