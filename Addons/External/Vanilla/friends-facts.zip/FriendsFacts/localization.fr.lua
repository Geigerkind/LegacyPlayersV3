-- Version : French ( by Sasmira )
-- Last Update : 03/20/2005

if ( GetLocale() == "frFR" ) then

-- For "name location" in friends list, should be moved into Cosmos localization once that has been stabilized
FRIENDS_FACTS_OFFLINE_TEMPLATE		= "|cffbbbbbb%s- %s - Pas en ligne|r";
FRIENDS_FACTS_OFFLINE_TEMPLATE_SHORT	= "|cffbbbbbb%s- %s|r";

end