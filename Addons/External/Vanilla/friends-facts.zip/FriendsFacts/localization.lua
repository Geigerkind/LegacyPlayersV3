-- Version : English (by AnduinLothar)
-- Last Update : 02/19/2005

-- For "name location" in friends list, should be moved into Cosmos localization once that has been stabilized
FRIENDS_FACTS_OFFLINE_TEMPLATE		= "|cffbbbbbb%s- %s - Offline|r";
FRIENDS_FACTS_OFFLINE_TEMPLATE_SHORT	= "|cffbbbbbb%s- %s|r";