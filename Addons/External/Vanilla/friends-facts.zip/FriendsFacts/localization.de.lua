-- Version : German (by StarDust)
-- Last Update : 02/21/2005

if ( GetLocale() == "deDE" ) then

	-- For "name location" in friends list, should be moved into Cosmos localization once that has been stabilized
	FRIENDS_FACTS_OFFLINE_TEMPLATE		= "|cffbbbbbb%s- %s - Offline|r";
	FRIENDS_FACTS_OFFLINE_TEMPLATE_SHORT	= "|cffbbbbbb%s- %s|r";

end