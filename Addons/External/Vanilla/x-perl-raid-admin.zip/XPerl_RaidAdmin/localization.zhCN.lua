﻿

if (GetLocale() == "zhCN") then

XPERL_ADMIN_TITLE		= "X-Perl 团队管理"

XPERL_BUTTON_ADMIN_PIN		= "固定窗口"
XPERL_BUTTON_ADMIN_LOCKOPEN	= "窗口始终打开"
XPERL_BUTTON_ADMIN_SAVE1	= "保存名单"
XPERL_BUTTON_ADMIN_SAVE2	= "以指定的名字保存当前的队伍结构。如果未输入名字则以当前时间为名。"
XPERL_BUTTON_ADMIN_LOAD1	= "载入名单"
XPERL_BUTTON_ADMIN_LOAD2	= "载入所选择的名单。所保存的名单中的任何团队成员如果已经不在团队中，则以相同职业的代之。"
XPERL_BUTTON_ADMIN_DELETE1	= "删除名单"
XPERL_BUTTON_ADMIN_DELETE2	= "删除选选择的名单"
XPERL_BUTTON_ADMIN_STOPLOAD1	= "停止载入"
XPERL_BUTTON_ADMIN_STOPLOAD2	= "放弃载入名单"

XPERL_LOAD			= "载入"

XPERL_SAVED_ROSTER		= "保存名单为 '%s'"
XPERL_ADMIN_DIFFERENCES		= "%d 个成员不在当前名单"
XPERL_NO_ROSTER_NAME_GIVEN	= "没有该名字的名单"
XPERL_NO_ROSTER_CALLED		= "保存的名单中没有 '%s'"

XPERL_RAID_TOOLTIP_NOCTRA	= "没有发现CTRA"

end
