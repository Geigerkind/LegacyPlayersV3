---     English     ---
--- by Tekkub (duh) ---
TITAN_ITEMDED_MENU_TEXT = "Itemized Deductions"
TITAN_ITEMDED_TOOLTIP_TITLE = "Itemized Deductions"
TITAN_ITEMDED_TOOLTIP_BAGS = "\nOpen bags\tClick\n";
TITAN_ITEMDED_TOOLTIP_DESTROY = "Destroy item\tShift-click\n";
TITAN_ITEMDED_TOOLTIP_IGNORE = "Ignore item\tDoubleclick\nAlways ignore\tAlt-Doubleclick\n\n";
TITAN_ITEMDED_TOOLTIP_SELL = "Shift-left-click to sell item\n";
TITAN_ITEMDED_NOITEMDESTROY = "No item to destroy";
TITAN_ITEMDED_NOITEMIGNORE = "No item to ignore";

