-- Version : French ( by Sasmira )
-- Last Update : 03/29/2005

if ( GetLocale() == "frFR" ) then

CT_MAIL_HELP = "compl\195\169tez autant de cases que vous souhaitez. Chaque article sera envoy\195\169 s\195\169par\195\169ment dans un courrier au destinataire, avec le sujet que vous sp\195\169cifiez et qui sera attach\195\169 au nom de l\'objet plus un num\195\169ro, ( Pour exemple : <Sujet> [Barre d\'Or x10]). L\'affranchissement combin\195\169 est montr\195\169 dans le coin en haut \195\60 droite. Vous pouvez ALT-Clic Gauche sur les objets dans votre inventaire afin de les ajouter \195\60 la liste automatiquement.";

CT_MAIL_SEND = "Envoyer un Message";
CT_MAIL_SENDBUTTON = "Envoi";
CT_MAIL_CANCELBUTTON = "Annuler";

CT_MAIL_SENDINFO = "Etes vous sur de vouloir envoyer ce message ? La Somme Totale pour les messages post\195\169s sera de :";
CT_MAIL_SENDINFO2 = "Vous avez envoy\195\169 :";
CT_MAIL_ITEMS = "Objet(s)";
CT_MAIL_ABORT = "Abandonner";

CT_MAIL_ITEMNUM = "Objet %d hors de %d.";
CT_MAIL_SENDING = "Envoi de Messages |c00FFFFFF%d|r/|c00FFFFFF%d|r...";
CT_MAIL_DONESENDING = "Envoi de |c00FFFFFF%d|r message(s) termin\195\169(s) !";
CT_MAIL_ABORTED = "Abandonn\195\169. |c00FFFFFF%d|r/|c00FFFFFF%d|r de message(s) a \195\169t\195\169 envoy\195\169.";
CT_MAIL_ERROR = "Une Erreur c\'est produite dans CT_MailMod. Envoyez un rapport de bug \195\160 l\'url suivante : http://www.ctmod.net";

CT_MMINBOX_OPENSELECTED = "Ouvrir la s\195\169lection";
CT_MMINBOX_OPENALL = "Tous les Ouvrir";
CT_MMINBOX_OPENALLTITLE = "Ouvrir les messages ?";
CT_MMINBOX_OPENALLCONFIRMATION = "Etes vous sur de vouloir ouvrir tous les messages ?";
CT_MMINBOX_DISPLAYPROCESSMESSAGES = "Afficher les processus";

end