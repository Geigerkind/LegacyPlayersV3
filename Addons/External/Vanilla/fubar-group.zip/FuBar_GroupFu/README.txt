﻿FuBar - GroupFu v1.4.7.8

Author: Brian DeGregorio (idbrain@gmail.com)
Release Date: 2006-07-16

A FuBar plugin that adds group management functions, 
loot mthod detection, and roll management.

TO INSTALL: Put the FuBar_GroupFu folder into
	\World of Warcraft\Interface\AddOns\

If you find _any_ bugs, feel free to submit them at
http://etten.wowinterface.com

If you want to request any features, feel free to submit your ideas at
http://etten.wowinterface.com

If you want to discuss GroupFu, feel free to do so at
http://www.wowinterface.com/forums/showthread.php?p=23003#post23003
