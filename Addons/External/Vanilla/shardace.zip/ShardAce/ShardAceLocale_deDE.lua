if (GetLocale() == "deDE") then

end
