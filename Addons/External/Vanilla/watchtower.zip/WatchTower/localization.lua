--------------------------------------------------
-- localization.lua (English)
--------------------------------------------------

WATCHTOWER_CONFIG_HEADER		= "WatchTower"
WATCHTOWER_CONFIG_HEADER_INFO		= "Useed for reporting of enemy position.";

WATCHTOWER_ENABLED			= "Enable WatchTower";
WATCHTOWER_ENABLED_INFO			= "Use keybindings for reporting of enemy position.";


