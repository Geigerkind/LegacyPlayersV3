CombatStats v3.75 (1300)

CombatStats is a standalone mod that is packaged with CTMod.  It was not designed by us but is fully functional with our mod.  The mod is displayed above your playerframe and when clicked, displays additional data including hits, misses, and min/max for each attack type, among other things.  Damage displayed in red is dps on you, green is your dps.

The CTMod team has modified CombatStats to include the following changes:
-Heals are now tracked, rejoice healers!
-Window is now draggable via right click.
-Stats window can be closed via escape.
-Stats are now saved between sessions, they will no longer reset when you log out