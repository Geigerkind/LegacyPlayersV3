﻿--Korean

if (GetLocale() == "koKR") then
--classes 
DISTANCE_WARRIOR = "전사";
DISTANCE_ROGUE = "도적";
DISTANCE_HUNTER = "사냥꾼";
DISTANCE_SHAMAN = "주술사";
DISTANCE_PALADIN = "성기사";
DISTANCE_DRUID = "드루이드";
DISTANCE_MAGE = "마법사";
DISTANCE_WARLOCK = "흑마법사";
DISTANCE_PRIEST = "사제";

--talents mage
DISTANCE_ARCTIC_REACH = "혹한의 손길";
DISTANCE_FLAME_THROWING = "화염 발사";
--talents shaman
DISTANCE_STORM_REACH = "폭풍의 테두리";
--talents hunter
DISTANCE_HAWK_EYE = "매의 눈";
--talents druid
DISTANCE_NATURES_REACH = "자연의 테두리";
--talents priest
DISTANCE_HOLY_REACH = "신성한 테두리";
DISTANCE_SHADOW_REACH = "어둠의 테두리";
--talents warlock
DISTANCE_DESTRUCTIVE_REACH ="파괴의 테두리";
DISTANCE_GRIM_REACH = "냉혹의 테두리";
end