--French

if (GetLocale() == "frFR") then
--classes 
DISTANCE_WARRIOR = "Guerrier";
DISTANCE_ROGUE = "Voleur";
DISTANCE_HUNTER = "Chasseur";
DISTANCE_SHAMAN = "Chaman";
DISTANCE_PALADIN = "Paladin";
DISTANCE_DRUID = "Druide";
DISTANCE_MAGE = "Mage";
DISTANCE_WARLOCK = "D\195\169moniste";
DISTANCE_PRIEST = "Pr\195\168tre";

--talents mage
DISTANCE_ARCTIC_REACH = "Allonge arctique";
DISTANCE_FLAME_THROWING = "Jet de flammes";
--talents shaman
DISTANCE_STORM_REACH = "Allonge de la temp\195\170te";
--talents hunter
DISTANCE_HAWK_EYE = "Oeil de faucon"; 
--talents druid
DISTANCE_NATURES_REACH = "Fl\195\169au de la nature";
--talents priest
DISTANCE_HOLY_REACH = "Allonge du Sacr\195\169";
DISTANCE_SHADOW_REACH = "Allonge de l'Ombre";
--talents warlock
DISTANCE_DESTRUCTIVE_REACH ="Allonge de destruction";
DISTANCE_GRIM_REACH = "Allonge sinistre";
end


--[[
à : \195\160    è : \195\168    ì : \195\172    ò : \195\178    ù : \195\185
á : \195\161    é : \195\169    í : \195\173    ó : \195\179    ú : \195\186
â : \195\162    ê : \195\170    î : \195\174    ô : \195\180    û : \195\187
ã : \195\163    ë : \195\171    ï : \195\175    õ : \195\181    ü : \195\188
ä : \195\164                   		 ñ : \195\177    ö : \195\182
æ : \195\166                                   				 ø : \195\184
 ç : \195\167
   
Ä : \195\132
Ö : \195\150
Ü : \195\156
ß : \195\159

]]