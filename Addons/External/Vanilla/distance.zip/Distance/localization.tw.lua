﻿--Traditional Chinese

if (GetLocale() == "zhTW") then

--classes 
DISTANCE_WARRIOR = "戰士";
DISTANCE_ROGUE = "盜賊";
DISTANCE_HUNTER = "獵人";
DISTANCE_SHAMAN = "薩滿";
DISTANCE_PALADIN = "聖騎士";
DISTANCE_DRUID = "德魯伊";
DISTANCE_MAGE = "法師";
DISTANCE_WARLOCK = "術士";
DISTANCE_PRIEST = "牧師";

--talents mage
DISTANCE_ARCTIC_REACH = "極寒延伸";
DISTANCE_FLAME_THROWING = "烈焰投擲";
--talents shaman
DISTANCE_STORM_REACH = "暴風降臨";
--talents hunter
DISTANCE_HAWK_EYE = "鷹眼";
--talents druid
DISTANCE_NATURES_REACH = "自然延伸";
--talents priest
DISTANCE_HOLY_REACH = "神聖延伸"; 
DISTANCE_SHADOW_REACH = "暗影延伸";
--talents warlock
DISTANCE_DESTRUCTIVE_REACH ="毀滅延伸"; 
DISTANCE_GRIM_REACH = "無情延伸";
end