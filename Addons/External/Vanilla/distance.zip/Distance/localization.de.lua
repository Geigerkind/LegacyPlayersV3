-- German

if (GetLocale() == "deDE") then
--classes
DISTANCE_WARRIOR = "Krieger";
DISTANCE_ROGUE = "Schurke";
DISTANCE_HUNTER = "J\195\164ger";
DISTANCE_SHAMAN = "Schamane";
DISTANCE_PALADIN = "Paladin";
DISTANCE_DRUID = "Druide";
DISTANCE_MAGE = "Magier";
DISTANCE_WARLOCK = "Hexenmeister";
DISTANCE_PRIEST = "Priester";

--talents mage
DISTANCE_ARCTIC_REACH = "Arktische Reichweite";
DISTANCE_FLAME_THROWING = "Flammenwerfen";
--talents shaman
DISTANCE_STORM_REACH = "Weitreichender Sturm";
--talents hunter
DISTANCE_HAWK_EYE = "Falkenauge"; 
--talents druid
DISTANCE_NATURES_REACH = "Reichweite der Natur";
--talents priest
DISTANCE_HOLY_REACH = "Heilige Reichweite";
DISTANCE_SHADOW_REACH = "Schattenreichweite";
--talents warlock
DISTANCE_DESTRUCTIVE_REACH ="Zerst\195\182rerische Reichweite";
DISTANCE_GRIM_REACH = "Grimmige Reichweite";
end



--[[
� : \195\160    � : \195\168    � : \195\172    � : \195\178    � : \195\185
� : \195\161    � : \195\169    � : \195\173    � : \195\179    � : \195\186
� : \195\162    � : \195\170    � : \195\174    � : \195\180    � : \195\187
� : \195\163    � : \195\171    � : \195\175    � : \195\181    � : \195\188
� : \195\164                   		 � : \195\177    � : \195\182
� : \195\166                                   				 � : \195\184
 � : \195\167
   
� : \195\132
� : \195\150
� : \195\156
� : \195\159

]]