 --Default

--classes
DISTANCE_WARRIOR = "Warrior";
DISTANCE_ROGUE = "Rogue";
DISTANCE_HUNTER = "Hunter";
DISTANCE_SHAMAN = "Shaman";
DISTANCE_PALADIN = "Paladin";
DISTANCE_DRUID = "Druid";
DISTANCE_MAGE = "Mage";
DISTANCE_WARLOCK = "Warlock";
DISTANCE_PRIEST = "Priest";

--talents mage
DISTANCE_ARCTIC_REACH = "Arctic Reach";
DISTANCE_FLAME_THROWING = "Flame Throwing";
--talents shaman
DISTANCE_STORM_REACH = "Storm Reach";
--talents hunter
DISTANCE_HAWK_EYE = "Hawk Eye"; 
--talents druid
DISTANCE_NATURES_REACH = "Nature's Reach";
--talents priest
DISTANCE_HOLY_REACH = "Holy Reach";
DISTANCE_SHADOW_REACH = "Shadow Reach";
--talents warlock
DISTANCE_DESTRUCTIVE_REACH ="Destructive Reach";
DISTANCE_GRIM_REACH = "Grim Reach";




--[[
� : \195\160    � : \195\168    � : \195\172    � : \195\178    � : \195\185
� : \195\161    � : \195\169    � : \195\173    � : \195\179    � : \195\186
� : \195\162    � : \195\170    � : \195\174    � : \195\180    � : \195\187
� : \195\163    � : \195\171    � : \195\175    � : \195\181    � : \195\188
� : \195\164                   		 � : \195\177    � : \195\182
� : \195\166                                   				 � : \195\184
 � : \195\167
   
� : \195\132
� : \195\150
� : \195\156
� : \195\159

]]