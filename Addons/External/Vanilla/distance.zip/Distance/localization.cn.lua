﻿--Sinplified Chinese

if (GetLocale == "zhCN") then 
--classes 
DISTANCE_WARRIOR = "战士";
DISTANCE_ROGUE = "盗贼";
DISTANCE_HUNTER = "猎人";
DISTANCE_SHAMAN = "萨满祭司";
DISTANCE_PALADIN = "圣骑士";
DISTANCE_DRUID = "德鲁伊";
DISTANCE_MAGE = "法师";
DISTANCE_WARLOCK = "术士";
DISTANCE_PRIEST = "牧师";

--talents mage
DISTANCE_ARCTIC_REACH = "极寒延伸";
DISTANCE_FLAME_THROWING = "烈焰投掷";
--talents shaman
DISTANCE_STORM_REACH = "风暴来临";
--talents hunter
DISTANCE_HAWK_EYE = "强化野兽之眼";
--talents druid
DISTANCE_NATURES_REACH = "自然延伸";
--talents priest
DISTANCE_HOLY_REACH = "神圣延伸"; 
DISTANCE_SHADOW_REACH = "暗影延伸";
--talents warlock
DISTANCE_DESTRUCTIVE_REACH ="毁灭延伸"; 
DISTANCE_GRIM_REACH = "无情延伸";
end