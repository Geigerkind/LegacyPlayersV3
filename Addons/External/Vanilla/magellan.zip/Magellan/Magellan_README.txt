====Magellan 002====
Author: Devla
qtuimod@gmail.com
http://qtui.x.am
=======================

A slight conversion of Magellan by Torgo. Modified all MapNotes code to work with MetaMap's built in version of MapNotes.

This mod will populate the the main map with notes for local landmarks, even in unexplored areas. As you mouse over them, you will see the description. If you ask a town guard for directions, those will be saved as a MapNote as well.

You MUST have either the 'MetaMap' AddOn installed for Magellan to do anything.

The landmarks are all retrieved from the server, so it is just making visible information that the client already has access to. It is most useful for low level characters with lots of unexplored areas. It should continue to work when new landmarks are added and even in new zones if/when they are released later.

Use '/magellan reset' to delete all notes created by Magellan (leaving all other MapNotes intact)

--Code is still intact for usage with CT_MapMod, but I have not tested it.

--All credit goes to the original author, Torgo.