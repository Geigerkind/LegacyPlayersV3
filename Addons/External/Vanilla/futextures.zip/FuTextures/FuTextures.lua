-- feel free to add textures, just leave your name.

FuBar:RegisterSkin("Tree", "Interface\\AddOns\\FuTextures\\tree") -- ckknight
FuBar:RegisterSkin("Ripple", "Interface\\AddOns\\FuTextures\\ripple") -- Occam
FuBar:RegisterSkin("Brushed", "Interface\\AddOns\\FuTextures\\brushed") -- Occam
FuBar:RegisterSkin("Black w/Yellow Border", "Interface\\AddOns\\FuTextures\\blackyellow") -- Stylpe
FuBar:RegisterSkin("Black w/Orange Border", "Interface\\AddOns\\FuTextures\\blackorange") -- Stylpe
FuBar:RegisterSkin("Black w/Red Border", "Interface\\AddOns\\FuTextures\\blackred") -- Stylpe
FuBar:RegisterSkin("Black w/Violet Border", "Interface\\AddOns\\FuTextures\\blackviolet") -- Stylpe
FuBar:RegisterSkin("Black w/Blue Border", "Interface\\AddOns\\FuTextures\\blackblue") -- Stylpe
FuBar:RegisterSkin("Black w/Cyan Border", "Interface\\AddOns\\FuTextures\\blackcyan") -- Stylpe
FuBar:RegisterSkin("Black w/Green Border", "Interface\\AddOns\\FuTextures\\blackgreen") -- Stylpe
FuBar:RegisterSkin("Black w/no Border","Interface\\Addons\\FuTextures\\blackblack") -- Tem
FuBar:RegisterSkin("Red sand stone","Interface\\Addons\\FuTextures\\redsandstone") -- Occam
FuBar:RegisterSkin("Sand stone","Interface\\Addons\\FuTextures\\sandstone") -- Occam
FuBar:RegisterSkin("Titan alternative","Interface\\Addons\\FuTextures\\titanalternative") -- Occam
FuBar:RegisterSkin("Patchwork","Interface\\Addons\\FuTextures\\patchwork") -- Occam
