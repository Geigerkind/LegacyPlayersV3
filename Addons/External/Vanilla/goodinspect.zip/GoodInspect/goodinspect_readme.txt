GoodInspect version 1.0.4 by usea - 2005
an inspect function improvement addon for World of Warcraft

increases inspect range
adds guild info and pvp rank to inspect window a la your character sheet
also adds a key binding for inspection
you'll find the "Inspect Target" entry in the key bindings under "Good Inspect"


-1.0.4-
fixed a few bugs, cleaned up some code

-1.0.3-
no more cross-faction inspection
added pvp rank to inspect window
made inspect key binding a toggle