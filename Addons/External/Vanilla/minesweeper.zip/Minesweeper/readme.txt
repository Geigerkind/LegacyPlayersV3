Author: Jacob Bowers (aka "Thronk" on Mal'Ganis)
Mod: Goblin Minesweeper

Version: 1.0

Purpose of mod:

Basically this mod is just the standard Minesweeper game that comes with Windows.
Sometimes when you're waiting on a flight, or a bg to pop, or whatever, it can
be fun to play a quick game.  To start the game, just type /minesweeper. 
Cntrl+clicking a square will mark it with an X, shift+clicking it  will mark it
with a ?. Doing either of these on a square that is already marked will unmark it.
I realize this game has been done before as a mod, but I just felt like doing it.
Enjoy :)