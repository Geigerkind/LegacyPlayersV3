--[[I Need These Strings Translated ]]--
SetWP_ErrorString1of2 				= "You Must Be in The Same Zone\nto Set "
SetAsWayPoint_End					= " as  Waypont"
SetasWAYPOINT1of2						= "Set "
