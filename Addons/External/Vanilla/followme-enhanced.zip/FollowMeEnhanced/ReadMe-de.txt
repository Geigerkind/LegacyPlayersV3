Die �bersetzung besteht aus der vollst�ndigen �bersetzung aller Textmeldungen und
der speziellen Folgen-Befehle:

Die folgenden Befehle werden unterst�tzt:
/fm status			- Zeigt den FollowMe-Status an
/fm aktivieren			- Aktiviert FollowMe
/fm deaktivieren		- Deaktiviert FollowMe
/fm gilde an/aus		- Schaltet, ob Gildenmitglieder dich auf Folgen setzten koennen
/fm freunde an/aus		- Schaltet, ob Freunde dich auf Folgen setzten koennen
/fm party			- Teilt der Gruppe mit, wie das
                       		  FollowMe-AddOn funktioniert
/fm raid			- Teilt dem Raid mit, wie das
                       		  FollowMe-AddOn funktioniert
/fm whisper 			- Teilt dem aktuellen Ziel per Whisper mit, wie das
				  FollowMe-AddOn funktioniert
/fm gruppenmeldung an/aus	- Schaltet automatische Gruppenmeldungen
                       		  ein/aus
/fm raidmeldung an/aus		- Schaltet automatische Raidmeldungen
                       		  ein/aus

Die Fl�stermeldung kann folgende Befehle enthalten:
   "!folgen" - Startet das Folgen auf den fl�sternden Spieler
   "!status" - antwortet dem Fl�sternden und meldet den Status (aktiviert/deaktiviert)
   				und falls man bereits jemandem folgt, den aktuell Verfolgten.
