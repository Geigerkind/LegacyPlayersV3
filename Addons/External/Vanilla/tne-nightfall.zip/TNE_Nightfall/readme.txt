Nightfall, by Silent:

Install by dropping the extracted folder in your Addons folder. Make sure you keep folder
structure, the two .tga files should be in a subfolder named 'texture'.

To enable sound, drop a mp3 sound named 'ShadowTrance.mp3' in the sounds folder.

Type /nightfall in game for configuration.

Version 1.1.2 (11000)
  - Fix: Made corrections to the German localization
     * strings should now display in a proper manner,
     * restored Shadow Trance detection.

Version 1.1.2 (11000)
  - Localization: Added German localization (thanks Citanul of Krag'jin!).

Version 1.1.1 (11000)
  - Updated TOC to 1.10.

Version 1.1 (10900)
  - Two modes for Shadow Trance
  - Sound support

Version 1.0 (10900)
  - Initial release

Contact:
- You can send questions, comments, and/or complaints to silentaddons@gmail.com
- Zaina is my forum avatar