if (GetLocale() == "zhTW") then
	-- Class Names
	WIM_LOCALIZED_DRUID = "德魯伊";
	WIM_LOCALIZED_HUNTER = "獵人";
	WIM_LOCALIZED_MAGE = "法師";
	WIM_LOCALIZED_PALADIN = "聖騎士";
	WIM_LOCALIZED_PRIEST = "牧師";
	WIM_LOCALIZED_ROGUE = "盜賊";
	WIM_LOCALIZED_SHAMAN = "薩滿";
	WIM_LOCALIZED_WARLOCK = "術士";
	WIM_LOCALIZED_WARRIOR = "戰士";

end