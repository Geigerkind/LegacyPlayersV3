---     English     ---
--- by Tekkub (duh) ---
TITAN_DURABILITY_MENU_ITEMS = "Show Item Details"
TITAN_DURABILITY_MENU_GUY = "Hide Durability Frame"
TITAN_DURABILITY_NUDE = "You're naked!";
