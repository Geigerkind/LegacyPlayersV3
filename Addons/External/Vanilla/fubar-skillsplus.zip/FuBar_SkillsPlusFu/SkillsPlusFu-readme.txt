FuBar - SkillsPlusFu v0.6.0

Author: Jayhawk
Release Date: 2006-08-19

Shows all skills in a tool tip and allows you to quickly select/reselect one of them. 

Changelog
0.6.0 - added option to keep track of the skills of your other toons.
0.5.3 - added notification option
0.5.2 - added option for displaying name before cooldown item.
0.5.1 - added key binding support, and warning timer message.
0.5.0 - complete rewrite of attempt at cooldown support, actually saved data, flexible menu label (non-released).
0.4.0 - complete rewrite of attempt at cooldown support, included timers (non-released).
0.3.0 - first attempt at cooldown support, only showed cooldown items (non-released).
0.2.1 - added fubar icon support.


Acknowledgements
This add-on is based on avngr's FuBar_ProfessionsFu, Kemayo's FuBar_KungFu, and smuggles FubarTradeCooldownFu. Thanks guys!

Install: extract the FuBar_SkillsPlusFu folder into

	\World of Warcraft\Interface\AddOns\


This add-on was downloaded from http://www.wowinterface.com/