
------------
-- FRENCH
------------

if( GetLocale() == "frFR" ) then


end