--------------------------------------------------
-- localization.lua (English)
--------------------------------------------------

ISMOUNTED_SPEED_INCREASED_BY = "Increases speed by (%d+)%%.";

