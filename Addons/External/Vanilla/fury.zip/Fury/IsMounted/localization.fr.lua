-- Version : French ( by Tinou )
-- last update : 

if ( GetLocale() == "frFR" ) then
	ISMOUNTED_SPEED_INCREASED_BY = "Augmente la vitesse de (%d+)%%.";
end