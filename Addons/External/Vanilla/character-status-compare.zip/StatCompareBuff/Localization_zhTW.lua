--[[

	File containing localized strings
	for Simplified Chinese and English versions, defaults to English

]]
function SC_BuffLocalization_zhTW()

	STATCOMPARE_BUFF_PATTERNS = {
		{ pattern = "+(%d+) 远程攻击强度。", effect = "RANGEDATTACKPOWER" },
	};

end