function CT_AllBags_Set()
	NUM_CONTAINER_FRAMES = 11;
end