-- one problem so far: theres more than 40 people on the priority list... >.<
-- for now, the addon will invite all people on this list in order from 1-40 until the 40 cap is hit. The priority list needs to be fixed so that only 40 people are on the list.
	AList = { 
	-- priests
		[1] = "Rorix";
		[2] = "Reggie";
		[3] = "Archess";
		[4] = "Dior";
		[5] = "Grundle";
		[6] = "Skie";
		[7] = "Ks";
		[8] = "Macy";
	
	-- druids
		[9] = "Tael";
		[10] = "Sillie";
		[11] = "Sleepz";
		[12] = "Gift";
		[13] = "Decadance";
		
	-- hunters
		[14] = "Baraka";
		[15] = "Malakai";
		[16] = "Ashtray";
		[17] = "Lakmire";
		[18] = "Mistrunner";
		
	-- mages
		[19] = "Asenath";
		[20] = "Honoka";
		[21] = "Infliction";
		[22] = "Magus";
		[23] = "Stratacast";
		[24] = "Eklipse";
		
	-- paladins
		[25] = "Callindra";
		[26] = "Vador";
		[27] = "Omas";
		[28] = "Malignant";
		[29] = "Necroacid";
		[30] = "Valik";
		[31] = "Marketh";
		
	-- warlocks
		[32] = "Tibby";
		[33] = "Conflagrate";
		[34] = "Archiess";
		[35] = "Frab";
		[36] = "Trwarlock";
		[37] = "Melanie";
		
	-- warriors
		[38] = "Lyon";
		[39] = "Zake";
		[40] = "Livewire";
		[41] = "Hosebeast";
		[42] = "Festivus";
		[43] = "Jeez";
		
	-- rogues
		[44] = "Haswb";
		[45] = "Hinatta";
		[46] = "Vyle";
		[47] = "Cen";
		[48] = "Delita";
		[49] = "Gnogaine";
	};
	
	BList = { 
	-- warlocks
		[1] = "Charlatan";
		[2] = "Danecook";
		
	-- rogues
		[3] = "Antisocial";
		[4] = "Honorable";
		[5] = "Chron";
		[6] = "Ras";
		[7] = "Sandyr";
		
	-- warriors
		[8] = "Relik";
		[9] = "Tank";
		[10] = "Pwnataur";
		[11] = "Gibblet";
		[12] = "Choosen";
		
	-- mages
		[13] = "Trmage";
		
	-- hunters
		[14] = "Griefer";
		[15] = "Admin";
		
	-- paladins
		[16] = "Vacho";
	};