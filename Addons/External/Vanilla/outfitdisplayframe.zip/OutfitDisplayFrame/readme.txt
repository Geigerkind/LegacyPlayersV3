OutfitDisplayFrame
------------------

This is a utility frame for handling 'outfits' -- collections of wearable
items that you can swap with what you are currently wearing.

It's in its early stages, so don't expect perfection -- but it does a pretty
good job of hanlding the basics. Plus, it handles having part of your outfits
in the bank!

This would not have been possible without the incredible example of
WeaponQuickSwap by CapnBry.

Feel free to send comments to Sutorix on the Windrunner server.