function availableonly_SetSkillFilter()
SetTrainerServiceTypeFilter("unavailable",0);
end



