ADG_TEXT_FR = 
{
    ["Argent Dawn Faction Name"] = "Aube d'argent";
    ["AD Rep"] = "AD Rep";
    ["Superior"] = "Sup\195\169rieur";
    ["Epic"] = "Epique";

    ["Minion's Scourgestone"] = "Pierre du Fl\195\169au des serviteurs";
    ["Invader's Scourgestone"] = "Pierre du Fl\195\169au des envahisseurs";
    ["Corruptor's Scourgestone"] = "Pierre du Fl\195\169au des corrupteurs";
    ["Argent Dawn Valor Token"] = "Marque de valeur de l'Aube d'argent";
    ["Core of Elements"] = "Noyau des \195\169l\195\169ments";
    ["Crypt Fiend Parts"] = "Morceaux de d\195\169mon des cryptes";
    ["Bone Fragments"] = "Fragments d'os";
    ["Dark Iron Scraps"] = "Morceaux de sombrefer";
    ["Savage Frond"] = "Palme sauvage";
    ["Insignia of the Crusade"] = "Insigne de la Croisade";
    ["Insignia of the Dawn"] = "Insigne de l'Aube";
    ["Arcane Quickener"] = "Catalyseur des arcanes";
    ["Osseous Agitator"] = "Agitateur osseux";
    ["Somatic Intensifier"] = "Intensificateur somatique";
    ["Ectoplasmic Resonator"] = "R\195\169sonateur ectoplasmique";
    ["Runecloth"] = "Etoffe runique";

    ["Felstone Field"] = "Champ de Felstone";
    ["Dalson's Tears or"] = "Larmes de Dalson";
    ["Writhing Haunt"] = "Le Repaire putride";
    ["Gahrron's Withering"] = "La Fl\195\169trissure de Gahrron";
}
