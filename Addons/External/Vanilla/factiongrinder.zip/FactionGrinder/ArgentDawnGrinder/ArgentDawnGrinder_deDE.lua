ADG_TEXT_DE = 
{
    ["Argent Dawn Faction Name"] = "Argentumd\195\164mmerung";
    ["AD Rep"] = "AD-Ruf";
    ["Superior"] = "\195\156berragend";
    ["Epic"] = "Episch";

    ["Minion's Scourgestone"] = "Gei\195\159elstein des Dieners";
    ["Invader's Scourgestone"] = "Gei\195\159elstein des Eindringlings";
    ["Corruptor's Scourgestone"] = "Gei\195\159elstein des Verderbers";
    ["Argent Dawn Valor Token"] = "Ehrenmarke der Argentumd\195\164mmerung";
    ["Core of Elements"] = "Kern der Elemente";
    ["Crypt Fiend Parts"] = "Teile einer Gruftsatanskreatur";
    ["Bone Fragments"] = "Knochenfragmente";
    ["Dark Iron Scraps"] = "Dunkeleisenfragmente";
    ["Savage Frond"] = "Wildwedel";
    ["Insignia of the Crusade"] = "Insignie des Kreuzzugs";
    ["Insignia of the Dawn"] = "Insignie der D\195\164mmerung";
    ["Arcane Quickener"] = "Arkanbeschleuniger";
    ["Osseous Agitator"] = "Kn\195\182cherner Aufstachler";
    ["Somatic Intensifier"] = "Somatischer Verst\195\164rker";
    ["Ectoplasmic Resonator"] = "Ektoplasmaresonator";
    ["Runecloth"] = "Runenstoff";

    ["Felstone Field"] = "Teufelssteinfeld";
    ["Dalson's Tears or"] = "Dalsons Tr\195\164nenfeld oder";
    ["Writhing Haunt"] = "Das trostlose Feld";
    ["Gahrron's Withering"] = "Gahrrons Trauerfeld";
}

--[[
   � : \195\160    � : \195\168    � : \195\172    � : \195\178    � : \195\185   � : \195\132
   � : \195\161    � : \195\169    � : \195\173    � : \195\179    � : \195\186   � : \195\150
   � : \195\162    � : \195\170    � : \195\174    � : \195\180    � : \195\187   � : \195\156
   � : \195\163    � : \195\171    � : \195\175    � : \195\181    � : \195\188   � : \195\159
   � : \195\164                    � : \195\177    � : \195\182
   � : \195\166                                    � : \195\184
   � : \195\167
--]]