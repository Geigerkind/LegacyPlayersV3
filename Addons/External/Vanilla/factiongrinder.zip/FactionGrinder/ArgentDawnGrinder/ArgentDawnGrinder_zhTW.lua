ADG_TEXT_ZHTW = 
{
    ["Argent Dawn Faction Name"] = "銀色黎明";
    ["AD Rep"] = "黎明聲望";
    ["Superior"] = "精良級";
    ["Epic"] = "史詩級";

    ["Minion's Scourgestone"] = "爪牙的天譴石";
    ["Invader's Scourgestone"] = "侵略者的天譴石";
    ["Corruptor's Scourgestone"] = "墮落者的天譴石";
    ["Argent Dawn Valor Token"] = "	銀色黎明勇氣勳章";
    ["Core of Elements"] = "元素之心";
    ["Crypt Fiend Parts"] = "地穴惡魔部位";
    ["Bone Fragments"] = "骨頭碎片";
    ["Dark Iron Scraps"] = "黑鐵碎片";
    ["Savage Frond"] = "野性藻葉";
    ["Insignia of the Crusade"] = "十字軍徽記";
    ["Insignia of the Dawn"] = "黎明徽記";
    ["Arcane Quickener"] = "祕法催化劑";
    ["Osseous Agitator"] = "骨質分離素";
    ["Somatic Intensifier"] = "細胞增強劑";
    ["Ectoplasmic Resonator"] = "外膜震盪體";
    ["Runecloth"] = "符文布";

    ["Felstone Field"] = "	費爾斯通農場";
    ["Dalson's Tears or"] = "達爾松之淚 / ";
    ["Writhing Haunt"] = "	嚎哭鬼屋";
    ["Gahrron's Withering"] = "蓋羅恩農場";
}
