FG_TEXT_ZHTW=
{
    ["Faction Grinder"] = "陣營聲望";
    ["Display Settings"] = "顯示設定";
    ["General Settings"] = "一般設定";
    ["Turn-ins"] = "取得";
    ["Grind Stats"] = "成果";

    ["Include Bank Bags"] = "包含銀行背包";
    ["Include Items on Alts"] = "包含其他角色的物品";
    ["Recount Items"] = "重新計算物品";

    ["Toggle Selected Trackers\tLeft-Click\nToggle Settings Screen\tRight-Click"] = "開啟/關閉追蹤器\t左鍵\n開啟/關閉設定視窗\t右鍵";
    ["FUBAR_Toggle Selected Trackers\tLeft-Click\nToggle Settings Screen\tRight-Click"] = "開啟/關閉設定的追蹤器     左鍵\n開啟/關閉設定視窗    右鍵";

    ["Argent Dawn"] = "銀色黎明";
    ["Argent Dawn Cauldrons"] = "瘟疫之鍋";
    ["Cenarion Circle"] = "塞納里奧議會";
    ["Cenarion Circle Summons"] = "召喚深淵議會";
    ["Timbermaw Hold"] = "木喉要塞";
    ["Wildhammer Clan"] = "蠻錘部族"; 
    ["Wintersaber Trainers"] = "冬刃豹訓練師"; 

    ["Not Grinding"] = "沒有耕耘";
    ["Grinding"] = "努力提昇中";
    ["Start Grinding"] = "開始計算";
    ["Stop Grinding"] = "停止計算";
    ["Today's Grinding"] = "今天努力成果";
    ["Total Grinding"] = "總計努力成果";
    ["Time"] = "時間";
    ["Rep"] = "聲望";
    ["rep"] = "聲望";
    ["Rep Value"] = "聲望值";
    ["Rep/Hour"] = "聲望/小時";
    ["Rep-up In"] = "提昇聲望";
    ["to rep-up"] = "聲望提昇";

    ["day abbreviation"] = "d";
    ["hour abbreviation"] = "h";
    ["minute abbreviation"] = "m";
    ["second abbreviation"] = "s";

    ["Human"] = "人類";
};
