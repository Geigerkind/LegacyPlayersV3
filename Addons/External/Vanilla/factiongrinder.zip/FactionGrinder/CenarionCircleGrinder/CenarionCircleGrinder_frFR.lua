CCG_TEXT_FR = --NOTHING IS TRANSLATED YET
{
    ["Cenarion Circle Faction Name"] = "Cenarion Circle";
    ["CC Rep"] = "CC Rep";

    ["Encrypted Twilight Text"] = "Encrypted Twilight Text";
    ["Abyssal Crest"] = "Abyssal Crest";
    ["Abyssal Signet"] = "Abyssal Signet";
    ["Abyssal Scepter"] = "Abyssal Scepter";
    ["Cenarion Combat Badge"] = "Cenarion Combat Badge";
    ["Cenarion Logistics Badge"] = "Cenarion Logistics Badge";
    ["Cenarion Tactical Badge"] = "Cenarion Tactical Badge";
    ["Mark of Remulos"] = "Mark of Remulos";
    ["Mark of Cenarius"] = "Mark of Cenarius";
    ["Twilight Cultist Mantle"] = "Twilight Cultist Mantle";
    ["Twilight Cultist Cowl"] = "Twilight Cultist Cowl";
    ["Twilight Cultist Robe"] = "Twilight Cultist Robe";
    ["Twilight Cultist Medallion of Station"] = "Twilight Cultist Medallion of Station";
    ["Twilight Cultist Ring of Lordship"] = "Twilight Cultist Ring of Lordship";
    ["Large Brilliant Shard"] = "Large Brilliant Shard";

    ["You Can Summon"] = "You Can Summon";
    ["Templar"] = "Templar";
    ["Dukes"] = "Dukes";
    ["Lords"] = "Lords";

    ["One Mantle, Cowl, and Robe are needed for each summon"] = "One Mantle, Cowl, and Robe are needed for each summon";
    ["One Medallion is needed for each Duke summon"] = "One Medallion is needed for each Duke summon";
    ["One Ring needed for each Lord summon"] = "One Ring needed for each Lord summon";
    ["Three Crests are needed to make a Medallion of Station"] = "Three Crests are needed to make a Medallion of Station";
    ["Three Signets are needed to make a Ring of Lordship"] = "Three Signets are needed to make a Ring of Lordship";
    ["One Shard is needed to make a Medallion of Station"] = "One Shard is needed to make a Medallion of Station";
    ["Five Shards are needed to make a Ring of Lordship"] = "Five Shards are needed to make a Ring of Lordship";

    ["One of each badge"] = "One of each badge";
    ["badge sets"] = "badge sets";
    ["badge sets to rep-up"] = "badge sets to rep-up";

    ["Volunteer"] = "Volunteer";
    ["Veteran"] = "Veteran";
    ["Stalwart"] = "Stalwart";
    ["Champion"] = "Champion";

    ["One needed for Stalwart's Battlegear turnin"] = "One needed for Stalwart's Battlegear turnin";
    ["One needed for Champion's Battlegear turnin"] = "One needed for Champion's Battlegear turnin";
}
