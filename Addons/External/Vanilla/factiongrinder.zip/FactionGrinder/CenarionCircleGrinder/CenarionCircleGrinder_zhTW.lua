CCG_TEXT_ZHTW =  
{
    ["Cenarion Circle Faction Name"] = "塞納里奧議會";
    ["CC Rep"] = "塞納里奧";

    ["Encrypted Twilight Text"] = "暮光加密文件";
    ["Abyssal Crest"] = "深淵紋章";
    ["Abyssal Signet"] = "深淵徽記";
    ["Abyssal Scepter"] = "深淵節杖";
    ["Cenarion Combat Badge"] = "塞納里奧作戰徽章";
    ["Cenarion Logistics Badge"] = "塞納里奧後勤徽章";
    ["Cenarion Tactical Badge"] = "塞納里奧戰術徽章";
    ["Mark of Remulos"] = "雷姆洛斯印記";
    ["Mark of Cenarius"] = "塞納留斯印記";
    ["Twilight Cultist Mantle"] = "暮光信徒披肩";
    ["Twilight Cultist Cowl"] = "暮光信徒兜帽";
    ["Twilight Cultist Robe"] = "暮光信徒長袍";
    ["Twilight Cultist Medallion of Station"] = "暮光信徒身份勳章";
    ["Twilight Cultist Ring of Lordship"] = "暮光貴族之戒";
    ["Large Brilliant Shard"] = "大塊魔光碎片";

    ["You Can Summon"] = "你可召喚";
    ["Templar"] = "聖殿騎士";
    ["Dukes"] = "公爵";
    ["Lords"] = "領主";

    ["One Mantle, Cowl, and Robe are needed for each summon"] = "召喚聖殿騎士需要（披肩、兜帽、長袍）各一個";
    ["One Medallion is needed for each Duke summon"] = "召喚公爵需要身份勳章";
    ["One Ring needed for each Lord summon"] = "召喚領主需要貴族之戒";
    ["Three Crests are needed to make a Medallion of Station"] = "三個深淵紋章可換取一個暮光信徒身份勳章";
    ["Three Signets are needed to make a Ring of Lordship"] = "三個深淵徽記可換取一個貴族之戒";
    ["One Shard is needed to make a Medallion of Station"] = "一個大塊魔光碎片可換取一個暮光信徒身份勳章";
    ["Five Shards are needed to make a Ring of Lordship"] = "五個大塊魔光碎片可換取一個暮光貴族之戒";

    ["One of each badge"] = "每一個徽章";
    ["badge sets"] = "個徽章";
    ["badge sets to rep-up"] = "個徽章聲望提昇";

    ["Volunteer"] = "志願兵";
    ["Veteran"] = "精兵";
    ["Stalwart"] = "忠誠者";
    ["Champion"] = "勇士";

    ["One needed for Stalwart's Battlegear turnin"] = "換取忠誠者的裝備需要一個";
    ["One needed for Champion's Battlegear turnin"] = "換取勇士的裝備需要一個";
}
