WTG_TEXT_ZHTW = 
{
    ["Wintersaber Trainers Faction Name"] = "冬刃豹訓練師";
    ["WT Rep"] = "冬刃豹"; 

    ["Frostsaber Provisions"] = "任務：霜刃豹的糧食"; 
    ["Chillwind Meat"] = "冰風奇美拉肉"; 
    ["Shardtooth Meat"] = "碎齒熊肉"; 

    ["Winterfall Intrusion"] = "任務：冬泉熊怪的侵擾"; 
    ["Winterfall Shaman slain"] = "殺死冬泉薩滿"; 
    ["Winterfall Ursa slain"] = "殺死冬泉巨熊怪"; 

    ["Rampaging Giants"] = "任務：狂暴的巨人"; 
    ["Frostmaul Giant slain"] = "殺死霜槌巨人"; 
    ["Frostmaul Preserver slain"] = "殺死霜槌保衛者"; 

    ["Quests to Rep-up"] = "聲望提昇任務次數"; 
    ["Quests to Exalted"] = "到崇拜的任務次數"; 
}
