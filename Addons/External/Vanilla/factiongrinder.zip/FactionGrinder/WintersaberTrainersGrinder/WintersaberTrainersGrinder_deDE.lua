WTG_TEXT_DE = 
{
    ["Wintersaber Trainers Faction Name"] = "Frosts\195\164bleausbiler";
    ["WT Rep"] = "WA-Ruf";

    ["Frostsaber Provisions"] = "Frosts\195\164blerverpflegung";
    ["Chillwind Meat"] = "Fleisch einer Eiswindschim\195\164re";
    ["Shardtooth Meat"] = "Splitterzahnfleisch";

    ["Winterfall Intrusion"] = "Eindringlinge der Winterfelle";
    ["Winterfall Shaman slain"] = "Shamane der Winterfelle get\195\182tet";
    ["Winterfall Ursa slain"] = "Ursa der Winterfelle get\195\182tet";

    ["Rampaging Giants"] = "Tobende Riesen";
    ["Frostmaul Giant slain"] = "Frosthagelriese get\195\182tet";
    ["Frostmaul Preserver slain"] = "Frosthagelbewahrer get\195\182tet";

    ["Quests to Rep-up"] = "Quests bis Rufaufstieg";
    ["Quests to Exalted"] = "Quests bis Ehrf\195\188rchtig";
}
--[[
   � : \195\160    � : \195\168    � : \195\172    � : \195\178    � : \195\185   � : \195\132
   � : \195\161    � : \195\169    � : \195\173    � : \195\179    � : \195\186   � : \195\150
   � : \195\162    � : \195\170    � : \195\174    � : \195\180    � : \195\187   � : \195\156
   � : \195\163    � : \195\171    � : \195\175    � : \195\181    � : \195\188   � : \195\159
   � : \195\164                    � : \195\177    � : \195\182
   � : \195\166                                    � : \195\184
   � : \195\167
--]]
