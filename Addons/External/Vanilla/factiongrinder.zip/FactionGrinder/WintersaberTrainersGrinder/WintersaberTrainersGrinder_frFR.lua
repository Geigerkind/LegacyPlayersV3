WTG_TEXT_FR = 
{
    ["Wintersaber Trainers Faction Name"] = "Wintersaber Trainers"; --NOT TRANSLATED
    ["WT Rep"] = "WT Rep"; --NOT TRANSLATED

    ["Frostsaber Provisions"] = "Frostsaber Provisions"; --NOT TRANSLATED
    ["Chillwind Meat"] = "Chillwind Meat"; --NOT TRANSLATED
    ["Shardtooth Meat"] = "Shardtooth Meat"; --NOT TRANSLATED

    ["Winterfall Intrusion"] = "Winterfall Intrusion"; --NOT TRANSLATED
    ["Winterfall Shaman slain"] = "Winterfall Shaman slain"; --NOT TRANSLATED
    ["Winterfall Ursa slain"] = "Winterfall Ursa slain"; --NOT TRANSLATED

    ["Rampaging Giants"] = "Rampaging Giants"; --NOT TRANSLATED
    ["Frostmaul Giant slain"] = "Frostmaul Giant slain"; --NOT TRANSLATED
    ["Frostmaul Preserver slain"] = "Frostmaul Preserver slain"; --NOT TRANSLATED

    ["Quests to Rep-up"] = "Quests to Rep-up"; --NOT TRANSLATED
    ["Quests to Exalted"] = "Quests to Exalted"; --NOT TRANSLATED
}
