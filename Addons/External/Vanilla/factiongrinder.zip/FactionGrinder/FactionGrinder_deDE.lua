FG_TEXT_DE = 
{
    ["Faction Grinder"] = "Faction Grinder";
    ["Display Settings"] = "Anzeigeeinstellungen";
    ["General Settings"] = "Allgemeine Einstellungen";
    ["Turn-ins"] = "Abgaben";
    ["Grind Stats"] = "Grind-\nStatistiken";

    ["Include Bank Bags"] = "Bankinhalt einschlie\195\159en";
    ["Include Items on Alts"] = "Gegenst\195\164nde von Twinks einbeziehen";
    ["Recount Items"] = "Gegenst\195\164nde nachz\195\164hlen";

    ["Toggle Selected Trackers\tLeft-Click\nToggle Settings Screen\tRight-Click"] = "Tracker anzeigen\tLinksklick\nEinstellungen anzeigen\tRechtsklick";
    ["FUBAR_Toggle Selected Trackers\tLeft-Click\nToggle Settings Screen\tRight-Click"] = "Tracker anzeigen    Linksklick\nEinstellungen anzeigen    Rechtsklick";

    ["Argent Dawn"] = "Argentumd\195\164mmerung";
    ["Argent Dawn Cauldrons"] = "Pestlandkessel";
    ["Cenarion Circle"] = "Zirkel des Cenarius";
    ["Cenarion Circle Summons"] = "Silithus-Beschw\195\182rungen";
    ["Timbermaw Hold"] = "Holzschlundfeste";
    ["Wildhammer Clan"] = "Wildhammerklan";
    ["Wintersaber Trainers"] = "Frosts\195\164bleausbiler";

    ["Not Grinding"] = "Nicht am Grinden";
    ["Grinding"] = "Am Grinden";
    ["Start Grinding"] = "Starte Grinden";
    ["Stop Grinding"] = "Stoppe Grinden";
    ["Today's Grinding"] = "Heutige Grinding";
    ["Total Grinding"] = "Totale Grinding";
    ["Time"] = "Zeit";
    ["Rep"] = "Ruf";
    ["rep"] = "Ruf";
    ["Rep Value"] = "Rufwert";
    ["Rep/Hour"] = "Ruf/Std";
    ["Rep-up In"] = "Rufaufstieg in";
    ["to rep-up"] = "bis Rufaufstieg";

    ["day abbreviation"] = "T";
    ["hour abbreviation"] = "S";
    ["minute abbreviation"] = "M";
    ["second abbreviation"] = "s";

    ["Human"] = "Mensch";
}

--[[
   � : \195\160    � : \195\168    � : \195\172    � : \195\178    � : \195\185   � : \195\132
   � : \195\161    � : \195\169    � : \195\173    � : \195\179    � : \195\186   � : \195\150
   � : \195\162    � : \195\170    � : \195\174    � : \195\180    � : \195\187   � : \195\156
   � : \195\163    � : \195\171    � : \195\175    � : \195\181    � : \195\188   � : \195\159
   � : \195\164                    � : \195\177    � : \195\182
   � : \195\166                                    � : \195\184
   � : \195\167
--]]
