FG_TEXT_FR = 
{
    ["Faction Grinder"] = "Faction Grinder";  --NOT TRANSLATED
    ["Display Settings"] = "Display Settings";  --NOT TRANSLATED
    ["General Settings"] = "General Settings";  --NOT TRANSLATED
    ["Turn-ins"] = "Turn-ins";  --NOT TRANSLATED
    ["Grind Stats"] = "Grind Stats";  --NOT TRANSLATED
   
    ["Include Bank Bags"] = "Inclure la Banque";
    ["Include Items on Alts"] = "Inclure les rerolls";
    ["Recount Items"] = "Recompter";

    ["Toggle Selected Trackers\tLeft-Click\nToggle Settings Screen\tRight-Click"] = "Trackers\tClic-Gauche\nFen\195\170tre d'options\tClic-Droit";
    ["FUBAR_Toggle Selected Trackers\tLeft-Click\nToggle Settings Screen\tRight-Click"] = "Trackers     Clic Gauche\nFen\195\170tre d'options    Clic Droit";

    ["Argent Dawn"] = "Aube d'argent";
    ["Argent Dawn Cauldrons"] = "Argent Dawn Cauldrons";  --NOT TRANSLATED
    ["Cenarion Circle"] = "Cenarion Circle";  --NOT TRANSLATED
    ["Cenarion Circle Summons"] = "Cenarion Circle Summons";  --NOT TRANSLATED
    ["Timbermaw Hold"] = "Timbermaw Hold";  --NOT TRANSLATED
    ["Wildhammer Clan"] = "Wildhammer Clan"; --NOT TRANSLATED
    ["Wintersaber Trainers"] = "Wintersaber Trainers"; --NOT TRANSLATED

    ["Not Grinding"] = "En pause";
    ["Grinding"] = "En grind";
    ["Start Grinding"] = "Commencer le grind";
    ["Stop Grinding"] = "Arreter le grind";
    ["Today's Grinding"] = "Grind du jour";
    ["Total Grinding"] = "Grind total";
    ["Time"] = "Temps";
    ["Rep"] = "Rep";
    ["rep"] = "rep";
    ["Rep Value"] = "R\195\169putation";
    ["Rep/Hour"] = "Rep/Heure";
    ["Rep-up In"] = "Rep-up In";
    ["to rep-up"] = "to rep-up";

    ["day abbreviation"] = "d";
    ["hour abbreviation"] = "h";
    ["minute abbreviation"] = "m";
    ["second abbreviation"] = "s";

    ["Human"] = "Humain";
}
