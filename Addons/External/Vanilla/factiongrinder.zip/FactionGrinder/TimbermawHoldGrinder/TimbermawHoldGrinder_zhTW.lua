THG_TEXT_ZHTW = 
{
    ["Timbermaw Hold Faction Name"] = "木喉要塞";
    ["TH Rep"] = "木喉要塞";

    ["Deadwood Headdress Feather"] = "死木頭飾羽毛";
    ["Winterfall Spirit Beads"] = "冬泉靈魂珠串";
}
