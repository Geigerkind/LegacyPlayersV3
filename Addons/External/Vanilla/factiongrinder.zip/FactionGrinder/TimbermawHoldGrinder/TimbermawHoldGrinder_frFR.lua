THG_TEXT_FR = 
{
    ["Timbermaw Hold Faction Name"] = "Timbermaw Hold";  --NOT TRANSLATED
    ["TH Rep"] = "TH Rep";  --NOT TRANSLATED

    ["Deadwood Headdress Feather"] = "Deadwood Headdress Feather";  --NOT TRANSLATED
    ["Winterfall Spirit Beads"] = "Winterfall Spirit Beads";  --NOT TRANSLATED
}
