--German
if (GetLocale()=="deDE") then

SAO_STR_NAN = "KEINE NUMMER!";
SAO_STR_MIN = "Min: ";
SAO_STR_MAX = ", Max: ";

--General options frame
--Alert Types names
SAO_STR_DAMAGE = "Schaden";
SAO_STR_HEAL = "Heilung";
SAO_STR_BUFFGAIN = "Buff\nbekommen";
SAO_STR_BUFFGONE = "Buff\nschwindet";
SAO_STR_TOTEM = "Totem";
SAO_STR_EMOTE = "Emote";
SAO_STR_PERIODIC = "Periodisch";
SAO_STR_INSTANT = "Spontan";
SAO_STR_CC = "CC";
SAO_STR_MISC = "Sonstige";

SAO_STR_GENERAL = "Allgemein";
SAO_STR_ON = "An";
SAO_STR_OFFONREST = "Aus bei Ruhestand";
SAO_STR_TO = "BIS";
SAO_STR_SHORT = "Kurz";

SAO_STR_ON_TT = "Schalte SA An/Aus";
SAO_STR_OFFONREST_TT = "Schalte SA aus w\195\164hrend des Ruhestandes (Gasth\195\164user und Hauptst\195\164dte)";
SAO_STR_TO_TT = "Zeige diese Alarmart nur f\195\188r das momentane Ziel";
SAO_STR_SHORT_TT = "Zeige diesen Alarm in kurzer Form, z.B. \"245 Gesundheit (Bob)\" statt \"Bob bekommt 245 Gesundheit von Alice's Erneuerung.\"";

--AlertX frames
SAO_STR_ALERT1 = "Alarm1";
SAO_STR_ALERT2 = "Alarm2";
SAO_STR_ALERT3 = "Alarm3";
SAO_STR_LOCK = "Fixieren";
SAO_STR_UNLOCK = "Freigeben";
SAO_STR_SIZE = "Schriftgr\195\182\195\159e";
SAO_STR_HT = "Zeit bevor Fade";
SAO_STR_FT = "Dauer des Fadings";
SAO_STR_LINES = "Zeilenzahl";
SAO_STR_ALPHA = "Transparenz";
SAO_STR_OUTLINE = "Schriftkontur";
SAO_STR_SPACE = "Linienabstand";
SAO_STR_GOTO = "Pr\195\188fe die Alarmarten,\ndie Du an diesen AlarmFrame binden m\195\182chtest";

end