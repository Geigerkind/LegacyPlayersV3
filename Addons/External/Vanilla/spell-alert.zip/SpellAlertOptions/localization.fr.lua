--French
if (GetLocale()=="frFR") then

SAO_STR_NAN = "NOT A NUMBER!";
SAO_STR_MIN = "Min: ";
SAO_STR_MAX = ", Max: ";

	--General options frame
	--Alert Types names
	SAO_STR_DAMAGE = "D\195\169g\195\162ts";
	SAO_STR_HEAL = "Soins";
	SAO_STR_BUFFGAIN = "Gain de buff";
	SAO_STR_BUFFGONE = "Fion de buff";
	SAO_STR_TOTEM = "Totem";
	SAO_STR_EMOTE = "Emote";
	SAO_STR_PERIODIC = "Periodique";
	SAO_STR_INSTANT = "Instantan\195\169";
	SAO_STR_CC = "CC";
	SAO_STR_MISC = "Divers";

	SAO_STR_GENERAL = "G\195\169n\195\169ral";
	SAO_STR_ON = "On";
	SAO_STR_OFFONREST = "OffOnRest";
	SAO_STR_TO = "TO";
	SAO_STR_SHORT = "Court";

	SAO_STR_ON_TT = "Activer/D\195\169sactiver SA";
	SAO_STR_OFFONREST_TT = "D\195\169sactive SA en repos (auberges et capitales)";
	SAO_STR_TO_TT = "Affiche ce type d'alerte seulement pour la cible actuelle";
	SAO_STR_SHORT_TT = "Affiche cette alerte en forme courte, ex. \"245 Soins (Bob)\" au lieu de \"R\195\169novation d'Alice soigne Bob de 245 points de vie.\"";

	--AlertX frames
	SAO_STR_ALERT1 = "Alert1";
	SAO_STR_ALERT2 = "Alert2";
	SAO_STR_ALERT3 = "Alert3";
	SAO_STR_LOCK = "Bloquer";
	SAO_STR_UNLOCK = "D\195\169bloquer";
	SAO_STR_SIZE = "Taille de police";
	SAO_STR_HT = "Temps avant disparition";
	SAO_STR_FT = "Temps de disparition";
	SAO_STR_LINES = "Nombre de lignes";
	SAO_STR_ALPHA = "Transparence";
	SAO_STR_OUTLINE = "Font Outline";
	SAO_STR_SPACE = "Espace de ligne";
	SAO_STR_GOTO = "Cochez le type d'alertes que vous souhaites associer 195\160 cette AlertFrame";

end