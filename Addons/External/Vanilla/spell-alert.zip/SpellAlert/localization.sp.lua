-- Spanish
if (GetLocale()=="spSP") then

end