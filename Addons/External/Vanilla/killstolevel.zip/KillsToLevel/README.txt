KillsToLevel - Titan - FuBar v0.53

Author: Willisterman (willisterman@hotmail.com)
Release Date: 17/05/05


Small mod which uses the xp to calculate the number of times
you would have to kill that creature to level.  Also can do
the same for quests.  Works with Titan Bar, and FuBar.

TO INSTALL: Put the KillsToLevel folder into
	\World of Warcraft\Interface\AddOns\

If you find _any_ bugs, feel free to submit them at
http://ui.worldofwar.net/ui.php?id=746

If you want to request any features, feel free to submit your ideas at
http://ui.worldofwar.net/ui.php?id=746
