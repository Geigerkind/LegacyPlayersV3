-- Version : French ( by Sasmira )
-- Last Update : 03/31/2005

if ( GetLocale() == "frFR" ) then

CT_MAPMOD_SETS = { };

CT_MAPMOD_TEXT_NAME = "Nom:";
CT_MAPMOD_TEXT_DESC = "Description:";
CT_MAPMOD_TEXT_GROUP = "Groupe:";
CT_MAPMOD_TEXT_SEND = "Envoi au Joueur:";
CT_MAPMOD_TEXT_TITLE = "Editeur de Note";

CT_MAPMOD_BUTTON_OKAY = "Ok";
CT_MAPMOD_BUTTON_CANCEL = "Annuler";
CT_MAPMOD_BUTTON_DELETE = "Supprimer";
CT_MAPMOD_BUTTON_EDITGROUPS = "Editeur de Groupe";
CT_MAPMOD_BUTTON_SEND = "Envoyer";

CT_MAPMOD_SETS[1] = "G\195\169n\195\169ral";
CT_MAPMOD_SETS[2] = "PNJs";
CT_MAPMOD_SETS[3] = "Montres";
CT_MAPMOD_SETS[4] = "Locations";
CT_MAPMOD_SETS[5] = "Objets";
CT_MAPMOD_SETS[6] = "Divers";

end