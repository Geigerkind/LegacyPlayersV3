if ( GetLocale() == "deDE" ) then
	-- Credits to Hj�rvar�r for these

	CT_MAPMOD_TEXT_NAME = "Name:";
	CT_MAPMOD_TEXT_DESC = "Beschreibung:";
	CT_MAPMOD_TEXT_GROUP = "Gruppe:";
	CT_MAPMOD_TEXT_SEND = "An Spieler senden:";
	CT_MAPMOD_TEXT_TITLE = "Notiz bearbeiten";

	CT_MAPMOD_BUTTON_OKAY = "Ok";
	CT_MAPMOD_BUTTON_CANCEL = "Abbrechen";
	CT_MAPMOD_BUTTON_DELETE = "L\195\182schen";
	CT_MAPMOD_BUTTON_EDITGROUPS = "Gruppen bearbeiten";
	CT_MAPMOD_BUTTON_SEND = "Senden";

	CT_MAPMOD_SETS[1] = "Allgemeines";
	CT_MAPMOD_SETS[2] = "NSC";
	CT_MAPMOD_SETS[3] = "Monster";
	CT_MAPMOD_SETS[4] = "Orte";
	CT_MAPMOD_SETS[5] = "Gegenst\195\164nde";
	CT_MAPMOD_SETS[6] = "Verschiedenes";

end