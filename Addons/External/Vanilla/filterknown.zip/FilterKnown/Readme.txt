FilterKnown - By Robert Jenkins (Merrem@Perenolde) - robj@suvangi.com

Colors "Already known" auction items, so you can tell which you know/don't know at a glance.

fixed for 1.9 by jimig all credit goes to Robert Jenkins for creating this mod

CHANGE HISTORY:

1.06:
	Fixed xml file

1.05
	Fixed it to work with 1.10 and changed the .toc


1.04:
	added ## Dependencies: Blizzard_AuctionUI to the FilterKnown.toc to fix 


1.03:

	Improved tooltip check. (Checks lines 2-4 now, instead of just line 3.)

1.02:

	Changed .toc to 1300

1.01:

	Added myAddOns support
	Used ITEM_SPELL_KNOWN global instead of "Already known" as the check.

1.00:

	Initial Release

