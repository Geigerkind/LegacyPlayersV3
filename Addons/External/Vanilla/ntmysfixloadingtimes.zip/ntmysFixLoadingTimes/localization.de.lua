-- german (letzte �nderung 13/apr/06)
-- Umlaute: \195\164 = �, \195\188 = �, \195\182 = �

if ( GetLocale() == "deDE" ) then

NFLT_TITLEUSAGE	= " geladen (benutze /nFLT f\195\188r Optionen)";

NFLT_SETTING = {};
NFLT_SETTING[1]	= "ntmysFLT aus";
NFLT_SETTING[2]	= "ntmysFLT an (mit Nachrichten)";
NFLT_SETTING[3]	= "ntmysFLT an (ohne Nachrichten)";
NFLT_SETTING[4]	= "ntmysFLT aus (mit Nachrichten)";

NFLT_ZONECHANGE	= "Zonewechsel dauerte ";
NFLT_PROCEVENTS = "Events bearbeitet: ";

end