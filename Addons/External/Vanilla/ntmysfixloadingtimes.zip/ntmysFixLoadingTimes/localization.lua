-- english (last change 13/apr/06)

NFLT_TITLEUSAGE	= " loaded (use /nFLT for options)";

NFLT_SETTING = {};
NFLT_SETTING[1]	= "ntmysFLT off";
NFLT_SETTING[2]	= "ntmysFLT on (with messages)";
NFLT_SETTING[3]	= "ntmysFLT on (without messages)";
NFLT_SETTING[4]	= "ntmysFLT off (with messages)";

NFLT_ZONECHANGE	= "Zonechange took ";
NFLT_PROCEVENTS = "Events processed: ";