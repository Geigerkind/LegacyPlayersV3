EnemyBuffTimersVanilla
======================
WoW 1.12.1 debuff timers on the default target frame
Behaves as it would in WoW 2.4.3 or 3.3.5
