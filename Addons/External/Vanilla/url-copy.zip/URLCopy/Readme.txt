URL Copy v1.2.10900 by Leuchtturm on Azshara EU


This addon makes URL's clickable links. When you click on them, a dialog with an
editbox will appear where you can copy the URL (ctrl+c).

Supported URL's:

*://* (http:// etc)
www.*.* (www.test.com/etc)
*.*.*.* and :* (127.0.0.1:21, numbers only)
*.*.* and : (test.test.com and test.test.com:8767 string can be variable. This one is for subdomains)
*@*.* (test@test.com, test@test.test.com)


Commands:
/ucc RRGGBB - change color on links (default is yellow)
/ucb on/off - set brackets on or off
