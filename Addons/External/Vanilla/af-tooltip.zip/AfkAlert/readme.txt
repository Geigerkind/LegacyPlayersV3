1) Create directory /Interface/Addons your World of Warcraft folder (if you don't already have it).
2) Extract the .zip into World of Warcraft/Interface/Addons.
3) Restart World of Warcraft.