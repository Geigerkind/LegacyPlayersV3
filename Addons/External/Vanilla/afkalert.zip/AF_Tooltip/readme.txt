-------------------------------------------------
Color Charts
-------------------------------------------------
AF_ToolTip v5.0 introduced color charts, a fun and easy way to get the look you desire at no memory cost to the game.

I have included with this mod default color charts to give you a starting space, located in the "My Color Charts" folder.
Have fun, be creative, share, and most of all tell your friends about it!

-------------------------------------------------
LOADING A COLOR CHART
-------------------------------------------------
In order to load a color chart, just copy it from the "My Color Charts" folder into af_tooltip's root directory.