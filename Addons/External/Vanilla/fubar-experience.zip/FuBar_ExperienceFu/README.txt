FuBar - ExperienceFu v1.1 $Revision: 1238 $

Author: ckknight (ckknight@gmail.com)
$Date: 2006-04-30 13:04:20 -1000 (Sun, 30 Apr 2006) $

Keeps track of experience.

TO INSTALL: Put the FuBar_ExperienceFu folder into
	\World of Warcraft\Interface\AddOns\

If you find _any_ bugs, feel free to submit them at
http://ckknight.wowinterface.com/portal.php?id=54&a=listbugs

If you want to request any features, feel free to submit your ideas at
http://ckknight.wowinterface.com/portal.php?id=54&a=listfeatures
