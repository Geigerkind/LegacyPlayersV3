This mod is mostly for lazy people:


PASSIVE ENHANCEMENTS:
CHARACTER AUTO SAVE 	          	- save character's data after receiving rare/epic/legendary item, finishing bg 
AUTO DISMOUNT 				- when casting spell or interacting with flightmaster(aq40 mounts included)
AUTO ZG ROLL 				- on bijou, coins(avaliable 4 modes: off, pass, greed, need)
LOOT WINDOW AUTO POSITION		- under the cursor when looting
GOSSIP AUTO PROCESSING			- when talking to NPC(taxi, battlemaster, innkeeper, vendors)
WORLD CHAT MUTE				- mute /world channel in raid/dungeon/bg zone also filter repeated messages(30s default ban time)
IMPROVED RIGHT CLICK			- if trade/auction/mail window is active, right click on container item will drag and drop it into trade/auction_create/send_mail window


ACTIVE ENHANCEMENTS(require shift modifier key press):
SHIFT SPLIT/MERGE			- shift + right will split stacked items
AUTO GREY SELL/REPAIR			- press shift when merchant frame is open
REPEATABLE QUESTS AUTOCOMPLETE 		- token quests like: AD(scourge stones,insignias), ZG(coins), BG(marks), Thorium Shells (v1.7changelog)

MINOR ENHANCEMENTS:
GROUP AUTO ACCEPT 			- 3 modes (GUILDMATES, GUILDMATES>FRIENDS, EVERYONE)
SUMMON AUTO ACCEPT 	  		- accept 2 seconds before confirm time expire
INSTANCE RESURECTION ACCEPT OOC		- instant accept OOC(ouf of combat)
EXTENDED CAMERA DISTANCE		- increase max camera distance up to 50y


SPECIAL KEY COMBINATIONS
alt+ctrl+shift				- logout

ctrl+shift				- follow

alt+shift 				- inspect, click button: bid_auction

alt+ctrl				- initiate/accept trade with other player, 
					  confirm popups: group_invite/bg_entry/release_spirit/recover_corpse/summon etc etc,
					  click button: send_mail/create_auction/buyout_auction/accept quest etc etc,
					  roll: on greenies other clolors are ignored, 3 modes (NEED,GREEN,PASS)





typing /lp    - customize addon functionality(most of the functions can be toggled)

Some of the addon's functions may not work if you're using not en/us localized client also bongos and oskin may cause some small issues. 


Addons with similar functionality you don't need anymore
- Auto Profit
- Ez Dismount
- Automaton
- Quick Loot
- Block Salation
- MailTo -> If you gonna use it anyways be sure to disable _LazyPig features(Improved Right Click and Shift Split/Merge) to avoid override.

New in v1.7 
Added new feature record/replay for repeatable quests that allows you to complete them extremely fast.
To record just hold down the Shift key and complete the repeatable quest, after that talk to the NPC again and all
the previous actions will be auto replayed, remember not to release the Shift key.
New in v1.8
Added split feature
- shift + right click will split stack
New in v1.9
Added auto roll option for zg rep items: bijous, coins 
New in 2.3
- added easy to use grey sell feature, just press shift key when merchant frame is open
- thorium shells exchange quest now can be automated(v1.7 changelog)
- added auto queue bg feature
New in 2.5
- resolved problem with dismounting when more than 16 buffs is active(tooltip instead of texture scanning)
- fixed all issues with the auto completing of repeatable quests (bg marks)
- fixed bg auto leave feature (did not trigger sometimes)
New in 2.7
- added new key combinations
- improved right click on container items
- added auto repair function(performed when merchant frame is visible and Shift key pressed)
- improved quest/gossip auto processing
New in 2.8
- improved Shift Split(see v1.8 changelog)
New in 2.83
- removed /lps command replaced by easy to use intuitive split mechanism(to enable split feature you need to type /lp 6 - if disabled)
New in 2.88
- added Alt+Ctrl green roll key combinations
New in 3.0
- added "Mute World" chat functionality, available 3 modes (RAID>DUNGEON>BG, RAID>DUNGEON, RAID) after leaving specified zone /world chat will be unmuted, function disabled as default type /lp for details
New in 3.50
- greatly improved split mechanism, check video
New in 4.00
- added GUI to acces type /lp
New in 4.40
- added keybindings
- added spam filter
- added salvation remover for tanks
- fixed many small bugs
New in 4.50
- couple fixes
- added drop WSG Flag bindig
cheers Ogrisch.
New in 4.52
- added find wsg efc binding
- improved REPEATABLE QUESTS AUTOCOMPLETE for wsg and arathi(if you're lvl 60 you will always complete lvl 60 version no matter which one you choose)
Some of the addon's functions may not work if you're using not en/us localized client also bongos and oskin may cause some small issues. 
New in 4.56
- some minor fixes
- resurrection auto accept now available only in instances
New in 5.00
- Block Battleground Quest Share feature(no more Empty Stables)
- Brand New GUI made by mrmr thx bro
