Serenity
-------------------------------

- Based on Necrosis LdC by Lomig and Nyx (http://necrosis.larmes-cenarius.net)
- Original Necrosis Idea : Infernal (http://www.revolvus.com/games/interface/necrosis/)
- Cryolysis Maintainer : Kaeldra of Aegwynn

- Contact : darklyte@gmail.com
- Send me in-game mail!  Nethaera on Aegwynn, Horde side.
- Guild: <Working as Intended>
- Updated 08/24/2006

-------------------------------
0 - Installation
-------------------------------

Extract the entire folder to your Wow\Interface\addons directory.  If you are installing a beta or patch,
please do not delete the directory before hand.  Patch and Beta files only contain the necessary changes.

-------------------------------
1 - What is Serenity?
-------------------------------

se�ren�i�ty (se-ren'i-te) n.
The state or quality of being...
1. Unaffected by disturbance; calm and unruffled. 
2. Unclouded; fair: "serene skies and a bright blue sea."



Serenity is a mod to help your priest managing their buffs, and spells, reagents, cooldowns and durations.  
It provides a variety of buttons for common spells in an easy-to-use, small, convinient package.  
The idea and code was adapted from Necrosis LdC to make it usable by priests.

-------------------------------
1b- What isn't Serenity?
-------------------------------

Serenity will not give provide you with buttons for offensive spells. It will not take up a lot of 
screen space.  It will not make coffee or walk your dog.

-------------------------------
2 - Why should I use Serenity?
-------------------------------

Because it is wonderful and very intuitive! The interface is small and movable, opening up a lot more screen and bar 
space for whatever you want.  You won't need to clutter your screen with uncommon spells and you will
never have to search through your spellbook or inventory for priestly things. You feel be a more efficient priest 
and have more fun thanks to this handy addon.

-------------------------------
3 - How does it work?
-------------------------------

Really simple, but very complex! My grandmother can do it.  Oh, well, you can bet my grandmother never intended 
to play online games. She thought that computers were devil machines which can provide illness and death. I think 
it is ashame to be so narrowminded. Well, anyway...

How does it work ? Well...


Serenity will provide you a sphere and 9 buttons. The sphere will display relevant information and the outer 
buttons will provide quick access to all your priestly desires.

More details?!  Okay, here we go!

[b]Main Sphere[/b]
[li]Right click to open the configuration menu. 
[li]Left-click to activate one of the various options. 
[li]=> Drink your best available water
[li]=> Use Mana Potion
[li]=> Use Healing Potion
[li]=> Cast Fade
[li]=> Cast Pyschic Scream
[li]=> Want something else?  Let me know!

[b]Main Sphere Display[/b] - You can set the main sphere to show any of these options
[li]Nothing!
[li]Available Drinks
[li]Mana and Healing Potion Quantities
[li]Current Health (Numeric)
[li]Current Health (Percent)
[li]Current Mana (Numeric)
[li]Current Mana (Percent)
[li]Potion Cooldown

[b]Outer Ring Display[/b]
[li]Nothing
[li]Mana Percentage
[li]Hit Points Percantage
[li]Potion Cooldown

[b]Drink Button[/b]
[li]Left-Click to drink.
[li]Right-Click to eat food (Available soon!).
[li]Middle-click to use bandages (Available soon!).

[b]Potion Button[/b]
[li]Left-Click to drink mana potion.
[li]Right-Click to drink healing potion.
[li]Automatically switches to PvP Potions when on a battleground.

[b]Decursive Button[/b]
[li]Left-click to cast Dispel Magic offensively or decursively.
[li]Right-click to cast Abolish/Cure Disease decursively.
	

[b]Three "Anything" Buttons[/b]
[li]Known as "left spell button", "middle spell button and "right spell button"
[li]Configurable to cast any spell from the buff menu or spell menu
[li]=>Left-click to cast primary spell (eg Power Word: Fortitude)
[li]=>Right-click to cast alternate spell (eg Prayer of Fortitude)

[b]Buff Menu Button[/b]
[li]Click to show available buffs
[li]=> Left-click to the button cast primary spell, right-click to cast alternate
[li]===> Includes Power Word: Fortitude (Prayer of Fortitude), Divine Spirit (Prayer of Spirit), Shadow Protection (Prayer of Shadow Protection)
[li]===> Inner Fire, Racial Spells, Inner Focus, Power Infusion, Shadowform
[li]Right-click to recast the last spell called from this menu
[li]Middle-click or Alt-click to keep the menu from automatically closing

[b]Mount Button[/b]
[li]Automatically detects your mount when enabled
[li]Right-click to use hearthstone

[b]Spell Menu Button[/b]
[li]Click to show available spells
[li]=> Spells Include: Fade, Lightwell, Resurrection, Pyschic Scream, Mind Control, Mind Sooth, Mind Vision, Shackle Undead
[li]Right-click to recast the last spell called from this menu
[li]Middle-click or Alt-click to keep the menu from automatically closing

[b]Spelltimer Button[/b] (defaults off)
[li]Spell cooldowns and durations will appear on the right of this button (configurable)
[li]Right-click the button to use your hearthstone

-------------------------------
4 - More functionalities
-------------------------------

[li]You can put the Serenity Sphere wherever you want
[li]You can put the Serenity Buttons wherever you want

[li]Automatically restock your reagents to the amount of your chosing (with or without a confirmation)
[li]Show various information on the outer ring of the main sphere, including health, mana, and cooldowns

[li]Advanced warning, letting you know when your shackles are about to break and telling you when it does break
[li]Random chat messages available for shackle undead, resurrection, and mounting.  
[li]=>Shackle message only shows when you are polymorphing a new target
[li]=>All chat messages configurable to a short, raid-ready version using /serenity sm

[li]Show or remove any of the visible buttons
[li]Show or remove cooldowns or reagent counts from any button
[li]Option to automatically open/close the buff menu on mouse-over

[li]Text-based timers available for lower-end machines
[li]Timers can grow upward and be anchored from either side of the spelltimer button, to fit anywhere on your screen

[li]Rotate the buttons around the sphere to fit your settings
[li]Detact the buttons from the sphere and move them whereever you'd like.
[li]All of your spell cooldowns and durations will be displayed on the spell timers.


-------------------------------
5 - Slash commands
-------------------------------

[li]/serenity -- open the configuration menu and display a list of slash commands
[li]/serenity recall -- Center Serenity and all the buttons in the middle of the screen
[li]/serenity sm -- Replace messages with a short raid-ready version
[li]/serenity reset -- Restore default settings

-------------------------------
6 - Help needed
-------------------------------

If you find any errors, or have any suggestions, let me know! I am always looking to improve my mod
and make it usable by everyone.  If you find a missing translation or would like to help translate, please
contact me!  I am interested in making my mod as available as possible.

-------------------------------
7 - FAQ
-------------------------------

Q: What is this Necrosis you keep mentioning?
A: My main character is a warlock and as such, I wanted to be the best warlock
   I could.  I found Necrosis LdC and fell in love with it.  On a Patch day if
   Necrosis would break, I wouldn't be able to play my warlock.  When I made
   My mage, I felt it could really benefit from a similar mod.  When I finished
   Cryolysis, I decided priest needed it too!

Q: So you stole the code made by Lomig and Nyx?!
A: Yes and no.  I went through their code and changed a lot of things around so
   It would work for mage.  I also added my own code to certain places like 
   Mana gems, right-clicking buff menu, etc.  Before releasing, I asked permission
   and they said it would be fine, as long as I give them credit (which is well
   (deserved!)

Q: How often do you update?
A: I am constantly tweeking things.  Whenever I am on, I am trying to make Serenity better.  I suggest adding Serenity to your favorites so you can easily watch for updates, becuase they come by quickly!

Q: I'm not a mage or priest. can you make this for my class?
A: Changing Necrosis to Cryolysis actually took a lot more work than I expected.  I was motivated, however, since I was just starting out my mage and I wanted to feel as at home there as I did on my warlock.  As of right now, I have no plans to work on a version for another class.  If I were to make another one, it would have to be for a class I was playing.  Most likely, it would come for rogue or hunter, as rogue is my next favorite class and I do not have a hunter on this server.

Q: Can I give you money?!
A: Of course!  please send your paypal donations to darklyte@gmail.com!

Q: Can I come talk to you on Aegwynn (Horde side)?
A: I have many characters.  About 10 or so, and I change on a whim.  Your best bet is to ask someone in my guild, <Working as Intended>, where I am.

Q: How else can I contact you?
A: E-mail: darklyte@gmail.com, AIM: darklyte64.  I also check curse-gaming, ui.worldofwar.net, and the official warcraft forums many times a day.  I will usually answer your questions within 12 hours.  Less if I am awake!
