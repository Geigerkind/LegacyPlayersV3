--===================================================================================================================--
-- Name:        Paranoia
-- Description: A WoW AddOn which tries to detect enemies in the near vicinity. Detection is done by registering to
--              events which are triggered by enemy players. This AddOn is about alerting the player of enemies and 
--              not supposed to hunt down enemies or used in a PvP Raid. In later it might even create unwanted noise.
-- Author:      rmet0815, October 27, 2005
--===================================================================================================================--

local MAX_LINES = 10;
local LOOKUP_DELAY = 1;		-- seconds

local PARANOIA_ZONE_REAL_NAME_ALTERAC_VALLEY = 'Alterac Valley';
local PARANOIA_ZONE_REAL_NAME_WARSONG_GULCH = 'Warsong Gulch';
local PARANOIA_ZONE_REAL_NAME_ARATHI_BASIN = 'Arathi Basin';

      Paranoia_Config = { enabled = true,
                          showTitle = true,
                          targetHostile = true,
                          disableInBattlefield = false,
                        };

local gLastWarnHostilePlayer = 0;

local gHostileList = {};
local gMaxHostiles = 50;
local gCurHostiles = 0;

local gNotHostileList = {};
local gMaxNotHostiles = 100;
local gCurNotHostiles = 0;

local gLastLookup = 0;

--===================================================================================================================--
--  Events
--===================================================================================================================--
function Paranoia_OnLoad()

  this:RegisterForDrag("LeftButton");

  SlashCmdList["PARANOIACONF"] = Paranoia_ShowConfig;
  SLASH_PARANOIACONF1 = "/paranoia";
  SLASH_PARANOIACONF2 = "/pconf";

  this:RegisterEvent( "VARIABLES_LOADED" );

  this:RegisterEvent( "CHAT_MSG_COMBAT_HOSTILEPLAYER_HITS" );
  this:RegisterEvent( "CHAT_MSG_COMBAT_HOSTILEPLAYER_MISSES" );
--  this:RegisterEvent( "CHAT_MSG_SPELL_HOSTILEPLAYER_BUFF" );		does not work
  this:RegisterEvent( "CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE" );
  this:RegisterEvent( "CHAT_MSG_SPELL_PERIODIC_HOSTILEPLAYER_BUFFS" );
  this:RegisterEvent( "CHAT_MSG_SPELL_PERIODIC_HOSTILEPLAYER_DAMAGE" );

  this:RegisterEvent( "PARTY_MEMBERS_CHANGED" );

  Paranoia_Frame_Status1:ClearAllPoints();
  Paranoia_Frame_Status1:SetPoint( "TOPLEFT", "Paranoia_Frame_Main", "TOPLEFT", 8, -8 );
  
  Paranoia_Frame_Status2:ClearAllPoints();
  Paranoia_Frame_Status2:SetPoint( "TOPLEFT", "Paranoia_Frame_Status1", "BOTTOMLEFT", 0, 0 );
  Paranoia_Frame_Status3:ClearAllPoints();
  Paranoia_Frame_Status3:SetPoint( "TOPLEFT", "Paranoia_Frame_Status2", "BOTTOMLEFT", 0, 0 );
  Paranoia_Frame_Status4:ClearAllPoints();
  Paranoia_Frame_Status4:SetPoint( "TOPLEFT", "Paranoia_Frame_Status3", "BOTTOMLEFT", 0, 0 );
  Paranoia_Frame_Status5:ClearAllPoints();
  Paranoia_Frame_Status5:SetPoint( "TOPLEFT", "Paranoia_Frame_Status4", "BOTTOMLEFT", 0, 0 );
  Paranoia_Frame_Status6:ClearAllPoints();
  Paranoia_Frame_Status6:SetPoint( "TOPLEFT", "Paranoia_Frame_Status5", "BOTTOMLEFT", 0, 0 );
  Paranoia_Frame_Status7:ClearAllPoints();
  Paranoia_Frame_Status7:SetPoint( "TOPLEFT", "Paranoia_Frame_Status6", "BOTTOMLEFT", 0, 0 );
  Paranoia_Frame_Status8:ClearAllPoints();
  Paranoia_Frame_Status8:SetPoint( "TOPLEFT", "Paranoia_Frame_Status7", "BOTTOMLEFT", 0, 0 );
  Paranoia_Frame_Status9:ClearAllPoints();
  Paranoia_Frame_Status9:SetPoint( "TOPLEFT", "Paranoia_Frame_Status8", "BOTTOMLEFT", 0, 0 );
  Paranoia_Frame_Status10:ClearAllPoints();
  Paranoia_Frame_Status10:SetPoint( "TOPLEFT", "Paranoia_Frame_Status9", "BOTTOMLEFT", 0, 0 );

end

function Paranoia_LoadVariables()

  if ( Paranoia_Config.enabled ) then
    ShowUIPanel( Paranoia_Frame_Main );
  else
    HideUIPanel( Paranoia_Frame_Main );
  end

end

function Paranoia_OnEvent( event, arg1, arg2, arg3)

  if ( event == "VARIABLES_LOADED" ) then
    Paranoia_LoadVariables();
    Paranoia_PartyMembersChanged();
  elseif ( event == "CHAT_MSG_COMBAT_HOSTILEPLAYER_HITS" or
           event == "CHAT_MSG_COMBAT_HOSTILEPLAYER_MISSES" or
           event == "CHAT_MSG_SPELL_HOSTILEPLAYER_BUFF" or
           event == "CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE" or
           event == "CHAT_MSG_SPELL_PERIODIC_HOSTILEPLAYER_BUFFS" or
           event == "CHAT_MSG_SPELL_PERIODIC_HOSTILEPLAYER_DAMAGE" ) 
  then
    Paranoia_WarnHostilePlayer( event, arg1 );
  elseif ( event == "PARTY_MEMBERS_CHANGED" ) then
    Paranoia_PartyMembersChanged();
  end

end

function Paranoia_OnDragStart()

  Paranoia_Frame_Main:StartMoving();

end

function Paranoia_OnDragStop()

  Paranoia_Frame_Main:StopMovingOrSizing();

end

function Paranoia_OnUpdate()

  if ( Paranoia_Config.enabled and 
      ((not Paranoia_Config.disableInBattlefield) or (not Paranoia_IsPlayerInBattlefield())) ) 
  then
    if ( (not Paranoia_Frame_Main:IsVisible()) ) then
      ShowUIPanel( Paranoia_Frame_Main );
    end
    Paranoia_UpdateHostileList();
  else
    gHostileList = {};
    gCurHostiles = 0;
    gNotHostileList = {};
    gCurNotHostiles = 0;
    HideUIPanel( Paranoia_Frame_Main );
  end

end

--===================================================================================================================--
--  Helper functions
--===================================================================================================================--

function Paranoia_IsPlayerInBattlefield()

  local currZone = GetRealZoneText();

  if ( currZone == PARANOIA_ZONE_REAL_NAME_ALTERAC_VALLEY or 
       currZone == PARANOIA_ZONE_REAL_NAME_WARSONG_GULCH or 
       currZone == PARANOIA_ZONE_REAL_NAME_ARATHI_BASIN )
  then
CH_Msg( 'TRUE' );
    return( true );
  end

  return( false );

end

function Paranoia_ToBoolean( value )

  if ( value == nil ) then
    return( false );
  end

  if ( type(value) == 'booloean' ) then
    return( value );
  end

  return( true );

end

function Paranoia_Msg( msg )

  ChatFrame1:AddMessage( "<P>"..msg );

end

function Paranoia_TargetByName( name )

  local prevTargetName = nil;

  if ( UnitExists('target') ) then
    prevTargetName = UnitName('target');
  end

  if ( not UnitExists('target') or UnitName('target') ~= name ) then
    TargetByName( name );
  end

  if ( UnitExists('target') and UnitName('target') == name ) then
    return( true );
  end

  Paranoia_ReTarget( prevTargetName );
 
  return( false ); 

end

function Paranoia_ReTarget( lastTargetName )

  if ( lastTargetName ) then
    if ( UnitExists('target') and UnitName('target') == lastTargetName ) then
      return;
    end

    TargetLastTarget();
    local curTargetName = UnitName("target");
    if ( (not UnitExists('target')) or (not curTargetName) or curTargetName ~= lastTargetName ) then
      Paranoia_Msg( "-----------------------------------------------" );
      Paranoia_Msg( "LOST TARGET !!!! (last: "..lastTargetName..")" );
      if ( not curTargetName ) then
        Paranoia_Msg( "(now: NIL)" );
      else
        Paranoia_Msg( "(now: "..curTargetName..")" );
      end
      Paranoia_Msg( "-----------------------------------------------" );
      TargetByName( lastTargetName );
    end
  else
    ClearTarget();
  end

end

--===================================================================================================================--
-- HOSTILE HANDLING
--===================================================================================================================--

function Paranoia_AddNotHostile( name )

  if ( gNotHostileList[name] ) then
    gNotHostileList[name].time = GetTime();
  elseif ( gCurNotHostiles < gMaxNotHostiles ) then
    gNotHostileList[name] = { time = GetTime() };
    gCurNotHostiles = gCurNotHostiles + 1;
  end

end

function Paranoia_PartyMembersChanged()

  local i;

  Paranoia_AddNotHostile( UnitName('player') );
  if ( UnitExists('pet') ) then
    Paranoia_AddNotHostile( UnitName('pet') );
  end

  for i = 1, GetNumPartyMembers() do
    if ( UnitExists('party'..i) ) then
      Paranoia_AddNotHostile( UnitName('party'..i) );
    end
    if ( UnitExists('partypet'..i) ) then
      Paranoia_AddNotHostile( UnitName('partypet'..i) );
    end
  end

end

function Paranoia_HostileExtractName( msg )

  local name = nil;

  local pos = string.find( msg, '%s' );			-- %s = space
  if ( pos ) then
    name = strsub( msg, 1, pos-1 );
    pos = string.find( name, "'" );			-- ' (Gror's fireball ...)
    if ( pos ) then
      name = strsub( msg, 1, pos-1 );
    end
  end

  return( name );

end

function Paranoia_MayTargetUnit( name )

 return( (Paranoia_Config.targetHostile and not (UnitExists('target') and UnitIsEnemy('player','target'))) or 
         (UnitExists('target') and UnitName('target') == name) );

end

function Paranoia_WarnHostilePlayer( event, msg )

  local isHostile = false;

  if ( not (Paranoia_Config.enabled and msg) ) then
    return;
  end

  local name = Paranoia_HostileExtractName( msg );
  if ( name ) then
    if ( gHostileList[name] ) then
      gHostileList[name].time = GetTime();
      isHostile = true;
    elseif ( gNotHostileList[name] ) then
      gNotHostileList[name].time = GetTime();
      isHostile = false;
    elseif ( Paranoia_MayTargetUnit(name) ) then
      local lastTargetName = UnitName("target");
      if ( Paranoia_TargetByName(name) ) then
        isHostile = Paranoia_UnitIsHostile("target",name);
        if ( isHostile and gCurHostiles < gMaxHostiles ) then
          Paranoia_AddTargetedHostile( name );
        elseif ( not isHostile and gCurNotHostiles < gMaxNotHostiles ) then
          gNotHostileList[name] = { time = GetTime() };
          gCurNotHostiles = gCurNotHostiles + 1;
        end
        Paranoia_ReTarget( lastTargetName );
      else
        Paranoia_AddUntargetedHostile( name );
        isHostile = true;
      end
    else
      Paranoia_AddUntargetedHostile( name );
      isHostile = true;
    end
  end

  if ( isHostile and GetTime() - gLastWarnHostilePlayer > 60 ) then
    PlaySoundFile( "Interface\\AddOns\\Paranoia\\ganker.wav" );
    gLastWarnHostilePlayer = GetTime();
  end

end

function Paranoia_UnitIsHostile( unit, name )

  return( UnitExists(unit) and UnitName(unit) == name and UnitIsPlayer(unit) and UnitIsEnemy("player",unit) );

end

function Paranoia_AddTargetedHostile( name )

  gHostileList[name] = { time = GetTime() };
  gCurHostiles = gCurHostiles + 1;

  gHostileList[name].class = UnitClass("target");
  gHostileList[name].level = UnitLevel("target");
  if ( gHostileList[name].level ~= nil and gHostileList[name].level > 0 ) then
    gHostileList[name].levelDiff = gHostileList[name].level - UnitLevel("player");
  else
    gHostileList[name].levelDiff = '?';
  end

end

function Paranoia_AddUntargetedHostile( name )

  gHostileList[name] = { time = GetTime() };
  gCurHostiles = gCurHostiles + 1;

  gHostileList[name].class = '???';
  gHostileList[name].level = 0;
  if ( gHostileList[name].level ~= nil and gHostileList[name].level > 0 ) then
    gHostileList[name].levelDiff = gHostileList[name].level - UnitLevel("player");
  else
    gHostileList[name].levelDiff = '?';
  end

end

function Paranoia_LookupHostile( name )

  if ( not gHostileList[name] or GetTime() < gLastLookup + LOOKUP_DELAY ) then
    return;
  end

  gLastLookup = GetTime();

  if ( (not gHostileList[name].class or gHostileList[name].class == '???') and Paranoia_MayTargetUnit(name) ) then
    prevTargetName = nil;
    if ( Paranoia_TargetByName(name) ) then
      gHostileList[name].class = UnitClass("target");
      gHostileList[name].level = UnitLevel("target");
      if ( gHostileList[name].level ~= nil and gHostileList[name].level > 0 ) then
        gHostileList[name].levelDiff = gHostileList[name].level - UnitLevel("player");
      else
        gHostileList[name].levelDiff = '?';
      end
      Paranoia_ReTarget( name );
    end
  end

end

function Paranoia_UpdateHostileList()

  local buttonText, i, displayed;
  local dispName, class;

  if ( Paranoia_Config.showTitle and (not ParanoiaTitle:IsVisible()) ) then
    ParanoiaTitle:Show();
  elseif ( (not Paranoia_Config.showTitle) and ParanoiaTitle:IsVisible() ) then
    ParanoiaTitle:Hide();
  end

  displayed = 0;
  i = 1;
  for name,_ in gHostileList do
    if ( gHostileList[name].time < GetTime() - 60 ) then
      gHostileList[name] = nil;
      gCurHostiles = gCurHostiles - 1;
    elseif ( i <= MAX_LINES ) then
      button = getglobal( "Paranoia_Frame_Status"..i );
      buttonText = getglobal( "Paranoia_Frame_Status"..i.."Text" );

      Paranoia_LookupHostile( name );

      dispName = name;

      class = gHostileList[name].class;
      if ( class == 'Warlock' ) then
        class = 'Wlk';
      else
        class = strsub(class,1,3);
      end

      button:Show();
      button.nickname = name;
      button.id = name;
      buttonText:SetText( dispName.." ("..class.."/"..gHostileList[name].levelDiff..")" );
      buttonText:SetTextColor( 1, 1, 0 );

      displayed = displayed + 1;
      i = i + 1;
    end
  end

  while ( i <= MAX_LINES ) do
    button = getglobal( "Paranoia_Frame_Status"..i );
    buttonText = getglobal( "Paranoia_Frame_Status"..i.."Text" );

    button:Hide();
    button.nickname = "empty"..i;
    button.id = "emptyid"..i;
    buttonText:SetText( "empty"..i );
    buttonText:SetTextColor( 0.5, 0.5, 0.5 );

    i = i + 1;
  end

  for name,_ in gNotHostileList do
    if ( gNotHostileList[name].time < GetTime() - 60*60*3 ) then		-- 3 hours
      gNotHostileList[name] = nil;
      gCurNotHostiles = gCurNotHostiles - 1;
    end
  end

  --change the window height according to max on list
  if ( displayed < 1 ) then
    displayed = 1;
  end
  Paranoia_Frame_Main:SetHeight( 10 + displayed*18 );

end

--===================================================================================================================--
-- Config GUI
--===================================================================================================================--

function Paranoia_OptionCheckBoxClicked( option )

  Paranoia_Config[option] = Paranoia_ToBoolean( this:GetChecked() );

end

function Paranoia_OptionCheckBoxInit( option )

  this:SetChecked( Paranoia_ToBoolean(Paranoia_Config[option]) );

end

function Paranoia_ShowConfig()

  ParanoiaConf_Frame:Show();

end

function ParanoiaConf_CloseClicked()

  ParanoiaConf_Frame:Hide();

end
