function AutoHideBar_OnUpdate()
	AutoHideBar_CheckMouse();
	AutoHideBar_showkey();	
	AutoHideBar_Check();
	
	
	
end	
