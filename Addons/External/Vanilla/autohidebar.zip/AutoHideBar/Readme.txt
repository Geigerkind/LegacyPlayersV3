AutoHideBar 1.4
---------------

New in 1.4
	- Scaling is centerd
	- Shows binding key at buttontemplate 
	- Added langue support, if anyone want to add a langue send a e-mail
	- renamed and moved around much in the code
	- Added help and reset as a slash command 
	- Rewritten bagcheck (take no memory) 
	- Fixed a bug with the lock function 
	- Fixed a set level bug with the template 
	- Fixed Some bugs

Install: Unzip AutoHideBar.zip to \World of Warcraft\Interface\Addons

- Creates a 20 button bar that autohides when the mouse is no longer on the template.
	(shift+mouseover or your ownshowkey+mouseover can also be set)
- Can set a keybinding to every AHB button
- Ability to scale AHB
- Ability to lock AHB interface and button
- Buttons autolock in combat (shift+click disabled)
- Can set to be hidden in combat
- Can Bind a key to open/hide AHB
- Ability to change ButtonID from within WoW

Then using your own showkey, you have to press it over AHB othervise it wont work.

Known bugs:
- AHB sometimes get stuck on the mouse. Will work after reload (rare)
- Texture on the first button can disappear (work after open and close AHB)
- Texture on the tabbed button can be wrong (work after reload)

ButtonID: Buttons have got be in range 1-20 and ButtonID got to be in range 1-120

Type /ahb or /ahb setting for the graphic settings

Short commands:

/ahb shift		- Show AutoHideBar with shift+mouseover
/ahb mouse 		- show AutoHideBar with just mouseover
/ahb own	 	- turn off shift and mouse but your own showkey still working
/ahb combat		- Turn off or on if AutoHideBar shall be visible in combat. Default is visible in combat
/ahb reload		- Reloads all addons. Same as /console reloadUI
/ahb reset		- Reset to default settings
/ahb help 		- Show commands

Remembar that AHB save sattings for every character.

Hope you like our addon - Entropy/Spjutbjorn

Email: entropi@zytor.com 
Page: http://www.curse-gaming.com/en/wow/addons-3196-1-autohidebar.html