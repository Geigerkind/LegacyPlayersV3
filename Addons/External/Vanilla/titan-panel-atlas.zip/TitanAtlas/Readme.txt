Please ensure you have removed the original version of Atlas, before installing this version.


In Version (1.0.5)
As requested I have added Chinese and German localization, I obtained these from the mods created by Maischter & DiabloHu
----------------------------------------------------------------------

In version (1.0.4)
Added the ability for the atlas to automatically select the correct map when you enter an instance
----------------------------------------------------------------------

In version (1.0.3)
Corrected bug that prevented label from being removed
----------------------------------------------------------------------

In version (1.0.2)
Corrected name in Addons manager
----------------------------------------------------------------------

In version (1.0.1)
New tooltip
New button name (now shows map you will view on pop up)
Remembering of the last map you viewed

