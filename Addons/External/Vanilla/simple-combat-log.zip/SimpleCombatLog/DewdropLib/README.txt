DewdropLib v1.0 $Revision: 1238 $

Author: ckknight (ckknight@gmail.com)
$Date: 2006-04-30 18:04:20 -0500 (Sun, 30 Apr 2006) $

A library to provide a clean dropdown menu interface.

Users:
	TO INSTALL: Put the DewdropLib folder into
		\World of Warcraft\Interface\AddOns\

Developers:
	Place the DewdropLib.lua file into your AddOn's folder, then add DewdropLib.lua to the .toc file.
	Then, to access the library, in your code, write `local dewdrop = DewdropLib:GetInstance("1.0")`.
	From that point on, you can access DewdropLib's functions.

If you find _any_ bugs, feel free to submit them at
http://ckknight.wowinterface.com/portal.php?id=54&a=listbugs

If you want to request any features, feel free to submit your ideas at
http://ckknight.wowinterface.com/portal.php?id=54&a=listfeatures
