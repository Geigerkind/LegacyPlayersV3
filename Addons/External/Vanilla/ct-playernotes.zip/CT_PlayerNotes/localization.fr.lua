-- Version : French ( by Sasmira )
-- Last Update : 03/31/2005


if ( GetLocale() == "frFR" ) then

CT_PLAYERNOTES_EDITING = "Editer la note pour le joueur '%s'.";
CT_PLAYERNOTES_CANCEL = "Annuler";
CT_PLAYERNOTES_UPDATE = "M.\195\160.J.";
CT_PLAYERNOTES_EDITNOTE = "Editer Note";
CT_PLAYERNOTES_CLICKEDIT = "Cliquer pour \195\169diter";

end