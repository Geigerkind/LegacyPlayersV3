CT_PLAYERNOTES_EDITING = "Editing note for player '%s'.";
CT_PLAYERNOTES_CANCEL = "Cancel";
CT_PLAYERNOTES_UPDATE = "Update";
CT_PLAYERNOTES_EDITNOTE = "Edit Note";
CT_PLAYERNOTES_CLICKEDIT = "Click to edit";
