if ( GetLocale() == "deDE" ) then
	-- Credits to Hj�rvar�r for these

	CT_TICKMOD_OFF = "HP&MP Regenerationsanzeige wurde deaktiviert.";
	CT_TICKMOD_ON = "HP&MP Regenerationsanzeige wurde aktiviert.";

	CT_TICKMOD_MODNAME = "Regen Mod";
	CT_TICKMOD_SUBNAME = "Ein/Aus Schalter";
	CT_TICKMOD_TOOLTIP = "Schaltet HP&MP Regenerationsanzeige an/aus.";

end