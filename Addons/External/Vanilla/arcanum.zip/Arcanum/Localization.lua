﻿ArcanumData = {};
ArcanumData.Version = "0.101";
ArcanumData.Author = "Nausicaa on Medivh FR";
ArcanumData.AppName = "Arcanum";
ArcanumData.Label = ArcanumData.AppName.." "..ArcanumData.Version.." by "..ArcanumData.Author;