local L = AceLibrary("AceLocale-2.0"):new("FruityLoots")

L:RegisterTranslations("enUS", function()
    return {
        ["Once"] = "Only position mouse cursor once",
    }
end)