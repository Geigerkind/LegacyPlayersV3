local L = AceLibrary("AceLocale-2.0"):new("FruityLoots")

L:RegisterTranslations("deDE", function()
    return {
        ["Once"] = "Mauszeiger nur einmal positionieren",
    }
end)