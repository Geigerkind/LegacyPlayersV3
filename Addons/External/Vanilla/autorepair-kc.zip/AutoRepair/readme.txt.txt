This Mod automatically Kicks in when you visit a vendor who can repair items.

type /ar mincost to view the default min repair cost.