AR_TEXT_LOADPATTERN	=	"AutoRepair v%s loaded.";

AR_TEXT_SLASHFULL	= "/autorepair";
AR_TEXT_SLASHAVB	= "/ar";

AR_TEXT_DEFAULT1	= "Default Variable Values Loaded."
AR_TEXT_DEFAULT2	= "To Learn How To Change Settings Type /ar"

AR_TEXT_ENABLED		= "Enabled";
AR_TEXT_DISABLED	= "Disabled";