ChatFilter_ChatFrame_OnEvent = ChatFrame_OnEvent
ChatFilter_Timer = GetTime()
ChatFilter_Messages = {{},{},{},{},{},{},{},{},{}}

function ChatFrame_OnEvent(event)

			local type = strsub(event, 10);
			if ( string.sub(type,1,7) == "CHANNEL" or type == "WHISPER" or type == "GUILD" or type == "YELL" or type == "SAY" or type == "EMOTE" or type == "RAID" ) then
				while ChatFilter_Timer < GetTime() do
					ChatFilter_Timer = ChatFilter_Timer + 1
					for i = 0,7 do
						ChatFilter_Messages[9-i] = ChatFilter_Messages[9-i-1]
					end
					ChatFilter_Messages[1] = {}
				end
				for i = 1,5 do
					for j = 1, table.getn(ChatFilter_Messages[i]) do
						if ChatFilter_Messages[i][j] == arg2..arg1 then
							return
						end
					end
				end
				table.insert(ChatFilter_Messages[1],arg2..arg1)
			end
		
	ChatFilter_ChatFrame_OnEvent(event)
end


function ColorPrint(msg,r,g,b)
	DEFAULT_CHAT_FRAME:AddMessage(msg, r, g, b)
end
function Print(msg)
	ColorPrint(msg, 1, 1, 0)
end