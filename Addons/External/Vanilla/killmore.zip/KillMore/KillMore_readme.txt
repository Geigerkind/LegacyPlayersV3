TXTLINGIT'S KillMore
====================

This is a rework of Mobs2Level ( http://www.curse-gaming.com/mod.php?addid=206 )

I have added code to allow the user to choose if the information is output in the chat
window or on the main screen. This was requested in the comments section of Mobs2Level
and Mobs2Level has not been updated since January 2005.

Commands:
=========
"/killmore"               shows this help message
"/killmore chat"          outputs the KillMore data in the chat window
"/killmore error"         outputs the KillMore data to the main screen
"/killmore both"          outputs the KillMore data to the chat window and main screen
"/killmore off"           turns KillMore off
"/killmore status"        shows KillMore status

ToDo:
=====
- Nothing at the moment

Known Bugs:
===========
- None

Change History:
===============
v0.4 - Added option to turn off KillMore output, added status
v0.3 - Added option to output information in both manners at the same time
v0.2 - Added German client support and framework for other localized clients
v0.1 - First publicly available release

Notes:
======
- Thank you centrino for the German translations :)