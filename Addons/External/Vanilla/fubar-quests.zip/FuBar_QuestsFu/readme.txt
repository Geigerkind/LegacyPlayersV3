FuBar - QuestsFu 1.2 $Revision: 1687 $

Author: Kemayo <kemayo@gmail.com>
Release Date: $Date: 2006-05-11 10:10:41 -0700 (Thu, 11 May 2006) $

This is a quest-tracker replacement plugin for FuBar (http://boss.wowinterface.com/).
It provides a tooltip which replicates /most/ of the information from the quest log.  (Quest
levels, difficulty, objectives, zones, and so on.)  In addition, quest completion status can
be shown in the tooltips for quest items and monsters.

Shift-click on quests in the tooltip to add them to Blizzard's quest-tracker.
Control-click on quests in the tooltip to share them with your party.
Alt-click on quests in the tooltip to copy them to the chatbox if it's open.

To install:
    Copy the FuBar_QuestsFu folder to: World of Warcraft/Interface/Addons

Comments may be made at: http://www.wowinterface.com/downloads/fileinfo.php?id=4752
Bug reports can be made at: http://www.wowinterface.com/portal.php?uid=28542&a=listbugs
Feature requests can be made at: http://www.wowinterface.com/portal.php?uid=28542&a=listfeatures
