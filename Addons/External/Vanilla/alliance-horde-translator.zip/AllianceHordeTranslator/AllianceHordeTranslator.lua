--This addon returns an emote for an emote
--
--
--

--CONSTANTS
--
HORDE = "Horde";
ALLIANCE = "Alliance";
COMMON = "Common";
ORCISH = "Orcish";


--TRANSLATION TABLE --------------- ADD YOUR OWN!!
--
Translations = {
"Hey you! Come here and shine my shoes!",
"Look at my new shiny trinket! I need some polish.",
"Heavens to Mergatroid! I can't find the freaking bank!",
"Do these new shoulders make me look hot?",
"Let's go ganking!",
"Where are my Murloc pajamas?!?!",
"I don't care if this sword has 20 more damage and two gem slots, it doesn't match my new greaves!",
"Free ice cream at the bank!",
"I'm a complete idiot!",
"Your retarded!",
"Without me, it would just be aweso!",
"Paying 5g to run me through deadmines!",
"We don't need no stinking emblems of heroism!",
"Cybering in the violet tower for 15g. C.O.D.",
"Smoking kills. If you're killed, you've lost a very important part of your life.",
"WTB a gnome for punting!",
"Rogues like to do it from behind!",
"Woohoo! 80! LFG H-Naxx!",
"I miss Dalaran being a big pink bubble by the lake.",
"Southshore versus Tauren Mill. Retro!",
"LF a Volunteer to rub jelly on my belly!",
"The word 'genius' isn't applicable in the Trade Channel. A genius is a guy like Norman Einstein.",
"Fiction is great, you can make up almost anything.",
"LFM 25-Naxx. We don't necessarily discriminate. We simply exclude certain types of people.",
"The world is more like it is now then it ever has before.",
"If you take out the killings, Wintergrasp actually has a very low crime rate.",
"You can put lipstick on Hogger. It's still Hogger!",
"I'm not happy. Can you make me happy?",
"Lf2M Ulduar. All Items Reserved! Plz come heal!",
"I think there is a Trojan horse lurking in the weeds trying to pull a fast one.",
"I think we agree, the past is over",
"If this were a dictatorship, it would be a heck of a lot easier.",
"If we do not succeed, we run the risk of failure.",
"It isn't pollution that's harming the environment. It's the impurities in our air.",
"The future will be better tomorrow",
"LOLUMAD?",
"I've never really wanted to go to Japan. Simply because I don�t like eating fish. And I know that's very popular out there in Africa.",
"I need someone to pull something for me!",
"WTT lvl 80 Resto Druid for a triple scoop chocolate on a sugar cone!",
"KEK! That means LOL right?",
"Thanks for logging on. I look forward to groping with you tomorrow!",
"Mooooooo!",
"Where the hell do I get a tickbird hatchling?",
"HELP!",
"Heal me!",
"So always look on the bright side of death!",
"Strategy is for cowards!",
"It's better to burn out than to fade away",
"I've had a wonderful time, but this wasn't it.",
"All your base are belong to us!",
"Pooping is an act of violence!",
"Who wants to pick herbs with me?",
"Coffee or ice? What is it baby?",
"I am playing my son's character. How do I heal?",
"The Tunisian barber has eaten the submerged gumball machine.",
"Once Cinderella was done, she threw down the machine gun and strolled to the door, leaving a grenade in her wake.",
"When the time comes, was it via the big hand or the little hand?",
"I want to put a clown nose on you and feed you pudding.",
"Janet Reno is an attractive lady.",
"My big toe feels like Rob Lowe pinched Nick Cage's nose off with his ventroliquist-controlled mechanical butt cheeks.",
"My cat is pickling Santa Claus in the doo-doo hole while jackhammering mickey mouse with a sausage full of melted cheese.",
"The General likes a woman wearing skimpy undergarments, plus a different colored booger hanging out of each nostril.",
"Speech therapy is not for animals, nor cacti.",
"I just got my head chopped off and lived.",
"Stipulations have arisen amidst the chipmunks of yesteryear, to the point that the fog is really a fartknocker's dream.",
"Aragorn strode up to the Black Gate wearing tights and playing a banjo, while Gandalf, Merry, Pippin, Legolas, Gimli, and Elrond were arm-locked and doing a riverdance.",
"Gandalf turned his attention to the assembled warriors, fixing his gaze upon each one in turn, looking for any signs of weakness. Finally he spoke, his voice raw with power. 'Whoever stole my underwear, I should like it back immediately.'",
"Sleeveless hamburglars rip through the orphanage with orangesickles and potato bugs.",
"The Eskimo bladder infestation has taken its toll on the sunflower seed bonanza.",
"Poo poo is not real doo doo, unless the poo poo has doo doo blood running through its veins.",
"Obi Wan took in a deep breath, and without warning boxed Yoda's ears from behind while echoing the cry of a dark-blossomed warbler in heat.",
"If you say meatsabre one more time, I will cut your head off and poop down your throat!",
"Rogues do terrible DPS during Halloween events.",
"LF4M with First Aid Capped!",
"Help me! I'm being camped on my alt by a 72 rogue in STV!",
"LF1M Ulduar!",
"LFM All Classes 25 man Naxx. No losers!",
"L2Play Mister !L2Play"
}


--loaded when the lua file is loaded
--
function AllianceHordeTranslator_OnLoad()

    	this:RegisterEvent("CHAT_MSG_SAY");
    	this:RegisterEvent("CHAT_MSG_YELL");

	--display on load
	--
	DEFAULT_CHAT_FRAME:AddMessage("Alliance Horde Translator Version 1.05 Loaded");

end


function AllianceHordeTranslator_OnEvent()

	local strFaction = "";
	local strFactionCheck = "";
	local strTranslation = "";
	local strFrom = "Alliance ";
	local strTo = "";
	local tester = "";
	local strSayOrShout = "says";
	local strTextColor = "";
	local strMyFaction = UnitFactionGroup("player");
	local strMyLang = GetDefaultLanguage("player"); 
	-- COMMON;

	--set my
	--if (strMyFaction == HORDE) then
		--strMyLang = ORCISH;
	--end

	--DEFAULT_CHAT_FRAME:AddMessage("My Language  " .. strMyLang, .8, 0.0, 0.0);
	--DEFAULT_CHAT_FRAME:AddMessage("My Faction " .. strMyFaction, .8, 0.0, 0.0);
	--DEFAULT_CHAT_FRAME:AddMessage("Language Heard " .. arg3, .8, 0.0, 0.0);

	--if my language is not the one
	--currently being checked
	if (strMyLang == arg3) then

		return;

	else

		strTranslation = arg3 .. " to " .. GetDefaultLanguage("player");		

		--if(strMyFaction == HORDE) then
			--strTranslation = COMMON .. " to " .. ORCISH;
			
			--strFrom = "Horde ";
		--else
			--strTranslation = ORCISH .. " to " .. COMMON;
		--end

		if (event == "CHAT_MSG_YELL") then
			--DEFAULT_CHAT_FRAME:AddMessage("[" .. arg2 .. "] yells: " .. "[" .. strTranslation .. "] " .. Translations[math.random(table.getn(Translations))], .8, 0.0, 0.0);
			
			SendChatMessage("Hey! " .. arg2 .. " just yelled: " .. "[" .. strTranslation .. "] " .. Translations[math.random(table.getn(Translations))] , "YELL");  

		else
			--DEFAULT_CHAT_FRAME:AddMessage("[" .. arg2 .. "] says: " .. "[" .. strTranslation .."] " .. Translations[math.random(table.getn(Translations))]);
			SendChatMessage("Hey! " .. arg2 .. " just said: " .. "[" .. strTranslation .. "] " .. Translations[math.random(table.getn(Translations))] , "SAY");  
		end

	end


end
