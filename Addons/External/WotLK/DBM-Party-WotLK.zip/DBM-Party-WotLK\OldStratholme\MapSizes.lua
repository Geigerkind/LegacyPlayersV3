DBM:RegisterMapSize("CoTStratholme",
	1, 1824.997, 1216.67,					-- Norndir Preperation
	2, 1125.299987791, 750.19995117			-- Stratholme City
)