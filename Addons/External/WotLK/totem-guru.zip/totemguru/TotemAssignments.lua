--  TotemGuru is a world of warcraft addon for showing totems during raiding
--  Copyright (C) 2009 Jon Edmunds (je95(AT)zepler.org.uk)
--  Create Date : 8/16/2009 9:16:05 AM
--  This file is part of the TotemGuru Wow Addon.
--
--  TotemGuru is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
-- 
--  TotemGuru is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
-- 
--  You should have received a copy of the GNU General Public License
--  along with TotemGuru.  If not, see <http://www.gnu.org/licenses/>.

TotemGuruAssignments = {}
local borders = 0
function TotemGuruAssignments_LoadWindow()
	TotemGuruAssignments:AssignmentWindowInit()
	if (GetNumRaidMembers() > 0) then
		SendAddonMessage("TotemGuru","VersionRequest","RAID");
	else
      SendAddonMessage("TotemGuru","VersionRequest","WHISPER",PlayerName:GetText());
   end
end
-------------------------
-- TotemGuruPlayerVersion
-------------------------
function TotemGuruPlayerVersion(playerName,Version)
	if (TotemGuruConfig.ReceiveAssignments) then
		if(Version and playerName) then
			print("received version "..Version.." from "..playerName)
			TotemGuruAssignments:TotemGuru_AddPlayer(playerName,Version)
		else
			print("TotemGuruPlayerVersion received incorrect data")
		end
		TotemGuruAssignments:UpdateHeight()
	end
end
-------------------------
-- AssignmentWindowInit
-------------------------
function TotemGuruAssignments:AssignmentWindowInit()
	if (self.MainFrame and self.MainFrame:GetObjectType()=="Frame") then
		TotemGuruAssignments_Toggle()
		TotemGuruAssignments_Redraw()
	else
		self.MainFrame = CreateFrame("Frame","TotemGuruMainAssignmentWindow",UIParent)
		local MW = self.MainFrame
		MW.Width =	(TotemGuruConstants.BORDER_SIZE*2) +
					TotemGuruConstants.NAME_OFFSET +
					TotemGuruConstants.NAME_SPACE_SIZE +
					TotemGuruConstants.ARROW_SIZE +
					((TotemGuruConstants.TOTEM_ICON_SIZE +
						TotemGuruConstants.TOTEM_ICON_SPACER)*4)
					
		MW.Height = 100		
		MW.bg = 
			{
			bgFile="Interface/DialogFrame/UI-DialogBox-Background",
			edgeFile=nil,
			tile="true",
			insets = {left="1", right="1", top="1", bottom="1"},
			tileSize = 32,
			edgeSize = TotemGuruConstants.BORDER_SIZE
			}
			MW.bg1 = 
			{
			bgFile=nil,
			edgeFile="Interface/BUTTONS/YELLOWORANGE64",
			tile="true",
			insets = {left="1", right="1", top="1", bottom="1"},
			tileSize = 32,
			edgeSize = TotemGuruConstants.BORDER_SIZE
			}
		MW:EnableMouse(true)
		MW:SetClampedToScreen(true)
		MW:SetResizable(1)
		MW:SetMovable(1)
		MW:SetFrameStrata("LOW")
		MW:SetToplevel(true)
		MW:SetWidth(MW.Width)
		MW:SetHeight(MW.Height)
		
		MW:SetScript("OnDragStart", function (...) 
			MW:StartMoving();
			MW.isMoving = true;
			 end)
		MW:SetScript("OnDragStop", function (...) 
			MW:StopMovingOrSizing();
			MW.isMoving = false;
			 end)
		MW:RegisterForDrag("LeftButton");
		if borders then
			MW:SetBackdrop(MW.bg)
		end
		self:CreateButtons()
		self:CreatePlayerNameFrame()	
		self:CreatePlayerTotemsFrame()
		if borders == 1 then
			self.ButtonsFrame:SetBackdrop(MW.bg1)
			self.PlayerNameFrame:SetBackdrop(MW.bg1)
			self.PlayerTotemsFrame:SetBackdrop(MW.bg1)
		end
		MW:SetPoint("CENTER",-200,0)
		TotemGuruAssignments:UpdateHeight()
		TotemGuruAssignments:CreateMenus()
	end
end 
------------------
-- UpdateHeight --
------------------
function TotemGuruAssignments:UpdateHeight()
	local offsetframe = self.ButtonsFrame
	local mainFrmHeight
	local PLAYERS = TotemGuruData.PlayerAssignments
	mainFrmHeight = TotemGuruConstants.HEADER_ROW_HEIGHT + (TotemGuruData.CurrentNoForAssignments * TotemGuruConstants.PLAYER_ROW_HEIGHT)
	self.PlayerNameFrame:SetPoint("TOPLEFT",offsetframe,"BOTTOMLEFT")
	self.PlayerNameFrame:SetPoint("BOTTOMRIGHT",offsetframe,"BOTTOMLEFT",
		TotemGuruConstants.NAME_SPACE_SIZE,
		-(TotemGuruConstants.PLAYER_ROW_HEIGHT
		*	TotemGuruData.CurrentNoForAssignments))
	self.MainFrame:SetHeight(mainFrmHeight)
end
---------------------------
-- CreatePlayerNameFrame --
---------------------------
function TotemGuruAssignments:CreatePlayerNameFrame()
	self.PlayerNameFrame = CreateFrame("Frame",nil,UIParent)
	local PNF = self.PlayerNameFrame
	PNF:SetPoint("TOPLEFT",self.ButtonsFrame,"BOTTOMLEFT")
	PNF:SetPoint("BOTTOMRIGHT",self.ButtonsFrame,"BOTTOMLEFT",
	TotemGuruConstants.NAME_SPACE_SIZE,
	0)
end
----------------------
-- TotemGuru_AddPlayer
----------------------
function TotemGuruAssignments:TotemGuru_AddPlayer(sourceName,Version)
	
	local PLAYERS = TotemGuruData.PlayerAssignments
	local PNF = self.PlayerNameFrame
	if (PLAYERS[sourceName]) then
		PLAYERS[sourceName]["Version"]= Version
	else
		PLAYERS[sourceName] = {["Version"] = Version}
		TotemGuruData.CurrentNoForAssignments = TotemGuruData.CurrentNoForAssignments + 1
		PLAYERS[sourceName].player_id = TotemGuruData.CurrentNoForAssignments
		PLAYERS[sourceName].fontstring = PNF:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		local fontstring = PLAYERS[sourceName].fontstring
		fontstring:SetFont(TotemGuruConstants.FONT_TYPE, TotemGuruConstants.PLAYER_FONT_SIZE)
		fontstring:SetNonSpaceWrap(nil)
		fontstring:SetSpacing(0) 
		fontstring:SetHeight(TotemGuruConstants.PLAYER_FONT_SIZE) 
		if Version then
			fontstring:SetText(sourceName .. "(V"..Version..")")
		else
			fontstring:SetText(sourceName)
		end
		fontstring:SetAlpha(TotemGuruConfig.PlayerNameAlpha)
	
		fontstring:SetPoint("TOPLEFT", PNF, "TOPLEFT", 
		0, 
		-TotemGuruConstants.PLAYER_ROW_HEIGHT*(PLAYERS[sourceName].player_id-1))
		fontstring:SetPoint("TOPRIGHT",  PNF, "TOPRIGHT", 
		0, 
		-TotemGuruConstants.PLAYER_ROW_HEIGHT*(PLAYERS[sourceName].player_id-1))
		fontstring:SetJustifyV("CENTER")
		fontstring:SetJustifyH("LEFT")
		
		--Create totems
		PLAYERS[sourceName]["school"..TotemGuru_air_school]={["icon"]=TotemGuru_Textures.NatureResistance}
		PLAYERS[sourceName]["school"..TotemGuru_water_school]={["icon"]=TotemGuru_Textures.Poison}
		PLAYERS[sourceName]["school"..TotemGuru_earth_school]={["icon"]=TotemGuru_Textures.StoneSkin}
		PLAYERS[sourceName]["school"..TotemGuru_fire_school]={["icon"]=TotemGuru_Textures.Wrath}
		TotemGuru_Create_Totem_icon(self.PlayerTotemsFrame,PLAYERS[sourceName]["school"..TotemGuru_air_school],
			TotemGuru_Textures.NatureResistance,
			"0",
			i,
			MenuDrop, 
			sourceName)
		TotemGuru_Create_Totem_icon(self.PlayerTotemsFrame,PLAYERS[sourceName]["school"..TotemGuru_water_school],
			TotemGuru_Textures.Poison,
			"0",
			i,
			MenuDrop, 
			sourceName)
		TotemGuru_Create_Totem_icon(self.PlayerTotemsFrame,PLAYERS[sourceName]["school"..TotemGuru_earth_school],
			TotemGuru_Textures.StoneSkin,
			"0",
			i,
			MenuDrop, 
			sourceName)
		TotemGuru_Create_Totem_icon(self.PlayerTotemsFrame,PLAYERS[sourceName]["school"..TotemGuru_fire_school],
			TotemGuru_Textures.Wrath,
			"0",
			i,
			MenuDrop, 
			sourceName)
		TotemGuru_UpdatePlayerIcons(PLAYERS[sourceName],self)
	end

end

---------------------------
-- CreatePlayerTotemsFrame --
---------------------------
function TotemGuruAssignments:CreatePlayerTotemsFrame()
	self.PlayerTotemsFrame = CreateFrame("Frame",nil,UIParent)
	local PTF = self.PlayerTotemsFrame
	PTF:SetPoint("TOPLEFT",self.PlayerNameFrame,"TOPRIGHT")
	PTF:SetPoint("BOTTOM",self.PlayerNameFrame,"BOTTOM")
	PTF:SetPoint("RIGHT",self.MainFrame,"RIGHT")
end
-----------------------------
----- CreateButtons ---------
-----------------------------
function TotemGuruAssignments:CreateButtons()
	self.ButtonsFrame = CreateFrame("Frame",nil,UIParent)
	local BF = self.ButtonsFrame
	local Anchor = self.MainFrame
	BF:SetPoint("TOPLEFT",Anchor,"TOPLEFT")
	BF:SetWidth(self.MainFrame.Width)
	BF:SetHeight(TotemGuruConstants.HEADER_SIZE)
	
	self:CreateButton("Close",BF,
		self.MainFrame.Width - (TotemGuruConstants.BORDER_SIZE+TotemGuruConstants.FRAME_ICON_SIZE),
		-TotemGuruConstants.BORDER_SIZE,
		TotemGuruConstants.FRAME_ICON_SIZE,
		"Interface/BUTTONS/UI-Panel-MinimizeButton-Up",
		0.18,0.78,0.2,0.78,
		"Interface/BUTTONS/UI-Panel-MinimizeButton-Down",
		0.18,0.78,0.2,0.78,
		TotemGuruAssignments_Toggle)

	self:CreateButton("Settings",BF,
		TotemGuruConstants.BORDER_SIZE,-TotemGuruConstants.BORDER_SIZE,
		TotemGuruConstants.FRAME_ICON_SIZE,
		"Interface/BUTTONS/UI-MicroButton-Help-Up",
		0,0.98,0.36,0.98,
		"Interface/BUTTONS/UI-MicroButton-Help-Down",
		0,0.98,0.36,0.98,
		TotemGuruMain_btnSettings_OnClick)
		
	self:CreateButton("Send",BF,
		TotemGuruConstants.BORDER_SIZE+TotemGuruConstants.FRAME_ICON_SIZE+TotemGuruConstants.FRAME_ICON_SPACER,
		-TotemGuruConstants.BORDER_SIZE-3,
		TotemGuruConstants.FRAME_ICON_SIZE-5,
		"Interface/BUTTONS/UI-PaidCharacterCustomization-Button",
		0.12,0.38,0.12,0.38,
		"Interface/BUTTONS/UI-PaidCharacterCustomization-Button",
		0.1,0.4,0.1,0.4,
		SendTotemsToPlayers,nil,nil)
end
-----------------------------
----- SendTotemsToPlayers ---
-----------------------------
function SendTotemsToPlayers()
	local message
	for k,v in pairs(TotemGuruData.PlayerAssignments) do
		message = "V"..TotemGuruConfig.MessageProtocolVersion
		for i=1,4 do
			message = message .. "T" .. TotemGuru_Totem_Message_Ids[v["school"..i].icon]
		end
		SendAddonMessage("TotemGuru_TA",message,"WHISPER",PlayerName:GetText());
	end
end


------------------------------
-- ReceivedTotemAssignments --
------------------------------
function ReceivedTotemAssignments(player,msg)
   TotemGuru_air_school=1
   TotemGuru_water_school=2
   TotemGuru_earth_school=3
   TotemGuru_fire_school=4

   local Ancestors = {140, 139, 138,137}
   --local Ancestors = {138, 137, 139,140}
   
   local Elements = {136, 135, 134,133}
   local Spirits = {144, 143, 142, 141}
	local spellID
   local totemNumber = 1
	local version = 0
	TotemGuruData.AssignedTotems = {}
	print("received totem assignments " .. msg)
    --for w in string.gmatch(msg, "%a%d+") do
	for w in string.gmatch(msg, "%a%d+") do
		if (string.find(w,"V")==1) then
			version = string.sub(w,2)
		end
		if (version == tostring(TotemGuruConfig.MessageProtocolVersion)) then
			if (not TotemGuruWindows["SBC"..totemNumber.."Button"]) then
				TotemGuruWindows:SingleButtonCast_init()
			end
			if (string.find(w,"T")==1) then
				local texture = TotemGuru_Totem_Message_Ids[tonumber(string.sub(w,2))]
				TotemGuruWindows["SBC"..totemNumber.."Button"]:SetAttribute("type", "spell");
				TotemGuruWindows["SBC"..totemNumber.."Button"]:SetAttribute("spell", TotemGuruTotemsInfo[texture].name);
				TotemGuruWindows["SBC"..totemNumber.."Button"]:SetNormalTexture(texture)
				totemNumber = totemNumber +1
          	if TotemGuruConfig.Multicast.Ancestors then
          		print("multicast set to Ancestors")
          		MButton = Ancestors[TotemGuruTotemsInfo[texture].school]
          	elseif TotemGuruConfig.Multicast.Elements then
          		print("multicast set to Elements")
          		MButton = Elements[TotemGuruTotemsInfo[texture].school]
          	elseif TotemGuruConfig.Multicast.Spirits then
          		print("multicast set to Spirits")
          		MButton = Spirits[TotemGuruTotemsInfo[texture].school]
         	end
         	print("MButton= ")
            print(MButton)
            print(TotemGuruTotemsInfo[texture].name)
            spellID = (GetSpellLink(TotemGuruTotemsInfo[texture].name) or ""):match("Hspell:(%d+)")
            spellID = spellID and tonumber(spellID)
            print(spellID)
            SetMultiCastSpell(MButton, spellID)
			end
		else
			print ("version didn't match")
		end
	end
end

------------------
-- CreateButton --
------------------
function TotemGuruAssignments:CreateButton(name,parent,x,y,width,
		NormalTexture, NT_left, NT_right, NT_top, NT_bottom,
		HighlightedTexture, HT_left, HT_right, HT_top, HT_bottom,
		ClickFunction,
		OnEnterFunction,
		OnLeaveFunction)
	self[name.."Button"] = CreateFrame("Button", nil, parent,UIPanelButtonTemplate)
	local button = self[name.."Button"]
	if ClickFunction then
		button:SetScript("OnClick", function (self) ClickFunction() end)
	end
	if OnEnterFunction then
		button:SetScript("OnEnter", function (self) OnEnterFunction() end)
	end
	if OnLeaveFunction then
		button:SetScript("OnLeave", function (self) OnLeaveFunction() end)
	end
	
	button:SetNormalTexture(NormalTexture)
	button:SetHighlightTexture(HighlightedTexture)
	button:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
	
	button:GetNormalTexture():SetTexCoord(NT_left, NT_right, NT_top, NT_bottom)  
	button:GetHighlightTexture():SetTexCoord(HT_left, HT_right, HT_top, HT_bottom)
	button:GetHighlightTexture():SetBlendMode("DISABLE")
	button:SetHeight(width)
	button:SetWidth(width)
end


------------
-- TotemGuruAssignments_Toggle()
-------------------------
function TotemGuruAssignments_Toggle()
	if(TotemGuruAssignments.MainFrame:IsShown()) then
		TotemGuruAssignments.MainFrame:Hide()
		TotemGuruAssignments.ButtonsFrame:Hide()
		TotemGuruAssignments.PlayerNameFrame:Hide()
		TotemGuruAssignments.PlayerTotemsFrame:Hide()
	else
		TotemGuruAssignments.MainFrame:Show()
		TotemGuruAssignments.ButtonsFrame:Show()
		TotemGuruAssignments.PlayerNameFrame:Show()
		TotemGuruAssignments.PlayerTotemsFrame:Show()
	end
	TotemGuruAssignments_Redraw()
end

-------------------------------------
-- TotemGuruAssignments_Redraw
-------------------------------------
function TotemGuruAssignments_Redraw()
	if (TotemGuruData.PlayerAssignments) then
		for k,v in pairs(TotemGuruData.PlayerAssignments) do
			TotemGuru_UpdatePlayerIcons(TotemGuruData.PlayerAssignments[k],TotemGuruAssignments)
		end
	end
end

---------------------------------------
-- TotemGuruSettingsGUI:CreateMenus --
---------------------------------------
function TotemGuruAssignments:CreateMenus()	
	TotemGuruAssignments["menu1"] = {}
	TotemGuruAssignments["menu2"] = {}
	TotemGuruAssignments["menu3"] = {}
	TotemGuruAssignments["menu4"] = {}
	for k,v in pairs(TotemGuruTotemsInfo) do
		table.insert(TotemGuruAssignments["menu"..v.school],{text = v.name, func = function (...) totemAssignmentChanged(v.school,k) end})
	end
end

function totemAssignmentChanged(school,totem)
	TotemGuru_TotemDied(TotemGuruData.PlayerAssignments[TotemGuruAssignments.ClickedPlayer]["school"..school])
	TotemGuru_Create_Totem_icon(TotemGuruAssignments.PlayerTotemsFrame,TotemGuruData.PlayerAssignments[TotemGuruAssignments.ClickedPlayer]["school"..school],
			totem,
			"0",
			school,
			MenuDrop, 
			TotemGuruAssignments.ClickedPlayer)
	TotemGuruData.PlayerAssignments[TotemGuruAssignments.ClickedPlayer]["school"..school].button.icon:SetTexture(totem)
	TotemGuruData.PlayerAssignments[TotemGuruAssignments.ClickedPlayer]["school"..school].icon = totem
end
---------------------------------------
-- TotemGuruSettingsGUI:MenuDrop --
---------------------------------------
function MenuDrop(source,icon)	
	TotemGuruAssignments.ClickedPlayer = source
	local menu_frame = CreateFrame("Frame", "ExampleMenuFrame", UIParent, "UIDropDownMenuTemplate")
	EasyMenu(TotemGuruAssignments["menu"..TotemGuruTotemsInfo[icon].school], menu_frame, "cursor", 0 , 0, "MENU")
end
