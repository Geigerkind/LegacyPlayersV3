--  TotemGuru is a world of warcraft addon for showing totems during raiding
--  Copyright (C) 2009 Jon Edmunds (je95(AT)zepler.org.uk)
--  Create Date : 8/16/2009 9:16:05 AM
--  This file is part of the TotemGuru Wow Addon.
--
--  TotemGuru is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
-- 
--  TotemGuru is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
-- 
--  You should have received a copy of the GNU General Public License
--  along with TotemGuru.  If not, see <http://www.gnu.org/licenses/>.


ButtonStash = 
{
	GlobalButtonCount = 0
};

--------------------
-- ButtonStash:new()
--------------------
function ButtonStash:new ()
	local newstash = {};
	setmetatable(newstash,self);
	self.__index = self;
	self.defaultButtons = {}
	return newstash;
end
--------------------------
-- ButtonStash:GetButton()
--------------------------
function ButtonStash:GetButton()
	if getn(self.defaultButtons) > 0 then
		local tempButton = table.remove(self.defaultButtons)
		tempButton:Hide()
		tempButton:SetParent(UIParent)
		return tempButton
	else
		local tempbutton = CreateFrame("Button", nil, UIParent)
		tempbutton.icon = tempbutton:CreateTexture(nil, "ARTWORK")
		tempbutton:Hide()
		tempbutton.icon:SetTexCoord(0.025, 0.975, 0.025, 0.975)
		tempbutton.icon:SetPoint("TOPLEFT", tempbutton, "TOPLEFT", 0,0)
		tempbutton.icon:SetPoint("BOTTOMRIGHT", tempbutton, "BOTTOMRIGHT", 0,0)

		tempbutton.cooldown = CreateFrame("Cooldown", nil, tempbutton, "CooldownFrameTemplate") 
		tempbutton.cooldown:SetPoint("TOPLEFT", tempbutton, "TOPLEFT", 0,0) 
		tempbutton.cooldown:SetPoint("BOTTOMRIGHT", tempbutton, "BOTTOMRIGHT", 0,0) 
		tempbutton.cooldown:SetReverse(1)
		
		tempbutton.buffIcon = tempbutton:CreateTexture("ButtonStashTexture" .. ButtonStash.GlobalButtonCount , "OVERLAY")
		tempbutton.buffIcon:SetParent(tempbutton)
		tempbutton.buffIcon:SetTexCoord(0,1,0,1)
		tempbutton.buffIcon:SetPoint("TOPLEFT", tempbutton, "TOPLEFT", 0,0)
		tempbutton.buffIcon:SetPoint("BOTTOMRIGHT", tempbutton, "BOTTOMRIGHT", 0,0)
		tempbutton.buffIcon:SetTexture("Interface\\BUTTONS\\GLOWSTAR.BLP")
		tempbutton.buffIcon:SetBlendMode("ADD")
		tempbutton.buffIcon:SetAlpha(0)	
		tempbutton.buffIcon.startFlashing = function () FlashBuffIcon(tempbutton.buffIcon,1);end
		tempbutton.buffIcon.stopFlashing = function () StopFlashBuffIcon(tempbutton.buffIcon);end
		ButtonStash.GlobalButtonCount = ButtonStash.GlobalButtonCount +1
		return (tempbutton)
	end
end		
------------------------------
-- ButtonStash:ReleaseButton()
------------------------------
function ButtonStash:ReleaseButton(button)
	for _,v in pairs(self.defaultButtons) do
		if button == v then
			return nil
		end
	end
	if button and (button:GetObjectType()=="Button") then
		button:Hide()
		table.insert(self.defaultButtons, button)
	end
	return nil;
end
----------------------------------
-------- SetUpAnimGroup ----------
----------------------------------
SetUpAnimGroup = function (self)
	self.anim = self:CreateAnimationGroup("Flash")
	self.anim.fadein = self.anim:CreateAnimation("ALPHA", "FadeIn")
	self.anim.fadein:SetChange(1)
	self.anim.fadein:SetOrder(1)
	self.anim.fadeout = self.anim:CreateAnimation("ALPHA", "FadeOut")
	self.anim.fadeout:SetChange(-1)
	self.anim.fadeout:SetOrder(2)
	self.anim:SetLooping("REPEAT")
end
---------------------------
------ FlashBuffIcon ------
---------------------------
FlashBuffIcon = function(self, duration)
	
	if not self.anim then
		SetUpAnimGroup(self)
	end
	
	if not self.anim:IsPlaying() then
		self.anim.fadein:SetDuration(duration)
		self.anim.fadeout:SetDuration(duration)
		self.anim:Play()
	end
end
---------------------------
---- StopFlashBuffIcon ----
---------------------------
StopFlashBuffIcon = function(self)

	if self.anim and self.anim:IsPlaying()then
		self.anim:Stop()
		self:SetAlpha(0)
	end
end
