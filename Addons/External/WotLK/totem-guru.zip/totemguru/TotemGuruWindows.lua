--  TotemGuru is a world of warcraft addon for showing totems during raiding
--  Copyright (C) 2009 Jon Edmunds (je95(AT)zepler.org.uk)
--  Create Date : 8/16/2009 9:16:05 AM
--  This file is part of the TotemGuru Wow Addon.
--
--  TotemGuru is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
-- 
--  TotemGuru is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
-- 
--  You should have received a copy of the GNU General Public License
--  along with TotemGuru.  If not, see <http://www.gnu.org/licenses/>.

TotemGuruWindows = {}
borders = 0
function TotemGuruWindows:init()
	self.MainFrame = CreateFrame("Frame","TotemGuruMainWindow",UIParent)
	local MW = self.MainFrame
	MW.Width =	(TotemGuruConstants.BORDER_SIZE*2) +
				TotemGuruConstants.NAME_OFFSET +
				TotemGuruConstants.NAME_SPACE_SIZE +
				TotemGuruConstants.ARROW_SIZE +
				((TotemGuruConstants.TOTEM_ICON_SIZE +
					TotemGuruConstants.TOTEM_ICON_SPACER)*4)

			
	MW.Height = 100		
	MW.bg = 
		{
		bgFile="Interface/DialogFrame/UI-DialogBox-Background",
		edgeFile=nil,
		tile="true",
		insets = {left="1", right="1", top="1", bottom="1"},
		tileSize = 32,
		edgeSize = TotemGuruConstants.BORDER_SIZE
		}
		MW.bg1 = 
		{
		bgFile=nil,
		edgeFile="Interface/BUTTONS/YELLOWORANGE64",
		tile="true",
		insets = {left="1", right="1", top="1", bottom="1"},
		tileSize = 32,
		edgeSize = TotemGuruConstants.BORDER_SIZE
		}
	MW:EnableMouse(true)
	MW:SetClampedToScreen(true)
	MW:SetResizable(1)
	MW:SetMovable(1)
	MW:SetFrameStrata("LOW")
	MW:SetToplevel(true)
	MW:SetWidth(MW.Width)
	MW:SetHeight(MW.Height)
	
	MW:SetScript("OnDragStart", function (...) 
		if (AreWindowsLocked()) then
			if (IsAltKeyDown()) then 
    			MW:StartMoving();
				MW.isMoving = true;
			end
		else
   			MW:StartMoving();
			MW.isMoving = true;
		end
		end)
	MW:SetScript("OnDragStop", function (...) 
		MW:StopMovingOrSizing();
		MW.isMoving = false;
		TotemGuruResetAnimations();
		 end)
	MW:SetScript("OnEvent", function (...) 
		TotemGuruMain_OnEvent(...)
		 end)
	 

	MW:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	MW:RegisterEvent("VARIABLES_LOADED");
	MW:RegisterEvent("CHAT_MSG_ADDON");
	MW:RegisterEvent("PLAYER_TOTEM_UPDATE"); 
	MW:RegisterEvent("PLAYER_LOGOUT"); 
	MW:RegisterEvent("UNIT_AURA"); 
	MW:RegisterEvent("PLAYER_UNGHOST"); 
	MW:RegisterEvent("PLAYER_ENTERING_WORLD"); 
	MW:RegisterForDrag("LeftButton");

	if borders then
		MW:SetBackdrop(MW.bg)
	end
	
	self:CreateButtons()
	self:CreateWarningsIcons()
	self:CreatePlayerNameFrame()	
	self:CreatePlayerTotemsFrame()
	if borders == 1 then
		self.ButtonsFrame:SetBackdrop(MW.bg1)
		self.WarningsFrame:SetBackdrop(MW.bg1)
		self.PlayerNameFrame:SetBackdrop(MW.bg1)
		self.PlayerTotemsFrame:SetBackdrop(MW.bg1)
	end
	MW:SetPoint("CENTER",-200,0)
	TotemGuruMain_OnLoad(MW)
end

------------------
-- UpdateHeight --
------------------
function AreWindowsLocked()
	if (TotemGuruData.VariablesLoaded and TotemGuruConfig.LockWindow==1) then
		return true
	else
		return false
	end
end
------------------
-- UpdateHeight --
------------------
function TotemGuruWindows:UpdateHeight()
	local offsetframe = self.ButtonsFrame
	local mainFrmHeight
	if TotemGuruConfig.ShowWarnings then
		offsetframe = self.WarningsFrame
		TotemGuruWindows.WarningsFrame:Show()
		mainFrmHeight = TotemGuruConstants.HEADER_ROW_HEIGHT + TotemGuruConstants.WARNING_ROW_HEIGHT + (TotemGuruData.CurrentNoOfPlayers * TotemGuruConstants.PLAYER_ROW_HEIGHT)
	else
		mainFrmHeight = TotemGuruConstants.HEADER_ROW_HEIGHT + (TotemGuruData.CurrentNoOfPlayers * TotemGuruConstants.PLAYER_ROW_HEIGHT)
		TotemGuruWindows.WarningsFrame:Hide()
	end
	self.PlayerNameFrame:SetPoint("TOPLEFT",offsetframe,"BOTTOMLEFT")
	self.PlayerNameFrame:SetPoint("BOTTOMRIGHT",offsetframe,"BOTTOMLEFT",
		TotemGuruConstants.NAME_SPACE_SIZE
			+TotemGuruConstants.BORDER_SIZE
			+TotemGuruConstants.ARROW_SIZE
			+TotemGuruConstants.NAME_OFFSET,
		-(TotemGuruConstants.PLAYER_ROW_HEIGHT
			*TotemGuruData.CurrentNoOfPlayers))
	self.MainFrame:SetHeight(mainFrmHeight)
end
---------------------------
-- CreatePlayerNameFrame --
---------------------------
function TotemGuruWindows:CreatePlayerNameFrame()
	self.PlayerNameFrame = CreateFrame("Frame",nil,UIParent)
	local PNF = self.PlayerNameFrame
	if TotemGuruConfig.ShowWarnings then
		PNF:SetPoint("TOPLEFT",self.WarningsFrame,"BOTTOMLEFT")
		PNF:SetPoint("BOTTOMRIGHT",self.WarningsFrame,"BOTTOMLEFT",
		TotemGuruConstants.NAME_SPACE_SIZE,
		0)
	else
		PNF:SetPoint("TOPLEFT",self.ButtonsFrame,"BOTTOMLEFT")
		PNF:SetPoint("BOTTOMRIGHT",self.ButtonsFrame,"BOTTOMLEFT",
		TotemGuruConstants.NAME_SPACE_SIZE,
		0)
	end

end
---------------------------
-- CreatePlayerTotemsFrame --
---------------------------
function TotemGuruWindows:CreatePlayerTotemsFrame()
	self.PlayerTotemsFrame = CreateFrame("Frame",nil,UIParent)
	local PTF = self.PlayerTotemsFrame
	PTF:SetPoint("TOPLEFT",self.PlayerNameFrame,"TOPRIGHT")
	PTF:SetPoint("BOTTOM",self.PlayerNameFrame,"BOTTOM")
	PTF:SetPoint("RIGHT",self.MainFrame,"RIGHT")
end
-----------------------------
----- CreateButtons ---------
-----------------------------
function TotemGuruWindows:CreateButtons()
	self.ButtonsFrame = CreateFrame("Frame",nil,UIParent)
	local BF = self.ButtonsFrame
	local Anchor = self.MainFrame
	BF:SetPoint("TOPLEFT",Anchor,"TOPLEFT")
	BF:SetPoint("TOPRIGHT",Anchor,"TOPRIGHT")
	--BF:SetWidth(self.MainFrame.Width)
	BF:SetHeight(TotemGuruConstants.HEADER_SIZE)
	
	self:CreateButton("Close",BF,
		self.MainFrame.Width - (TotemGuruConstants.BORDER_SIZE+TotemGuruConstants.FRAME_ICON_SIZE),
		-TotemGuruConstants.BORDER_SIZE,
		TotemGuruConstants.FRAME_ICON_SIZE,
		"Interface/BUTTONS/UI-Panel-MinimizeButton-Up",
		0.18,0.78,0.2,0.78,
		"Interface/BUTTONS/UI-Panel-MinimizeButton-Down",
		0.18,0.78,0.2,0.78,
		TotemGuruMain_btnClose_OnClick)

	self:CreateButton("Settings",BF,
		TotemGuruConstants.BORDER_SIZE,-TotemGuruConstants.BORDER_SIZE,
		TotemGuruConstants.FRAME_ICON_SIZE,
		"Interface/BUTTONS/UI-MicroButton-Help-Up",
		0,0.98,0.36,0.98,
		"Interface/BUTTONS/UI-MicroButton-Help-Down",
		0,0.98,0.36,0.98,
		TotemGuruMain_btnSettings_OnClick)
		
	self:CreateButton("Refresh",BF,
		TotemGuruConstants.BORDER_SIZE+TotemGuruConstants.FRAME_ICON_SIZE+TotemGuruConstants.FRAME_ICON_SPACER,
		-TotemGuruConstants.BORDER_SIZE,
		TotemGuruConstants.FRAME_ICON_SIZE,
		"Interface/BUTTONS/UI-RotationRight-Button-Up",
		0.1,0.88,0.1,0.83,
		"Interface/BUTTONS/UI-RotationRight-Button-Down",
		0.1,0.88,0.1,0.85,
		TotemGuruMain_btnRefresh_OnClick,nil,nil)
end
-------------------------
-- CreateWarningsIcons --
-------------------------
function TotemGuruWindows:CreateWarningsIcons()
	
	self.WarningsFrame = CreateFrame("Frame",nil,UIParent)
	local Anchor = self.ButtonsFrame
	local WF = self.WarningsFrame
	WF:SetPoint("TOPLEFT",Anchor,"BOTTOMLEFT",
		0,
		0)
	WF:SetPoint("BOTTOMRIGHT",Anchor,"BOTTOMRIGHT",
		0,
		-((TotemGuruConstants.BORDER_SIZE*2)
			+TotemGuruConstants.WARNING_ICON_SIZE)
		)
	
	self:CreateButton("WarningIcon1",WF,
		TotemGuruConstants.WARNING_ICON_OFFSET1,-TotemGuruConstants.BORDER_SIZE,
		TotemGuruConstants.WARNING_ICON_SIZE,
		"Interface/CHARACTERFRAME/UI-Player-PlayTimeUnhealthy",
		0.22, 0.75, 0.2, 0.74,
		"Interface/CHARACTERFRAME/UI-Player-PlayTimeUnhealthy",
		0.22, 0.75, 0.2, 0.74,
		nil,
		function (...) TotemGuru_showTooltip(TotemGuruWindows.WarningIcon1Button,1,nil) end,
		function (...) TotemGuru_hideTooltip() end
		)

	self:CreateButton("WarningIcon2",WF,
		TotemGuruConstants.WARNING_ICON_OFFSET2,-TotemGuruConstants.BORDER_SIZE,
		TotemGuruConstants.WARNING_ICON_SIZE,
		"Interface/CHARACTERFRAME/UI-Player-PlayTimeUnhealthy",
		0.22, 0.75, 0.2, 0.74,
		"Interface/CHARACTERFRAME/UI-Player-PlayTimeUnhealthy",
		0.22, 0.75, 0.2, 0.74,
		nil,
		function (...) TotemGuru_showTooltip(TotemGuruWindows.WarningIcon2Button,2,nil) end,
		function (...) TotemGuru_hideTooltip() end
		)

	self:CreateButton("WarningIcon3",WF,
		TotemGuruConstants.WARNING_ICON_OFFSET3,-TotemGuruConstants.BORDER_SIZE,
		TotemGuruConstants.WARNING_ICON_SIZE,
		"Interface/CHARACTERFRAME/UI-Player-PlayTimeUnhealthy",
		0.22, 0.75, 0.2, 0.74,
		"Interface/CHARACTERFRAME/UI-Player-PlayTimeUnhealthy",
		0.22, 0.75, 0.2, 0.74,
		nil,
		function (...) TotemGuru_showTooltip(TotemGuruWindows.WarningIcon31Button,3,nil) end,
		function (...) TotemGuru_hideTooltip() end
		)


	self:CreateButton("WarningIcon4",WF,
		TotemGuruConstants.WARNING_ICON_OFFSET4,-TotemGuruConstants.BORDER_SIZE,
		TotemGuruConstants.WARNING_ICON_SIZE,
		"Interface/CHARACTERFRAME/UI-Player-PlayTimeUnhealthy",
		0.22, 0.75, 0.2, 0.74,
		"Interface/CHARACTERFRAME/UI-Player-PlayTimeUnhealthy",
		0.22, 0.75, 0.2, 0.74,
		nil,
		function (...) TotemGuru_showTooltip(TotemGuruWindows.WarningIcon4Button,4,nil) end,
		function (...) TotemGuru_hideTooltip() end
		)
end

-----------------------------------------------------------
----------- TotemGuruwindows_SingleButtonCast -------------
-----------------------------------------------------------
function TotemGuruwindows_SingleButtonCast()
	if TotemGuruWindows.SingleButtonCastFrame then
		if(TotemGuruWindows.SingleButtonCastFrame:IsShown()) then 
			TotemGuruWindows.SingleButtonCastFrame:Hide()
		else
			TotemGuruWindows.SingleButtonCastFrame:Show()
		end
	else
		TotemGuruWindows:SingleButtonCast_init()
	end

end
-----------------------------------------------------------
----------- TotemGuruwindows:SingleButtonCast_init --------
-----------------------------------------------------------
function TotemGuruWindows:SingleButtonCast_init()
	self.SingleButtonCastFrame = CreateFrame("Frame","SingleButtonCastFrame",UIParent)
	local SBC = self.SingleButtonCastFrame
	SBC.Width =	TotemGuruConstants.TOTEM_BUTTON_SIZE
	SBC.Height = TotemGuruConstants.TOTEM_BUTTON_SIZE
	SBC.bg = 
		{
		bgFile="Interface/DialogFrame/UI-DialogBox-Background",
		edgeFile=nil,
		tile="true",
		insets = {left="1", right="1", top="1", bottom="1"},
		tileSize = 32,
		edgeSize = TotemGuruConstants.BORDER_SIZE
		}
	SBC.bg1 = 
		{
		bgFile=nil,
		edgeFile="Interface/BUTTONS/YELLOWORANGE64",
		tile="true",
		insets = {left="1", right="1", top="1", bottom="1"},
		tileSize = 32,
		edgeSize = TotemGuruConstants.BORDER_SIZE
		}
	SBC:EnableMouse(true)
	SBC:SetClampedToScreen(true)
	SBC:SetResizable(1)
	SBC:SetMovable(1)
	SBC:SetFrameStrata("LOW")
	SBC:SetToplevel(true)
	SBC:SetWidth(SBC.Width)
	SBC:SetHeight(SBC.Height*4)
	SBC:SetBackdrop(SBC.bg)
	SBC:SetScript("OnDragStart", function (...) 
			if (AreWindowsLocked()) then
				if (IsAltKeyDown()) then 
    				SBC:StartMoving();
					SBC.isMoving = true;
				end
			else
   				SBC:StartMoving();
				SBC.isMoving = true;
			end
		 end)
	SBC:SetScript("OnDragStop", function (...) 
		SBC:StopMovingOrSizing();
		SBC.isMoving = false;
		 end)
	SBC:SetScript("OnEvent", function (...) 
		TotemGuruMain_OnEvent(...)
		 end)
	 
	SBC:RegisterForDrag("LeftButton");

	SBC:SetPoint("CENTER",0,0)
	SBC:Show()

	TotemGuruWindows:CreateSingleCastButtons("SBC1",SBC,
		0,-10,
		TotemGuruConstants.TOTEM_BUTTON_SIZE,
		"Interface/ICONS/Achievement_Dungeon_TheVioletHold.blp",
		0,1,0,1,
		"Interface/ICONS/Achievement_Dungeon_TheVioletHold_Heroic.blp",
		0,1,0,1,
		function (...) TotemGuruWindows:DropTotemsClicked(1) end,
		function (...) ShowToolTip(1) end,
		function (...) TotemGuru_hideTooltip() end
		)
	TotemGuruWindows:CreateSingleCastButtons("SBC2",SBC,
		0,-(TotemGuruConstants.TOTEM_BUTTON_SIZE+10),
		TotemGuruConstants.TOTEM_BUTTON_SIZE,
		"Interface/ICONS/Achievement_Dungeon_TheVioletHold.blp",
		0,1,0,1,
		"Interface/ICONS/Achievement_Dungeon_TheVioletHold_Heroic.blp",
		0,1,0,1,
		function (...) TotemGuruWindows:DropTotemsClicked(2) end,
		function (...) ShowToolTip(2) end,
		function (...) TotemGuru_hideTooltip() end
		)
	TotemGuruWindows:CreateSingleCastButtons("SBC3",SBC,
		0,-((TotemGuruConstants.TOTEM_BUTTON_SIZE*2)+10),
		TotemGuruConstants.TOTEM_BUTTON_SIZE,
		"Interface/ICONS/Achievement_Dungeon_TheVioletHold.blp",
		0,1,0,1,
		"Interface/ICONS/Achievement_Dungeon_TheVioletHold_Heroic.blp",
		0,1,0,1,
		function (...) TotemGuruWindows:DropTotemsClicked(3) end,
		function (...) ShowToolTip(3) end,
		function (...) TotemGuru_hideTooltip() end
		)
	TotemGuruWindows:CreateSingleCastButtons("SBC4",SBC,
		0,-((TotemGuruConstants.TOTEM_BUTTON_SIZE*3)+10),
		TotemGuruConstants.TOTEM_BUTTON_SIZE,
		"Interface/ICONS/Achievement_Dungeon_TheVioletHold.blp",
		0,1,0,1,
		"Interface/ICONS/Achievement_Dungeon_TheVioletHold_Heroic.blp",
		0,1,0,1,
		function (...) TotemGuruWindows:DropTotemsClicked(4) end,
		function (...) ShowToolTip(4) end,
		function (...) TotemGuru_hideTooltip() end
		)

end
---------------------------
--      ShowToolTip      --
---------------------------
function ShowToolTip(school)
   
   if(TotemGuruData.PlayerAssignments[PlayerName:GetText()]) then
      local assignments = TotemGuruData.PlayerAssignments[PlayerName:GetText()]["school"..school]
      if( assignments ) then
         TotemGuru_showTooltip(assignments.button,assignments.icon,0)
      end
   end 
end
---------------------------
-- CreateSingleCastButtons --
---------------------------
function TotemGuruWindows:CreateSingleCastButtons(name,parent,x,y,width,
		NormalTexture, NT_left, NT_right, NT_top, NT_bottom,
		HighlightedTexture, HT_left, HT_right, HT_top, HT_bottom,
		ClickFunction,
		OnEnterFunction,
		OnLeaveFunction)
	
	self[name.."Button"] = CreateFrame("Button", nil, parent,"SecureActionButtonTemplate")
	local button = self[name.."Button"]
	button:SetAttribute("type", "spell");
	button:SetAttribute("spell", "Magma Totem");

	if OnEnterFunction then
		button:SetScript("OnEnter", function (self) OnEnterFunction() end)
	end
	if OnLeaveFunction then
		button:SetScript("OnLeave", function (self) OnLeaveFunction() end)
	end
	button:SetNormalTexture(NormalTexture)
	--button:SetHighlightTexture(HighlightedTexture)
	button:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
	button:GetNormalTexture():SetTexCoord(NT_left, NT_right, NT_top, NT_bottom)  
	--button:GetHighlightTexture():SetTexCoord(HT_left, HT_right, HT_top, HT_bottom)
	--button:GetHighlightTexture():SetBlendMode("DISABLE")
	button:SetHeight(width)
	button:SetWidth(width)
end
------------------
-- CreateButton --
------------------
function TotemGuruWindows:CreateButton(name,parent,x,y,width,
		NormalTexture, NT_left, NT_right, NT_top, NT_bottom,
		HighlightedTexture, HT_left, HT_right, HT_top, HT_bottom,
		ClickFunction,
		OnEnterFunction,
		OnLeaveFunction)
	self[name.."Button"] = CreateFrame("Button", nil, parent,UIPanelButtonTemplate)
	local button = self[name.."Button"]
	if ClickFunction then
		button:SetScript("OnClick", function (self) ClickFunction() end)
	end
	if OnEnterFunction then
		button:SetScript("OnEnter", function (self) OnEnterFunction() end)
	end
	if OnLeaveFunction then
		button:SetScript("OnLeave", function (self) OnLeaveFunction() end)
	end
	
	button:SetNormalTexture(NormalTexture)
	button:SetHighlightTexture(HighlightedTexture)
	button:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
	
	button:GetNormalTexture():SetTexCoord(NT_left, NT_right, NT_top, NT_bottom)  
	button:GetHighlightTexture():SetTexCoord(HT_left, HT_right, HT_top, HT_bottom)
	button:GetHighlightTexture():SetBlendMode("DISABLE")
	button:SetHeight(width)
	button:SetWidth(width)
end


---------------------------------
-- TotemGuruUpdateScale
---------------------------------
function TotemGuruUpdateScale()
	TotemGuruWindows.MainFrame:SetScale(TotemGuruConfig.TotemGuruScale)
	TotemGuruWindows.ButtonsFrame:SetScale(TotemGuruConfig.TotemGuruScale)
	TotemGuruWindows.WarningsFrame:SetScale(TotemGuruConfig.TotemGuruScale)
	TotemGuruWindows.PlayerNameFrame:SetScale(TotemGuruConfig.TotemGuruScale)
	TotemGuruWindows.PlayerTotemsFrame:SetScale(TotemGuruConfig.TotemGuruScale)
	TotemGuruResetAnimations()
end
--------------------------
-- TotemGuru_CheckWarningsToggle
--------------------------
function TotemGuru_CheckWarningsToggle()
	if TotemGuruConfig.ShowWarnings then
		TotemGuruWindows.PlayerNameFrame:SetPoint("TOPLEFT",TotemGuruWindows.WarningsFrame,"BOTTOMLEFT")
		TotemGuruWindows.PlayerNameFrame:SetPoint("BOTTOMRIGHT",TotemGuruWindows.WarningsFrame,"BOTTOMLEFT",
			TotemGuruConstants.NAME_SPACE_SIZE,
			-(TotemGuruConstants.PLAYER_ROW_HEIGHT*TotemGuruData.CurrentNoOfPlayers))
		TotemGuru_CheckAllWarnings()
	else
		TotemGuruWindows.PlayerNameFrame:SetPoint("TOPLEFT",TotemGuruWindows.ButtonsFrame,"BOTTOMLEFT")
		TotemGuruWindows.PlayerNameFrame:SetPoint("BOTTOMRIGHT",TotemGuruWindows.ButtonsFrame,"BOTTOMLEFT",
		TotemGuruConstants.NAME_SPACE_SIZE,
		-(TotemGuruConstants.PLAYER_ROW_HEIGHT*TotemGuruData.CurrentNoOfPlayers))
	end
	TotemGuruWindows:UpdateHeight()	
	-- Real hack here to get round the non moving animation issue.
	-- doesn't work to call the function from here as we need to 
	-- finish this thread for some reason
	TotemGuruMain_Redraw()
	SendAddonMessage("TotemGuru","ToggleAnims","WHISPER",PlayerName:GetText());
end
