--  TotemGuru is a world of warcraft addon for showing totems during raiding
--  Copyright (C) 2009 Jon Edmunds (je95(AT)zepler.org.uk)
--  Create Date : 8/16/2009 9:16:05 AM
--  This file is part of the TotemGuru Wow Addon.
--
--  TotemGuru is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
-- 
--  TotemGuru is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
-- 
--  You should have received a copy of the GNU General Public License
--  along with TotemGuru.  If not, see <http://www.gnu.org/licenses/>.

--------------------------------------------------
------------- data structures --------------------
--------------------------------------------------
local TotemGuruConfigDefaults = {
	["Version"] = 0,
	["MessageProtocolVersion"] = 1,
	["MainFrame"] = {["x"] = 0,["y"] = 0,},
	["TotemGuruScale"] = 1,
	["TotemGuruAssignment"] = 1,
	["BackgroundAlpha"] = 1,
	["ButtonsAlpha"] = 1,
	["PlayerNameAlpha"] = 1,
	["TotemNormalAlpha"] = 1,
	["LockWindow"] = 0,
	["TotemUnbuffedAlpha"] = 0.5,
	["WarningsAlpha"] = 1,
	["TooltipsEnabled"] = true,
	["ShowCooldowns"] = true,
	["ShowWarnings"] = false,
	["ShowBuffFlash"] = true,
	["NoEnemyPlayers"] = true,
	["Monitor"] = {["Raid"] = false,["Party"] = false,["All"] = true,},
	["Multicast"] = {["Spirits"] = false,["Elements"] = false,["Ancestors"] = true,},
	["Totems"] = {[1] = {},[2] = {},[3] = {},[4] = {},},
	["MonitoredTotems"] = {},
	["RangeCheckInterval"] = 1.0; 
	["InstanceSettingHide"] = true,
	["Loadnone"] = true,
	["Loadpvp"] = false,
	["Loadarena"] = false,
	["Loadparty"] = false,
	["Loadraid"] = false,
	["ReceiveAssignments"] = false,
	};
TotemGuruConfig = {};
local counter= {[1] = 0, [2] = 0,[3] = 0,[4] = 0}
for k,v in pairs(TotemGuruTotemsInfo) do
	TotemGuruConfigDefaults["Totems"][v.school][tostring(counter[v.school])] = k;
	counter[v.school] = counter[v.school]+1
end
TotemGuruData = {
	["Players"] = {},
	["CurrentNoOfPlayers"] = 0,
	["TotemGuru_admin"] = false,
	["PlayerAssignments"] = {},
	["CurrentNoForAssignments"] = 0,
	["CurrentTotemWarnings"] = {
		[1] = {PlayerLevelWarning = 100,List={}},
		[2] = {PlayerLevelWarning = 100,List={}},
		[3] = {PlayerLevelWarning = 100,List={}},
		[4] = {PlayerLevelWarning = 100,List={}},
		},
	["VariablesLoaded"] = nil,
	};
TotemGuruConstants = {}
TotemGuruConstants["FRAME_ICON_SIZE"] = 20
TotemGuruConstants["FRAME_ICON_SPACER"] = 2
TotemGuruConstants["BORDER_SIZE"] = 2
TotemGuruConstants["HEADER_SIZE"] = 
	TotemGuruConstants.FRAME_ICON_SIZE+
	(TotemGuruConstants.BORDER_SIZE*2)
TotemGuruConstants["NAME_SPACE_SIZE"] = 100+(TotemGuruConstants.BORDER_SIZE*2)
TotemGuruConstants["PLAYER_FONT_SIZE"] = 14
TotemGuruConstants["NAME_OFFSET"] = 5
TotemGuruConstants["FONT_TYPE"] = "Fonts\\FRIZQT__.ttf"
TotemGuruConstants["WARNING_ICON_OFFSET1"] = 131
TotemGuruConstants["WARNING_ICON_OFFSET2"] = 158
TotemGuruConstants["WARNING_ICON_OFFSET3"] = 186
TotemGuruConstants["WARNING_ICON_OFFSET4"] = 212
TotemGuruConstants["WARNING_ICON_SIZE"] = 12
TotemGuruConstants["TOTEM_ICON_SPACER"] = 2
TotemGuruConstants["TOTEM_ICON_SIZE"] = 25
TotemGuruConstants["TOTEM_BUTTON_SIZE"] = 25
TotemGuruConstants["ARROW_SIZE"] = 12
TotemGuruConstants["ARROW_SPACER"] = 1
TotemGuruConstants["PLAYER_ROW_HEIGHT"] = TotemGuruConstants.TOTEM_ICON_SIZE+TotemGuruConstants.TOTEM_ICON_SPACER
TotemGuruConstants["WARNING_ROW_HEIGHT"] = TotemGuruConstants.WARNING_ICON_SIZE+(TotemGuruConstants.BORDER_SIZE*2)
TotemGuruConstants["HEADER_ROW_HEIGHT"] = TotemGuruConstants.HEADER_SIZE
TotemGuruConstants["TOOLTIP_FONT_SIZE"] = 12

-- this one is for the totem window
TotemGuruConstants["TOTEM_NUMBER_SPACE_SIZE"] = 12
TotemGuruConstants["TOTEM_WINDOW_FONT_SIZE"] = 8

---------------------------------------------------
---------- main window functions ------------------
---------------------------------------------------

-----------------------
-- TotemGuruMain_OnLoad
-----------------------
function TotemGuruMain_OnLoad(frame)
	SLASH_TotemGuru1 = "/totemguru";
	SLASH_TotemGuru2 = "/tg";
	SlashCmdList["TotemGuru"] = function(...) TotemGuru_SlashCommandHandler(...);end
end
------------------------
-- TotemGuruMain_OnEvent
------------------------
function TotemGuruMain_OnEvent(self, event, ...)

	if (event == "VARIABLES_LOADED") then
        if (not TotemGuruData.VariablesLoaded) then
            TotemGuru_Variables_loaded()
        end
        -- if(not TotemGuruConfig.TotemGuruOff) then
			TotemGuruMain_Redraw()
		-- end
	end
	if (TotemGuruData.VariablesLoaded) then
        if (event == "COMBAT_LOG_EVENT_UNFILTERED") then	
    		local timestamp, combatEvent, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags =  ...; -- Those arguments appear for all combat event variants.
    		if (arg2 == "SPELL_SUMMON") then
    			local spellID = arg9;
    			local spellName, rank, icon, cost, isFunnel, powerType, castTime, minRange, maxRange = GetSpellInfo(spellID);
    			if(TotemGuruTotemsInfo[icon]) then
    				
    				myFraction,_ = UnitFactionGroup(PlayerName:GetText())
    				playerFraction ,_ = UnitFactionGroup(sourceName)
    				if not ( myFraction == playerFraction) then
    					if TotemGuruConfig.NoEnemyPlayers then
    						return
    					end
    				end
    				if (PlayerName:GetText()== sourceName) then
    					TotemGuru_PlayerDroppedTotem(sourceName,spellName,spellID,icon,destGUID)
    					TotemGuruWindows:UpdateHeight()
    					TotemGuruMain_Redraw();
    				else
    					if (sourceName=="Fire Elemental Totem" or sourceName=="Earth Elemental Totem") then
    						return
    					end
    					if(TotemGuruConfig.Monitor.Raid and not UnitInRaid(sourceName)) then 
    						return
    					elseif (TotemGuruConfig.Monitor.Party and not UnitInParty(sourceName)) then
    						return
    					end
    					TotemGuru_PlayerDroppedTotem(sourceName,spellName,spellID,icon,destGUID)
    					TotemGuruWindows:UpdateHeight()
    					TotemGuruMain_Redraw();
    				end
    			end
    		elseif (arg2 == "UNIT_DIED") then
    			for k,v in pairs(TotemGuruData.Players) do
    				for totem = 1, 4, 1 do
    					local player_totem = TotemGuruData.Players[k]["school"..totem]
    					if (player_totem and destGUID  == player_totem.totemGUID) then 
    						TotemGuru_TotemDied(player_totem)
    					end	
    				end		
    			end
    		end
    		 
    	elseif(event == "UNIT_AURA") then
    		if (arg1 == "player") then
    			TotemGuru_Check_Buffs(arg1)
    		end
    	elseif(event == "PLAYER_UNGHOST") then
    		TotemGuruMain_btnRefresh_OnClick()
	    elseif(event == "PLAYER_ENTERING_WORLD") then
    		TotemGuruMain_CheckInstance()
    		TotemGuruMain_btnRefresh_OnClick()
    	elseif(event == "PLAYER_TOTEM_UPDATE") then
    		haveTotem, totemName, startTime, duration = GetTotemInfo(arg1)
    		local player = TotemGuruData.Players[PlayerName:GetText()]
    		if (startTime==0 and player and player["school"..(5-arg1)])then
    			TotemGuru_TotemDied(player["school"..(5-arg1)])
    		end
    	elseif (event == "PLAYER_LOGOUT") then
    		TotemGuruConfig.MainFrame.x = TotemGuruMain:GetLeft();
    		TotemGuruConfig.MainFrame.y = TotemGuruMain:GetTop();
    	elseif (event == "CHAT_MSG_ADDON") then	
    		if (arg1 == "TotemGuru") then
    			if (arg2 == "VersionRequest") then
    				SendAddonMessage("TotemGuru_Version", GetAddOnMetadata("TotemGuru", "Version") , "WHISPER",arg4)
    			elseif arg2 == "ToggleAnims" then
    				--This is a real hacky way round the animation problem.
    				TotemGuruResetAnimations()
    			elseif(TotemGuruData.TotemGuru_admin) then
    				print(arg4 .. " has totemGuru Version " .. arg2)
    			end
    		elseif (arg1 == "TotemGuru_Version") then
    			TotemGuruPlayerVersion(arg4,arg2)
    		elseif (arg1 == "TotemGuru_TA") then
    			ReceivedTotemAssignments(arg4,arg2)
    		end
    	end
    end
end

--------------------------------
-- TotemGuruMain_CheckInstance()
--------------------------------
function TotemGuruMain_CheckInstance()
	local inInstance
    local instanceType
    inInstance, instanceType = IsInInstance()
    
    if TotemGuruConfig["Load" .. instanceType] then
		TotemGuruConfig.InstanceSettingHide = false
	else
		TotemGuruConfig.InstanceSettingHide = true
	end
	-- if TotemGuruConfig.LoadAll and instanceType  == "none" then
		-- TotemGuruConfig.InstanceSettingHide = false
	-- elseif TotemGuruConfig.LoadPVP and inInstance and (instanceType  == "pvp") then
		-- TotemGuruConfig.InstanceSettingHide = false
	-- elseif TotemGuruConfig.LoadArena and inInstance and (instanceType  == "arena") then
		-- TotemGuruConfig.InstanceSettingHide = false
	-- elseif TotemGuruConfig.LoadParty and inInstance and (instanceType  == "party") then
		-- TotemGuruConfig.InstanceSettingHide = false
	-- elseif TotemGuruConfig.LoadRaid and inInstance and (instanceType  == "raid") then
		-- TotemGuruConfig.InstanceSettingHide = false
	-- else
		-- TotemGuruConfig.InstanceSettingHide = true
	-- end
	TotemGuruMain_Toggle()
end
-------------------------
-- TotemGuruMain_Toggle()
-------------------------
function TotemGuruMain_Toggle()
	if(TotemGuruConfig.InstanceSettingHide) then
	--if (TotemGuruWindows.MainFrame:IsShown()) then
		TotemGuruWindows.MainFrame:Hide()
		TotemGuruWindows.ButtonsFrame:Hide()
		for totemschool = 1,4,1 do
			TotemGuruWindows["WarningIcon"..totemschool.."Button"]:Hide()
		end
		TotemGuruWindows.WarningsFrame:Hide()
		TotemGuruWindows.PlayerNameFrame:Hide()
		TotemGuruWindows.PlayerTotemsFrame:Hide()
	else
		TotemGuruWindows.MainFrame:Show()
		TotemGuruWindows.ButtonsFrame:Show()
		if TotemGuruConfig.ShowWarnings then
			TotemGuruWindows.WarningsFrame:Show()
		end
		TotemGuruWindows.PlayerNameFrame:Show()
		TotemGuruWindows.PlayerTotemsFrame:Show()
	end
	TotemGuruMain_Redraw()
end

---------------------------------
-- TotemGuruMain_btnClose_OnClick
---------------------------------
function TotemGuruMain_btnClose_OnClick()
	local inInstance
    local instanceType
    inInstance, instanceType = IsInInstance()
	if TotemGuruConfig["Load" .. instanceType] then
		TotemGuruConfig["Load" .. instanceType] = false
	else
		TotemGuruConfig["Load" .. instanceType] = true
	end
	TotemGuruMain_CheckInstance()
end

-----------------------------------
-- TotemGuruMain_btnRefresh_OnClick
-----------------------------------
function TotemGuruMain_btnRefresh_OnClick()
	--remove all players and hide all on screen data
	if (TotemGuruData.Players) then
		for k,v in pairs(TotemGuruData.Players) do
			local player = TotemGuruData.Players[k]
			if (player) then
				if(player.fontstring) then
					player.fontstring:Hide()
					player.fontstring = nil
				end
				for totem = 1, 4, 1 do 
					local school_ref = "school"..totem
					if(player[school_ref]) then
						TotemGuru_TotemDied(player[school_ref])
					end
				end
				player.UpArrow:Hide()
				player.UpArrow = nil
				player.DownArrow:Hide()
				player.DownArrow = nil
				player=nil
			end 
		end
	end
	--TotemGuruWindows.MainFrame:SetAlpha(TotemGuruConfig.BackgroundAlpha)
	TotemGuruData.CurrentNoOfPlayers=0
	TotemGuruData.Players={}
	TotemGuruWindows:UpdateHeight()
	TotemGuruMain_Redraw();
end

-------------------------------------
-- TotemGuruMain_btnSettings_OnClick
-------------------------------------
function TotemGuruMain_btnSettings_OnClick()
	InterfaceOptionsFrame_OpenToCategory(TotemGuruSettingsGUI.mainPanel);
end
-------------------------------------
-- TotemGuruMain_Redraw
-------------------------------------
function TotemGuruMain_Redraw()
	--if not TotemGuruConfig.TotemGuruOff then
	if not TotemGuruConfig.InstanceSettingHide then
		TotemGuruWindows.MainFrame:SetWidth(TotemGuruWindows.MainFrame.Width)
		local TP = TotemGuruData.Positions
		local player 
		if TotemGuruConfig.ShowWarnings then
			TotemGuruWindows.WarningsFrame:Show()
			for totemschool = 1,4,1 do
				if TotemGuruData.CurrentTotemWarnings[totemschool].PlayerLevelWarning <= TotemGuruData.CurrentNoOfPlayers  then
					TotemGuruWindows["WarningIcon"..totemschool.."Button"]:Show()
				else
					TotemGuruWindows["WarningIcon"..totemschool.."Button"]:Hide()	
					
				end
			end	
		else
			TotemGuruWindows.WarningsFrame:Hide()		
		end
		
		if (TotemGuruData.Players) then
			for k,v in pairs(TotemGuruData.Players) do
				TotemGuru_UpdatePlayerIcons(TotemGuruData.Players[k])
			end
		end
	end
end

------------------------------
-- TotemGuru_UpdatePlayerIcons
------------------------------
function TotemGuru_UpdatePlayerIcons(player,frame)
	local row_height = 0
	local window_height = 0
	local extras
	if frame then
		extras = false
		local button_Size = TotemGuruConstants.TOTEM_ICON_SIZE
	else
		local button_Size = TotemGuruConstants.TOTEM_ICON_SIZE--*TotemGuruConfig.TotemGuruScale
		frame = TotemGuruWindows
		extras = true
	end
    for i = 1, 4 do
        local school_ref = "school".. i
        if (player[school_ref] and player["school".. i].button) then
            local button = player[school_ref].button
            button:SetPoint("TOPLEFT", frame.PlayerTotemsFrame, "TOPLEFT", 
				(TotemGuruConstants.TOTEM_ICON_SIZE + TotemGuruConstants.TOTEM_ICON_SPACER)*(i-1),
				-TotemGuruConstants.PLAYER_ROW_HEIGHT*(player.player_id-1))
           
            if extras and TotemGuruConfig.ShowBuffFlash then
				if player[school_ref].buff == 1 then
					button.buffIcon.startFlashing()
					button:SetAlpha(TotemGuruConfig.TotemNormalAlpha)
					button.buffIcon:SetAlpha(TotemGuruConfig.TotemNormalAlpha)
				else
					button.buffIcon.stopFlashing()
					button:SetAlpha(TotemGuruConfig.TotemUnbuffedAlpha)
					button.buffIcon:SetAlpha(0)
				end
			else
				button.buffIcon.stopFlashing()
				button:SetAlpha(TotemGuruConfig.TotemNormalAlpha)
			end
			--if extras and (not TotemGuruConfig.TotemGuruOff) and TotemGuruConfig.ShowCooldowns then
			if extras and TotemGuruConfig.ShowCooldowns then
				player[school_ref].button.cooldown:Show()
			else
				player[school_ref].button.cooldown:Hide()
			end
		end
	end
	if extras then
		if player.player_id ~= 1 then
			player.UpArrow:SetPoint("TOPLEFT", frame.PlayerTotemsFrame, "TOPLEFT", 
				-(TotemGuruConstants.ARROW_SIZE+TotemGuruConstants.ARROW_SPACER), 
				-(TotemGuruConstants.ARROW_SPACER 
					+(TotemGuruConstants.PLAYER_ROW_HEIGHT*(player.player_id-1))
				))
			player.UpArrow:SetWidth(TotemGuruConstants.ARROW_SIZE)
			player.UpArrow:SetHeight(TotemGuruConstants.ARROW_SIZE)
			player.UpArrow:Show()
		else
			player.UpArrow:Hide()
		end
		if player.player_id ~= TotemGuruData.CurrentNoOfPlayers then
			player.DownArrow:SetPoint("TOPLEFT", frame.PlayerTotemsFrame, "TOPLEFT", 
				-(TotemGuruConstants.ARROW_SIZE+TotemGuruConstants.ARROW_SPACER),
				-(	(TotemGuruConstants.PLAYER_ROW_HEIGHT+
						(TotemGuruConstants.PLAYER_ROW_HEIGHT*(player.player_id-1))
					)-(TotemGuruConstants.ARROW_SIZE+TotemGuruConstants.ARROW_SPACER)))
			player.DownArrow:SetWidth(TotemGuruConstants.ARROW_SIZE)
			player.DownArrow:SetHeight(TotemGuruConstants.ARROW_SIZE)
			player.DownArrow:Show()
		else
			player.DownArrow:Hide()
		end
	end
	local fontstring = player.fontstring
	fontstring:SetSpacing(0)
	fontstring:SetAlpha(TotemGuruConfig.PlayerNameAlpha)
	fontstring:SetPoint("TOPLEFT", frame.PlayerNameFrame, "TOPLEFT", 
		0, 
		-TotemGuruConstants.PLAYER_ROW_HEIGHT*(player.player_id-1))
	fontstring:SetPoint("TOPRIGHT",  frame.PlayerNameFrame, "TOPRIGHT", 
		0, 
		-TotemGuruConstants.PLAYER_ROW_HEIGHT*(player.player_id-1))
	fontstring:SetJustifyV("CENTER")
	fontstring:SetJustifyH("LEFT")
end

-----------------------------
-- TotemGuru_PlayerUp_OnClick
-----------------------------
function TotemGuru_PlayerUp_OnClick(sourceName)
    local currentPos = TotemGuruData.Players[sourceName].player_id
    if currentPos > 1 then
        for k,v in pairs(TotemGuruData.Players) do
            if TotemGuruData.Players[k].player_id == currentPos -1 then
                TotemGuruData.Players[k].player_id = currentPos
                TotemGuruData.Players[sourceName].player_id = currentPos -1
                TotemGuruMain_Redraw()
            end
        end
    end
end
-------------------------------
-- TotemGuru_PlayerDown_OnClick
-------------------------------
function TotemGuru_PlayerDown_OnClick(sourceName)
    local currentPos = TotemGuruData.Players[sourceName].player_id
    if currentPos < TotemGuruData.CurrentNoOfPlayers then
        for k,v in pairs(TotemGuruData.Players) do
            if TotemGuruData.Players[k].player_id == currentPos +1 then
                TotemGuruData.Players[k].player_id = currentPos
                TotemGuruData.Players[sourceName].player_id = currentPos +1
				TotemGuruMain_Redraw()
            end
        end
    end
end

---------------------------------------------------
---------- Tooltips Window functionality ----------
---------------------------------------------------

-------------------------
-- TotemGuru_showTooltip
-------------------------
function TotemGuru_showTooltip(button,icon,spellID)
	--if(not TotemGuruConfig.TotemGuruOff) and
	if TotemGuruConfig.TooltipsEnabled then 
		local TipText = ""
		if not spellID then
			local totem_priority = 100;
			local warning_icon;
			for totem_icon,priority in pairs (TotemGuruData.CurrentTotemWarnings[icon].List) do
				if totem_priority > tonumber(priority) then
					totem_priority = tonumber(priority);
					warning_icon = totem_icon;
				end;
			end
			if not warning_icon then
				return
			end
			TipText = TipText .. "|TTexturePath:" .. floor((TotemGuruConstants.TOOLTIP_FONT_SIZE+4)*TotemGuruConfig.TotemGuruScale) .. "|t";
			TipText = TipText .. TotemGuruTotemsInfo[warning_icon].name;
		elseif(TotemGuruTotemsInfo[icon] and TotemGuruTotemsInfo[icon].ranks[tostring(spellID)]) then
			if (string.find(TotemGuruTotemsInfo[icon].ranks[tostring(spellID)], "*")) then
				TipText = "|cFFFF0000 " 
			else
				TipText = "|cFF00FF00 "
			end
			TipText = TipText .. "|TTexturePath:" .. floor((TotemGuruConstants.TOOLTIP_FONT_SIZE+4)*TotemGuruConfig.TotemGuruScale) .. "|t"
			TipText = TipText .. TotemGuruTotemsInfo[icon].name .. " " .. TotemGuruTotemsInfo[icon].ranks[tostring(spellID)]
			TipText = TipText .. "|r|n" ..  TotemGuruTotemsInfo[icon].effect
			TipText = TipText .. "|nRange " ..  TotemGuruTotemsInfo[icon].range
			TipText = TipText .. "|nDuration " ..  TotemGuruTotemsInfo[icon].duration
		else
			TipText = "Totem data not found"
		end
		if not TotemGuruData.Tooltip then
			TotemGuruData.Tooltip = CreateFrame("Frame", nil,UIParent)
			TotemGuruData.Tooltip:SetFrameStrata("TOOLTIP")
			TotemGuruData.Tooltip:SetClampedToScreen(true)
			local bg = {
				bgFile = "Interface\\Buttons\\UI-SliderBar-Background",
				edgeFile = "Interface\\Buttons\\UI-SliderBar-Border",
				tile	 = true,
				tileSize = 8,
				edgeSize = 8,
				insets = { left = 3, right = 3, top = 6, bottom = 6 }
			}
			TotemGuruData.Tooltip:SetBackdrop(bg)
		end

		TotemGuruData.Tooltip:SetPoint("LEFT", button, "RIGHT")
		if not TotemGuruData.Tooltip.text then
			TotemGuruData.Tooltip.text = TotemGuruData.Tooltip:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
			TotemGuruData.Tooltip.text:SetFont(TotemGuruConstants.FONT_TYPE, floor(TotemGuruConstants.TOOLTIP_FONT_SIZE*TotemGuruConfig.TotemGuruScale))
			TotemGuruData.Tooltip.text:SetJustifyH("LEFT")
			TotemGuruData.Tooltip.text:SetPoint("TOPLEFT",TotemGuruData.Tooltip,"TOPLEFT",3,-3)
			TotemGuruData.Tooltip.text:SetPoint("BOTTOMRIGHT",TotemGuruData.Tooltip,"BOTTOMRIGHT",3,3)
		end

		TotemGuruData.Tooltip.text:SetText(TipText)
		TotemGuruData.Tooltip:SetWidth(ceil(TotemGuruData.Tooltip.text:GetWidth()+15))
		TotemGuruData.Tooltip:SetHeight(ceil(TotemGuruData.Tooltip.text:GetHeight()+15))
		TotemGuruData.Tooltip:Show()
	end
end

-------------------------
-- TotemGuru_hideTooltip
-------------------------
function TotemGuru_hideTooltip()
	if(TotemGuruData.Tooltip) then 
		TotemGuruData.Tooltip:Hide()
	end
end

---------------------------------------------------
---------- Totems Window functionality ------------
---------------------------------------------------


---------------------------------
-- TotemGuru_OnTotemPriorityClick
---------------------------------
function TotemGuru_OnTotemPriorityClick(source,icon)
	
	if((not TotemGuruConfig.MonitoredTotems[TotemGuruTotemsInfo[icon].school])
		or (not TotemGuruConfig.MonitoredTotems[TotemGuruTotemsInfo[icon].school][icon])) then
		for k,v in pairs(TotemGuruConfig.Totems[TotemGuruTotemsInfo[icon].school]) do
			if v == icon then
				if not TotemGuruConfig.MonitoredTotems[TotemGuruTotemsInfo[icon].school] then
					TotemGuruConfig.MonitoredTotems[TotemGuruTotemsInfo[icon].school] = {}
				end
				if not TotemGuruConfig.MonitoredTotems[TotemGuruTotemsInfo[icon].school] then
					TotemGuruConfig.MonitoredTotems[TotemGuruTotemsInfo[icon].school] = {}
				end
				TotemGuruConfig.MonitoredTotems[TotemGuruTotemsInfo[icon].school][icon]= k
			end
		end
	else
		TotemGuruConfig.MonitoredTotems[TotemGuruTotemsInfo[icon].school][icon] =nil
	end
	TotemGuru_CheckWarnings(TotemGuruTotemsInfo[icon].school)
	TotemGuru_TotemsWindow_Redraw()
	TotemGuruMain_Redraw()
end

--------------------------------
-- TotemGuru_TotemUp_OnClick
--------------------------------
function TotemGuru_TotemUp_OnClick(source)
	local prioritySchool = TotemGuruTotemsInfo[source].school
	local TotemPosition

	for position,totem in pairs(TotemGuruConfig.Totems[prioritySchool]) do
		if totem==source then
			TotemPosition = position
		end
	end
	
	local currentPosition = tostring(TotemPosition)
	local newPosition = tostring(TotemPosition-1)
	local totemAtNewPosition = TotemGuruConfig.Totems[prioritySchool][newPosition]
	TotemGuruConfig.Totems[prioritySchool][currentPosition] = totemAtNewPosition
	TotemGuruConfig.Totems[prioritySchool][newPosition] = source

	if TotemGuruConfig.MonitoredTotems[prioritySchool] then
		if (TotemGuruConfig.MonitoredTotems[prioritySchool][source]) then
			TotemGuruConfig.MonitoredTotems[prioritySchool][source] = newPosition
		end
		if (TotemGuruConfig.MonitoredTotems[prioritySchool][totemAtNewPosition]) then
			TotemGuruConfig.MonitoredTotems[prioritySchool][totemAtNewPosition] = currentPosition
		end
	end
	TotemGuru_TotemsWindow_Redraw()
	TotemGuru_CheckWarnings(TotemGuruTotemsInfo[source].school)
	TotemGuruMain_Redraw()
end

--------------------------------
-- TotemGuru_TotemDown_OnClick
--------------------------------
function TotemGuru_TotemDown_OnClick(source)
	local prioritySchool = TotemGuruTotemsInfo[source].school
	local TotemPosition

	for position,totem in pairs(TotemGuruConfig.Totems[prioritySchool]) do
		if totem==source then
			TotemPosition = position
		end
	end
	
	local currentPosition = tostring(TotemPosition)
	local newPosition = tostring(TotemPosition+1)
	local totemAtNewPosition = TotemGuruConfig.Totems[prioritySchool][newPosition]
	TotemGuruConfig.Totems[prioritySchool][currentPosition] = totemAtNewPosition
	TotemGuruConfig.Totems[prioritySchool][newPosition] = source
	if TotemGuruConfig.MonitoredTotems[prioritySchool] then
		if (TotemGuruConfig.MonitoredTotems[prioritySchool][source]) then
			TotemGuruConfig.MonitoredTotems[prioritySchool][source] = newPosition
		end
		if (TotemGuruConfig.MonitoredTotems[prioritySchool][totemAtNewPosition]) then
			TotemGuruConfig.MonitoredTotems[prioritySchool][totemAtNewPosition] = currentPosition
		end
	end
	TotemGuru_TotemsWindow_Redraw()
	TotemGuru_CheckWarnings(TotemGuruTotemsInfo[source].school)
	TotemGuruMain_Redraw()
end

---------------------------------------------------
---------- general Window functionality -----------
---------------------------------------------------
------------------------------
-- TotemGuruResetAnimations
------------------------------
function TotemGuruResetAnimations()
	--#### This is only here due to a bug where playing animations 
	--#### don't appear to move with the main windows
	local totem
	if (TotemGuruData.Players) then
		for _,player in pairs(TotemGuruData.Players) do
			for school = 1,4  do
				totem = player["school"..school]
				if (totem and
					totem.button and
					totem.button.buffIcon and
					totem.button.buffIcon and
					totem.button.buffIcon.anim) then
					if (totem.button.buffIcon.anim:IsPlaying()) then
						totem.button.buffIcon.stopFlashing()
						totem.button.buffIcon.startFlashing()
					end
				end
			end
		end
	end
end
------------------------------
-- TotemGuru_Create_Totem_icon
------------------------------
function TotemGuru_Create_Totem_icon(ParentWindow,source,icon,spellID,school_ref,mouseclick, playerName)
	source.button = TotemGuruData.TotemButtonStash:GetButton()
	local button = source.button
	button:Show()
	button:SetParent(ParentWindow)
	button:SetScript("OnEnter", function (...) TotemGuru_showTooltip(button,icon,spellID) end)
	button:SetScript("OnLeave", function (...) TotemGuru_hideTooltip() end)
	button:SetWidth(TotemGuruConstants.TOTEM_ICON_SIZE)
    button:SetHeight(TotemGuruConstants.TOTEM_ICON_SIZE)
	if mouseclick then
		button:SetScript("OnClick", function (...) mouseclick(playerName,icon) end)
	end
	button.icon:SetTexture(icon)
end

-----------------------------------
-- TotemGuru_Create_position_arrows
-----------------------------------
function TotemGuru_Create_position_arrows(arrowParent,source,sourceName,upHandler,downHandler)
    source.UpArrow  = CreateFrame("Button", nil, arrowParent)
	source.UpArrow:SetScript("OnClick", function (...) upHandler(sourceName) end)
	source.UpArrow.icon = source.UpArrow:CreateTexture("texture", "ARTWORK")
    source.UpArrow.icon:SetParent(source.UpArrow)
    source.UpArrow.icon:SetTexCoord(0.22, 0.75, 0.24, 0.74)
    source.UpArrow.icon:SetPoint("TOPLEFT", source.UpArrow, "TOPLEFT", 0,0)
    source.UpArrow.icon:SetPoint("BOTTOMRIGHT", source.UpArrow, "BOTTOMRIGHT", 0,0)
    source.UpArrow.icon:SetTexture("Interface\\BUTTONS\\UI-ScrollBar-ScrollUpButton-up")
    source.DownArrow  = CreateFrame("Button", nil, arrowParent)
	source.DownArrow:SetScript("OnClick", function (...) downHandler(sourceName) end)
	source.DownArrow.icon = source.DownArrow:CreateTexture("texture", "ARTWORK")
	source.DownArrow.icon:SetParent(source.DownArrow)
	source.DownArrow.icon:SetTexCoord(0.22, 0.75, 0.24, 0.74)
    source.DownArrow.icon:SetPoint("TOPLEFT", source.DownArrow, "TOPLEFT", 0,0)
    source.DownArrow.icon:SetPoint("BOTTOMRIGHT", source.DownArrow, "BOTTOMRIGHT", 0,0)
    source.DownArrow.icon:SetTexture("Interface\\BUTTONS\\UI-ScrollBar-ScrollDownButton-up")
    TotemGuruMain_Redraw()
	
end

---------------------------------------------------
---------- general functionality ------------------
---------------------------------------------------
---------------------------
-- TotemGuru_Reset_Defaults
---------------------------
function TotemGuru_Reset_Defaults()
	if (not TotemGuruData.VariablesLoaded) then
		return;	
	end
	TotemGuruConfig = TotemGuruConfigDefaults;
end 

-----------------------------------
-- TotemGuruConfig_Variables_loaded
-----------------------------------
function TotemGuru_Variables_loaded()
    if (TotemGuruConfig and TotemGuruConfig.Version) then
		if (not (TotemGuruConfig.Version == GetAddOnMetadata("TotemGuru", "Version"))) then
			local version = TotemGuruConfig.Version
			TotemGuruConfig = TotemGuruConfigDefaults;
			TotemGuruConfig.Version = GetAddOnMetadata("TotemGuru", "Version");
			print("|cFFAAAA00TotemGuru found updated version V" .. TotemGuruConfig.Version .. " > " .. version);
		end
	else
		print("|cFFAAAA00TotemGuru found new Version " .. GetAddOnMetadata("TotemGuru", "Version"));
		TotemGuruConfig = TotemGuruConfigDefaults;
		TotemGuruConfig.Version = GetAddOnMetadata("TotemGuru", "Version");
	end
	TotemGuruData["TotemButtonStash"] = ButtonStash:new()
	print("|cFFAAAA00TotemGuru V" .. GetAddOnMetadata("TotemGuru", "Version") .. " Copyright (C) 2009 Jon Edmunds");
    TotemGuruData.VariablesLoaded = 1;
    
	TotemGuruSettingsGUI:init()
    TotemGuruMain_Toggle()
end

-------------------------
-- TotemGuru_ToggleAdmin
-------------------------
function TotemGuru_ToggleAdmin()
	if (TotemGuruData.TotemGuru_admin) then
		TotemGuruData.TotemGuru_admin=nil;
		print("TotemGuru admin off");
	else
		TotemGuruData.TotemGuru_admin=true;
		print("TotemGuru admin on");
		
	end
end

-------------------------------
-- TotemGuru_PlayerDroppedTotem
-------------------------------
function TotemGuru_PlayerDroppedTotem(sourceName,spellName,spellID,icon,destGUID)
	local school_id = TotemGuruTotemsInfo[icon].school
	local school_ref = "school" .. school_id
    if (not TotemGuruData.Players[sourceName]) then
		TotemGuru_AddPlayer(sourceName,spellName,icon,destGUID,school_ref)
	else
		if(TotemGuruData.Players[sourceName][school_ref]) then
			TotemGuru_TotemDied(TotemGuruData.Players[sourceName][school_ref])
		end
		TotemGuruData.Players[sourceName][school_ref] = {spellname = spellName,icon=icon,totemGUID = destGUID}
	end
	if (not TotemGuruData.Players[sourceName][school_ref].button) then
		TotemGuru_Create_Totem_icon(TotemGuruWindows.PlayerTotemsFrame,TotemGuruData.Players[sourceName][school_ref],icon,spellID,school_ref,nil,sourceName)
    end
	TotemGuru_UpdatePlayerIcons(TotemGuruData.Players[sourceName])
	if(TotemGuruData.Players[sourceName][school_ref].button.cooldown) then
		CooldownFrame_SetTimer(TotemGuruData.Players[sourceName][school_ref].button.cooldown, GetTime(), TotemGuruTotemsInfo[icon].duration, 1)
	end
	TotemGuru_CheckWarnings(school_id)
end

----------------------
-- TotemGuru_AddPlayer
----------------------
function TotemGuru_AddPlayer(sourceName,spellName,icon,destGUID,school_ref)
	local y
	TotemGuruData.CurrentNoOfPlayers = TotemGuruData.CurrentNoOfPlayers+1
	TotemGuruData.Players[sourceName] = nil
	TotemGuruData.Players[sourceName] = {[school_ref]={spellname = spellName,icon=icon,totemGUID = destGUID}};
	TotemGuruData.Players[sourceName].player_id = TotemGuruData.CurrentNoOfPlayers
	TotemGuruData.Players[sourceName].fontstring = TotemGuruWindows.PlayerNameFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	local fontstring = TotemGuruData.Players[sourceName].fontstring
	-- if(TotemGuruConfig.TotemGuruOff) then
		-- fontstring:Hide()
	-- else
		-- fontstring:Show()
	-- end
	fontstring:SetFont(TotemGuruConstants.FONT_TYPE, TotemGuruConstants.PLAYER_FONT_SIZE)
	
	fontstring:SetNonSpaceWrap(nil)
	fontstring:SetSpacing(0) 
	fontstring:SetHeight(TotemGuruConstants.PLAYER_FONT_SIZE) 
	
	fontstring:SetText(sourceName)
	TotemGuru_Create_position_arrows(TotemGuruWindows.PlayerTotemsFrame,TotemGuruData.Players[sourceName],sourceName,TotemGuru_PlayerUp_OnClick,TotemGuru_PlayerDown_OnClick)
	TotemGuru_CheckAllWarnings()
	SendAddonMessage("TotemGuru","ToggleAnims","WHISPER",PlayerName:GetText());
end

--------------------------------
-- TotemGuru_SlashCommandHandler
--------------------------------
function TotemGuru_SlashCommandHandler(msg)
    InterfaceOptionsFrame_OpenToCategory(TotemGuruSettingsGUI.mainPanel);
end

----------------------
-- TotemGuru_TotemDied
----------------------
function TotemGuru_TotemDied(player_totem)
	local totemRemoved = player_totem.icon
	if(player_totem) then
		if(player_totem.button) then	
			if player_totem.button.buffIcon then
				UIFrameFlashRemoveFrame(player_totem.button.buffIcon)
				UIFrameFadeRemoveFrame(player_totem.button.buffIcon)
				player_totem.button.buffIcon:SetAlpha(0)	
			end
			player_totem.button:Hide()
			player_totem.button = TotemGuruData.TotemButtonStash:ReleaseButton(player_totem.button)
			player_totem.spellname = 0
			player_totem.totemGUID = 0
		end
	end
	if (totemRemoved) then
		TotemGuru_CheckWarnings(TotemGuruTotemsInfo[totemRemoved].school)
	end
end
--------------------------
-- TotemGuru_CheckAllWarnings
--------------------------
function TotemGuru_CheckAllWarnings()
	for i = 1,4 do
		TotemGuru_CheckWarnings(i)
	end
end
--------------------------
-- TotemGuru_CheckWarnings
--------------------------
function TotemGuru_CheckWarnings(school)
	local lowestPriority = 100
	TotemGuruData.CurrentTotemWarnings[school].PlayerLevelWarning = 100
	TotemGuruData.CurrentTotemWarnings[school].List = {}
	if TotemGuruConfig.ShowWarnings and TotemGuruConfig.MonitoredTotems[school] then
		local addWarning
		for MonitoredTotem, MonitoredPriority in pairs (TotemGuruConfig.MonitoredTotems[school]) do
			addWarning = true
			if tonumber(MonitoredPriority) < TotemGuruData.CurrentNoOfPlayers then
				for PlayerName,playerTable in pairs (TotemGuruData.Players) do
				    if playerTable["school" .. school] and playerTable["school" .. school].icon == MonitoredTotem then
						addWarning = false;
					end
				end
				if addWarning then
					if not TotemGuruData.CurrentTotemWarnings[school].List[MonitoredTotem] then
						TotemGuruData.CurrentTotemWarnings[school].List[MonitoredTotem] = nil
					end
					TotemGuruData.CurrentTotemWarnings[school].List[MonitoredTotem]=MonitoredPriority;
					if lowestPriority > tonumber(MonitoredPriority) then
						lowestPriority = tonumber(MonitoredPriority) +1;
					end
				else
					if TotemGuruData.CurrentTotemWarnings[school].List[MonitoredTotem] then
						TotemGuruData.CurrentTotemWarnings[school].List[MonitoredTotem] = nil
					end
				end
			end
		end
		if (lowestPriority < 100) then
			TotemGuruData.CurrentTotemWarnings[school].PlayerLevelWarning = lowestPriority
		end
	end
    
end

--------------------------
-- TotemGuru_Check_Buffs()
--------------------------
function TotemGuru_Check_Buffs(unit)
	local id = id or 1; 
	local tmpPlayer;-- default value, making id optional;
	-- first lets mark all players as not setting auras
	-- we have to do it like this as we don't know if a buff was removed
	for k,v in pairs(TotemGuruData.Players) do
		tmpPlayer = TotemGuruData.Players[k]
		for totem = 1, 4, 1 do
			if (tmpPlayer["school"..totem]) then
				tmpPlayer["school"..totem].buff = 0
			end
		end
	end
	
	while true do
		local name, rank, buffTexture, count, type, duration, timeleft, owner = UnitBuff (unit, id);
		-- finish whe we run out of buffs to check
		if not name then
			break;
		end
		if not owner or owner == "target" or owner == "mouseover" then
			-- annoyingly if we have the mouse over a totem (or it targetted)
			-- then this returns a value that doesn't work in UnitName
			currentBuffOwner = ""
		else
			currentBuffOwner,_ = UnitName(owner)
		end
		
		-- is this a totem or some other buff
		if (TotemGuruTotemsInfo[buffTexture]) then
			local school = "school"..TotemGuruTotemsInfo[buffTexture].school
			if (TotemGuruData.Players[currentBuffOwner] and
					TotemGuruData.Players[currentBuffOwner][school] and
					TotemGuruData.Players[currentBuffOwner][school].icon == buffTexture) then
				TotemGuruData.Players[currentBuffOwner][school].buff = 1
			end
		end
		id = id +1
	end
	for k,v in pairs(TotemGuruData.Players) do
		TotemGuru_UpdatePlayerIcons(TotemGuruData.Players[k])
	end
end
-- initialise the main window
TotemGuruWindows:init()
