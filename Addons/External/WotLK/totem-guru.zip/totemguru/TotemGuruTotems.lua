--  TotemGuru is a world of warcraft addon for showing totems during raiding
--  Copyright (C) 2009 Jon Edmunds (je95(AT)zepler.org.uk)
--  Create Date : 8/16/2009 9:16:05 AM
--  This file is part of the TotemGuru Wow Addon.
--
--  TotemGuru is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
-- 
--  TotemGuru is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
-- 
--  You should have received a copy of the GNU General Public License
--  along with TotemGuru.  If not, see <http://www.gnu.org/licenses/>.

--some local variables
TotemGuru_air_school=1
TotemGuru_water_school=2
TotemGuru_earth_school=3
TotemGuru_fire_school=4


-- These textuers were found by printing the icon field from the combat log message for 'SPELL_SUMMON'
-- if these stop working then add a print(icon) line into the event handler and drop the totem you
-- want to monitor to see the image path, and then add it in here.
-- you can also fool this by using other icons for other abilities if you wnt to see them appear in the list
TotemGuru_Textures = 
	{
		NatureResistance = "Interface\\Icons\\Spell_Nature_NatureResistanceTotem",
		Grounding = "Interface\\Icons\\Spell_Nature_GroundingTotem",
	    Windfury = "Interface\\Icons\\Spell_Nature_Windfury",
	    Sentry = "Interface\\Icons\\Spell_Nature_RemoveCurse",
	    WrathOfAir = "Interface\\Icons\\Spell_Nature_SlowingTotem",
		ManaSpring = "Interface\\Icons\\Spell_Nature_ManaRegenTotem",
		Poison = "Interface\\Icons\\Spell_Nature_DiseaseCleansingTotem",
		--Disease = "Interface\\Icons\\Spell_Nature_DiseaseCleansingTotem",
		FireResistance = "Interface\\Icons\\Spell_FireResistanceTotem_01",
		HealingStream = "Interface\\Icons\\INV_Spear_04",
		ManaTide = "Interface\\Icons\\Spell_Frost_SummonWaterElemental",
	    StoneClaw = "Interface\\Icons\\Spell_Nature_StoneClawTotem",
	    EarthBind = "Interface\\Icons\\Spell_Nature_StrengthOfEarthTotem02",
	    StoneSkin = "Interface\\Icons\\Spell_Nature_StoneSkinTotem",
	    StrengthOfEarth = "Interface\\Icons\\Spell_Nature_EarthBindTotem",
		EarthElemental = "Interface\\Icons\\Spell_Nature_EarthElemental_Totem",
		Tremor = "Interface\\Icons\\Spell_Nature_TremorTotem",
		Wrath = "Interface\\Icons\\Spell_Fire_TotemOfWrath",
		Searing = "Interface\\Icons\\Spell_Fire_SearingTotem",
		Magma = "Interface\\Icons\\Spell_Fire_SelfDestruct",
		FlameTongue = "Interface\\Icons\\Spell_Nature_GuardianWard",
		--FireNova = "Interface\\Icons\\Spell_Fire_SealOfFire",
		FrostResistance = "Interface\\Icons\\Spell_FrostResistanceTotem_01",
		FireElemental = "Interface\\Icons\\Spell_Fire_Elemental_Totem",
		
	}
	
-- less processing to do it this way that searching and its only a small table :P
TotemGuru_Totem_Message_Ids = 
	{
		[1] = TotemGuru_Textures.NatureResistance,
		[TotemGuru_Textures.NatureResistance] = 1,
		[2] = TotemGuru_Textures.Grounding,
	    [TotemGuru_Textures.Grounding] = 2,
	    [3] = TotemGuru_Textures.Windfury,
	    [TotemGuru_Textures.Windfury] = 3,
	    [4] = TotemGuru_Textures.Sentry,
	    [TotemGuru_Textures.Sentry] = 4,
	    [5] = TotemGuru_Textures.WrathOfAir,
		[TotemGuru_Textures.WrathOfAir] = 5,
		[6] = TotemGuru_Textures.ManaSpring,
		[TotemGuru_Textures.ManaSpring] = 6,
		[7] = TotemGuru_Textures.Poison,
		[TotemGuru_Textures.Poison] = 7,
		--[8] = TotemGuru_Textures.Disease,
		--[TotemGuru_Textures.Disease] = 8,
		[8] = TotemGuru_Textures.FireResistance,
		[TotemGuru_Textures.FireResistance] = 8,
		[9] = TotemGuru_Textures.HealingStream,
		[TotemGuru_Textures.HealingStream] = 9,
		[10] = TotemGuru_Textures.ManaTide,
	    [TotemGuru_Textures.ManaTide] = 10,
	    [11] = TotemGuru_Textures.StoneClaw,
	    [TotemGuru_Textures.StoneClaw] = 11,
	    [12] = TotemGuru_Textures.EarthBind,
	    [TotemGuru_Textures.EarthBind] = 12,
	    [13] = TotemGuru_Textures.StoneSkin,
	    [TotemGuru_Textures.StoneSkin] = 13,
	    [14] = TotemGuru_Textures.StrengthOfEarth,
		[TotemGuru_Textures.StrengthOfEarth] = 14,
		[15] = TotemGuru_Textures.EarthElemental,
		[TotemGuru_Textures.EarthElemental] = 15,
		[16] = TotemGuru_Textures.Tremor,
		[TotemGuru_Textures.Tremor] = 16,
		[17] = TotemGuru_Textures.Wrath,
		[TotemGuru_Textures.Wrath] = 17,
		[18] = TotemGuru_Textures.Searing,
		[TotemGuru_Textures.Searing] = 18,
		[19] = TotemGuru_Textures.Magma,
		[TotemGuru_Textures.Magma] = 19,
		[20] = TotemGuru_Textures.FlameTongue,
		[TotemGuru_Textures.FlameTongue] = 20,
		--[21] = TotemGuru_Textures.FireNova,
		--[TotemGuru_Textures.FireNova] = 21,
		[21] = TotemGuru_Textures.FrostResistance,
		[TotemGuru_Textures.FrostResistance] = 21,
		[22] = TotemGuru_Textures.FireElemental,
		[TotemGuru_Textures.FireElemental] = 22,
		
	}

-- The main data array for totems. Ranks are spellId and an '*' on the
-- name is to indicate that its not the highest rank available
TotemGuruTotemsInfo = 
	{
		[TotemGuru_Textures.NatureResistance] = 
		{
			school = TotemGuru_air_school,
			name = "Nature Resistance Totem",
			effect = "Increases Nature resistance of party",
            range = "30",
            duration = 300,
			ranks = 
			{   
				-- default value
				["0"] = "Rank 6",
				["10595"] = "Rank 1*",
                ["10600"] = "Rank 2*",
                ["10601"] = "Rank 2*",
                ["25574"] = "Rank 4*",
                ["58746"] = "Rank 5*",
                ["58749"] = "Rank 6",
            },
		},
		[TotemGuru_Textures.Grounding] = 
		{
			school = TotemGuru_air_school,
			name = "Grounding Totem",
			effect = "Absorbs one harmful spell cast on a nearby party member to iteself",
            range = "0",
            duration = 45, 
			ranks = 
            {
                ["0"] = "Rank 1",
                ["8177"] = "Rank 1",
            }
		},
		[TotemGuru_Textures.Windfury] = 
		{
			school = TotemGuru_air_school,
			name = "Windfury Totem",
			effect = "Provides melee haste to all party members",
            range = "30",
            duration = 300,
            ranks = 
            {
                ["0"] = "Rank 1",
                ["8512"] = "Rank 1",
            }
		},
		[TotemGuru_Textures.Sentry] = 
		{
			school = TotemGuru_air_school,
			name = "Sentry Totem",
			effect = "Summons an immobile Sentry Totem",
            range = "0",
            duration = 300,
            ranks = 
            {
                ["0"] = "Rank 1",
                ["6495"] = "Rank 1",
            }
		},
		[TotemGuru_Textures.ManaSpring] = 
		{
			school = TotemGuru_water_school,
			name = "Mana Spring Totem",
			effect = "Restores mana every 2 seconds to group members",
            range = "30",
            duration = 300,
            ranks = 
            {
                ["0"] = "Rank 8",
                ["5675"] = "Rank 1*",
                ["10495"] = "Rank 2*",
                ["10496"] = "Rank 3*",
                ["10497"] = "Rank 4*",
                ["35570"] = "Rank 5*",
                ["58771"] = "Rank 6*",
                ["58773"] = "Rank 7*",
                ["58774"] = "Rank 8",
            }
            
		},
		[TotemGuru_Textures.WrathOfAir] = 
		{
			school = TotemGuru_air_school,
			name = "Wrath of Air Totem",
			effect = "Provides spell haste to all party members",
            range = "30",
            duration = 300,
            
			ranks = 
            {
                ["0"] = "Rank 1",
                ["3738"] = "Rank 1",
            }
		},
		[TotemGuru_Textures.Poison] = 
		{
			school = TotemGuru_water_school,
			name = "Cleansing Totem",
			effect = "Attempts to remove 1 poison effect from party members every 5 seconds",
            range = "30",
            duration = 300,
			ranks = 
            {
				["0"] = "Rank 1",
                ["8166"] = "Rank 1",
            }
		},
		-- [TotemGuru_Textures.Disease] = 
		-- {
			-- school = TotemGuru_water_school,
			-- name = "Disease Clensing Totem",
			-- effect = "Attempts to remove 1 disease effect from party members every 5 seconds.",
            -- range = "30",
            -- duration = 300,
			-- ranks = 
            -- {
				-- ["0"] = "Rank 1",
                -- ["8170"] = "Rank 1",
            -- }
		-- },	
		[TotemGuru_Textures.FireResistance] = 
		{
			school = TotemGuru_water_school,
			name = "Fire Resistance Totem",
			effect = "Increases the fire resistance of party members",
            range = "30",
            duration = 300,
            
			ranks = 
            {
				["0"] = "Rank 6",
                ["8184"] = "Rank 1*",
                ["10537"] = "Rank 2*",
                ["10538"] = "Rank 3*",
                ["25563"] = "Rank 4*",
                ["58737"] = "Rank 5*",
                ["58739"] = "Rank 6",
            }
            
		},	
		[TotemGuru_Textures.HealingStream] = 
		{
			school = TotemGuru_water_school,
			name = "Healing Stream Totem",
			effect = "Heals group members every 2 seconds",
            range = "20",
            duration = 300,
            ranks = 
            {
				["0"] = "Rank 9",
                ["5394"] = "Rank 1*",
                ["6375"] = "Rank 2*",
                ["6377"] = "Rank 3*",
                ["10462"] = "Rank 4*",
                ["10463"] = "Rank 5*",
                ["25567"] = "Rank 6*",
                ["58755"] = "Rank 7*",
                ["58756"] = "Rank 8*",
                ["58757"] = "Rank 9",
            }
		},
		[TotemGuru_Textures.ManaTide] = 
		{
			school = TotemGuru_water_school,
			name = "Mana Tide Totem",
			effect = "Gain 6% of total mana every 3 seconds.",
            range = "0",
            duration = 12,
			ranks = 
            {
				["0"] = "Rank 1",
                ["16191"] = "Rank 1",
            }
		},
		[TotemGuru_Textures.StoneClaw] = 
		{
			school = TotemGuru_earth_school,
			name = "Stoneclaw Totem",
			effect = "Has 1620 health and taunts creatures. 50% chance to stun for 3 sec. Protects all casters totems",
            range = "8",
            duration = 15,
			ranks = 
            {
				["0"] = "Rank 10",
                ["5730"] = "Rank 1*",
		        ["6390"] = "Rank 2*",
		        ["6391"] = "Rank 3*",
		        ["6392"] = "Rank 4*",
		        ["10427"] = "Rank 5*",
		        ["10428"] = "Rank 6*",
		        ["25525"] = "Rank 7*",
		        ["58580"] = "Rank 8*",
		        ["58581"] = "Rank 9*",
		        ["58582"] = "Rank 10",
            }
		},
		[TotemGuru_Textures.EarthBind] = 
		{
			school = TotemGuru_earth_school,
			name = "Earthbind Totem",
			effect = "Slows enemy movement",
            range = "10",
            duration = 45,
            ranks = 
            {
				["0"] = "Rank 1",
                ["2484"] = "Rank 1",
            }
		},
		[TotemGuru_Textures.StoneSkin] = 
		{
			school = TotemGuru_earth_school,
			name = "Stoneskin Totem",
			effect = "Increasing party members armor by 1150.  Lasts 5 min.",
            range = "30",
            duration = 300,
			ranks = 
            {
				["0"] = "Rank 10",
                ["8071"] = "Rank 1*",
		        ["8154"] = "Rank 2*",
		        ["8155"] = "Rank 3*",
                ["10406"] = "Rank 4*",
                ["10407"] = "Rank 5*",
                ["10408"] = "Rank 6*",
                ["25508"] = "Rank 7*",
                ["25509"] = "Rank 8*",
                ["58751"] = "Rank 9*",
                ["58753"] = "Rank 10",
            }
		},
		[TotemGuru_Textures.StrengthOfEarth] = 
		{
			school = TotemGuru_earth_school,
			name = "Strength Of Earth Totem",
			effect = "Increases the strength and agility of all party members",
            range = "30",
            duration = 300,
			ranks = 
            {
				["0"] = "Rank 8",
                ["8075"] = "Rank 1*",
                ["8160"] = "Rank 2*",
                ["8161"] = "Rank 3*",
                ["10442"] = "Rank 4*",
                ["25361"] = "Rank 5*",
                ["25528"] = "Rank 6*",
                ["57622"] = "Rank 7*",
                ["58643"] = "Rank 8",
            }
		},
		[TotemGuru_Textures.EarthElemental] = 
		{
			school = TotemGuru_earth_school,
			name = "Earth Elemental Totem",
			effect = "Calls forth a greater earth elemental to protect the caster and <his/her> allies.",
            range = "0",
            duration = 120,
			ranks = 
            {
				["0"] = "Rank 1",
                ["2062"] = "Rank 1",
            }
		},
		[TotemGuru_Textures.Tremor] = 
		{
			school = TotemGuru_earth_school,
			name = "Tremor Totem",
			effect = "Shakes the ground around it, removing Fear, Charm and Sleep effects from party members",
            range = "30",
            duration = 300,
            ranks = 
            {
				["0"] = "Rank 1",
                ["8143"] = "Rank 1",
            }
		},
		[TotemGuru_Textures.Wrath] = 
		{
			school = TotemGuru_fire_school,
			name = "Totem of Wrath",
			effect = "Increases the spell power and critical strike chance of all attacks for all party and raid members",
            range = "0",
            duration = 300,
            ranks = 
            {
				["0"] = "Rank 3",
                ["30706"] = "Rank 1*",
                ["55720"] = "Rank 2*",
                ["57721"] = "Rank 3*",
                ["57722"] = "Rank 3",
            }
		},
		[TotemGuru_Textures.Searing] = 
		{
			school = TotemGuru_fire_school,
			name = "Searing Totem",
			effect = "Repeatedly attacks an enemy with Fire damage",
            range = "20",
            duration = 60,
			ranks = 
            {
				["0"] = "Rank 10",
                ["3599"] = "Rank 1*",
                ["6363"] = "Rank 2*",
                ["6364"] = "Rank 3*",
                ["6365"] = "Rank 4*",
                ["10437"] = "Rank 5*",
                ["10438"] = "Rank 6*",
                ["25533"] = "Rank 7*",
                ["58699"] = "Rank 8*",
                ["58703"] = "Rank 9*",
                ["58704"] = "Rank 10",
            }
		},
		[TotemGuru_Textures.Magma] = 
		{
			school = TotemGuru_fire_school,
			name = "Magma Totem",
			effect = "Fire damage to all creatures within 8 yards every 2 seconds",
            range = "",
            duration = 20,
			ranks = 
            {
				["0"] = "Rank 7",
                ["8190"] = "Rank 1*",
                ["10585"] = "Rank 2*",
                ["10586"] = "Rank 3*",
                ["10587"] = "Rank 4*",
                ["25552"] = "Rank 5*",
                ["58731"] = "Rank 6*",
                ["58734"] = "Rank 7",
            }
		},
		[TotemGuru_Textures.FlameTongue] = 
		{
			school = TotemGuru_fire_school,
			name = "Flametongue Totem",
			effect = "Increases spell and healing of party memebers",
            range = "30",
            duration = 300,
			ranks = 
            {
				["0"] = "Rank 8",
                ["8227"] = "Rank 1*",
                ["8249"] = "Rank 2*",
                ["10526"] = "Rank 3*",
                ["16387"] = "Rank 4*",
                ["25557"] = "Rank 5*",
                ["58649"] = "Rank 6*",
                ["58652"] = "Rank 7*",
                ["58656"] = "Rank 8",
            }
		},	
-- 		[TotemGuru_Textures.FireNova] = 
-- 		{
-- 			school = TotemGuru_fire_school,
-- 			name = "Fire Nova Totem",
-- 			effect = "Inflicts fire damage to enemies when it explodes.",
--             range = "10",
--             duration = 5,
--             
-- 			ranks = 
--             {
-- 				["0"] = "Rank 9",
--                 ["1535"] = "Rank 1*",
--                 ["8498"] = "Rank 2*",
--                 ["8499"] = "Rank 3*",
--                 ["11314"] = "Rank 4*",
--                 ["11315"] = "Rank 5*",
--                 ["25546"] = "Rank 6*",
--                 ["25547"] = "Rank 7*",
--                 ["61649"] = "Rank 8*",
--                 ["61657"] = "Rank 9",
--             }
-- 		},
		[TotemGuru_Textures.FrostResistance] = 
		{
			school = TotemGuru_fire_school,
			name = "Frost Resistance Totem",
			effect = "Increases party members frost resistance.",
            range = "30",
            duration = 300,
			ranks = 
            {
				["0"] = "Rank 6",
                ["8181"] = "Rank 1*",
                ["10478"] = "Rank 2*",
                ["10479"] = "Rank 3*",
                ["25560"] = "Rank 4*",
                ["58741"] = "Rank 5*",
                ["58745"] = "Rank 6",
            }
		},
		[TotemGuru_Textures.FireElemental] = 
		{
			school = TotemGuru_fire_school,
			name = "Fire Elemental Totem",
			effect = "Calls forth a greater fire elemental to rain destruction on the caster's enemies.",
            range = "",
            duration = 120,
			ranks = 
            {
				["0"] = "Rank 1",
                ["2894"] = "Rank 1",
                
            }
		},
	
}
