--  TotemGuru is a world of warcraft addon for showing totems during raiding
--  Copyright (C) 2009 Jon Edmunds (je95(AT)zepler.org.uk)
--  Create Date : 8/16/2009 9:16:05 AM
--  This file is part of the TotemGuru Wow Addon.
--
--  TotemGuru is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
-- 
--  TotemGuru is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
-- 
--  You should have received a copy of the GNU General Public License
--  along with TotemGuru.  If not, see <http://www.gnu.org/licenses/>.

TotemGuruSettingsGUI = { 
						font = STANDARD_TEXT_FONT,--"Fonts\\FRIZQT__.ttf",
						fontsize = 12,
						fontcolour = NORMAL_FONT_COLOR,
						info = {}
						};
-------------------------------------
-- TotemGuruSettingsGUI:init() ------
-------------------------------------
function TotemGuruSettingsGUI:init()
	local x,y
	-------------------------------------
	------------ Main Panel -------------
	-------------------------------------
	self.mainPanel = CreateFrame( "Frame", "TotemGuruSettingsGUI", UIParent);
	self.mainPanel.name = "TotemGuru V"..tostring(GetAddOnMetadata("TotemGuru", "Version"))
	
	self.mainPanel.title = FrameTitle(self.mainPanel.name,self.mainPanel)
	self.mainPanel.subtitle1 = FrameSubtitle("General Settings",self.mainPanel)
	x = 30
	y = -80
	--y = self:createChkBox("TotemGuruOff","Disable totemGuru\n(Note: You may need to reset instance\nsettings after changing this)",50,-80,self.mainPanel,TotemGuruMain_Toggle)
   	y = self:createChkBox("Loadnone","Load TotemGuru at all times",x,y,self.mainPanel,TotemGuruMain_CheckInstance)
	y = self:createChkBox("Loadpvp","Load TotemGuru when in Battleground",x,y,self.mainPanel,TotemGuruMain_CheckInstance)
	y = self:createChkBox("Loadarena","Load TotemGuru when in Arena",x,y,self.mainPanel,TotemGuruMain_CheckInstance)
	y = self:createChkBox("Loadparty","Load TotemGuru when in 5 man instance",x,y,self.mainPanel,TotemGuruMain_CheckInstance)
	y = self:createChkBox("Loadraid","Load TotemGuru when in a Raid instance",x,y,self.mainPanel,TotemGuruMain_CheckInstance)

    InterfaceOptions_AddCategory(self.mainPanel);
    
    -------------------------------------
	------------ Options Panel ----------
	-------------------------------------
    self.OptionsPanel =  CreateFrame( "Frame", "TotemGuruSettingsGUI-Options", UIParent);
    self.OptionsPanel.name = "Options";
	self.OptionsPanel.parent = self.mainPanel.name
	self.OptionsPanel.title = FrameTitle(self.mainPanel.name .. " " .. self.OptionsPanel.name,self.OptionsPanel)
	self.OptionsPanel.subtitle1 = FrameSubtitle("Options",self.OptionsPanel)
	x = 30
	y = -80
	y = self:createChkBox("LockWindow","Forces the use of the alt key to move the main window",x,y,self.OptionsPanel,TotemGuruMain_Redraw)
	y = self:createChkBox("TooltipsEnabled","Enable tooltips",x,y,self.OptionsPanel)
	y = self:createChkBox("ShowCooldowns","Show Cooldowns",x,y,self.OptionsPanel)
	y = self:createChkBox("ShowWarnings","Show Missing totem warnings",x,y,self.OptionsPanel,TotemGuru_CheckWarningsToggle)
	y = self:createChkBox("ShowBuffFlash","Show which totems are giving us a buff",x,y,self.OptionsPanel,TotemGuruMain_Redraw)
	y = self:createChkBox("ReceiveAssignments","Allow the sending/receiving of totem Assignments",x,y,self.OptionsPanel,TotemGuruMain_Redraw)

	-- not sure if this was a bug but in BG's on the ptr we sometimes saw enemy players totems. This needs some testing
	-- as if it is reliable this could be a bonus for PVP'rs
	--y = self:createChkBox("NoEnemyPlayers","Hide Enemy Players (PVP)",x,y,self.OptionsPanel,TotemGuruMain_Redraw)
	
	
	y = self:CreateMonitorDropdown(x + 40,y-10)	
	InterfaceOptions_AddCategory(self.OptionsPanel);


	-------------------------------------
	--------- Size Panel -------------
	-------------------------------------
    self.SizePanel =  CreateFrame( "Frame", "TotemGuruSettingsGUI-Size", UIParent );
    self.SizePanel.name = "Display Size";
	self.SizePanel.parent = self.mainPanel.name
	self.SizePanel.title = FrameTitle(self.mainPanel.name,self.SizePanel)
	self.SizePanel.subtitle1 = FrameSubtitle("Size Settings",self.SizePanel)
	x = 140
	y = -100
	y = self:createSlider("TotemGuruScale", "Main window size", self.SizePanel, 0.3, 2, 0.001, x, y, TotemGuruUpdateScale)
	InterfaceOptions_AddCategory(self.SizePanel);


	-------------------------------------
	--------- Alpha Panel -------------
	-------------------------------------
    self.AlphaPanel =  CreateFrame( "Frame", "TotemGuruSettingsGUI-Alpha", UIParent );
    self.AlphaPanel.name = "Display Alpha";
	self.AlphaPanel.parent = self.mainPanel.name
	self.AlphaPanel.title = FrameTitle(self.mainPanel.name,self.AlphaPanel)
	self.AlphaPanel.subtitle1 = FrameSubtitle("Alpha Settings",self.AlphaPanel)
	x = 140
	y = -100
	y = self:createSlider("BackgroundAlpha", "Main window Alpha", self.AlphaPanel, 0.1, 1, 0.01,x,y,UpdateAlpha)
	y = self:createSlider("ButtonsAlpha", "Main Windows Buttons", self.AlphaPanel, 0.1, 1, 0.01,x,y,UpdateAlpha)
	y = self:createSlider("WarningsAlpha", "Warning icons Alpha", self.AlphaPanel, 0.1, 1, 0.01,x,y,UpdateAlpha)
	y = self:createSlider("PlayerNameAlpha", "Player Name Alpha", self.AlphaPanel, 0.1, 1, 0.01,x,y,UpdateAlpha)
	y = self:createSlider("TotemNormalAlpha", "Totem's Normal/Buffed Alpha", self.AlphaPanel, 0.1, 1, 0.01,x,y,UpdateAlpha)
	y = self:createSlider("TotemUnbuffedAlpha", "Totem's Unbuffed Alpha", self.AlphaPanel, 0.1, 1, 0.01,x,y,UpdateAlpha)
	InterfaceOptions_AddCategory(self.AlphaPanel);
	
	-------------------------------------
	--------- Totems Panel -------------
	-------------------------------------
    self.TotemsPanel =  CreateFrame( "Frame", "TotemGuruSettingsGUI-Totems", UIParent );
    self.TotemsPanel.name = "Totem Priorites";
	self.TotemsPanel.parent = self.mainPanel.name
	self.TotemsPanel.title = FrameTitle(self.mainPanel.name,self.TotemsPanel)
	self.TotemsPanel.subtitle1 = FrameSubtitle("Set the order in which totems will be warned",self.TotemsPanel)
	self:createTotemsWindow("TotemGuruTotemPriorities", "blah blah", self.TotemsPanel )
	InterfaceOptions_AddCategory(self.TotemsPanel);
	
	-------------------------------------
	--------- Assignment Panel -------------
	-------------------------------------
  self.AssignmentPanel =  CreateFrame( "Frame", "TotemGuruSettingsGUI-Assignment", UIParent );
  self.AssignmentPanel.name = "Totem Assignments";
	self.AssignmentPanel.parent = self.mainPanel.name
	self.AssignmentPanel.title = FrameTitle(self.mainPanel.name,self.AssignmentPanel)
	self.AssignmentPanel.subtitle1 = FrameSubtitle("Set the totems for all shamans in the group",self.AssignmentPanel)
	--self:createTotemsWindow("TotemGuruTotemPriorities", "blah blah", self.TotemsPanel )
	x = 140
	y = -100
	y = self:createButton("Assign","Assign",x,y,self.AssignmentPanel,TotemGuruAssignments_LoadWindow)
	y = self:createButton("ShowButton","TotemBar",x,y,self.AssignmentPanel,TotemGuruwindows_SingleButtonCast)
	y = self:CreateMulticastDropdown(x-40,y-10)	
   	InterfaceOptions_AddCategory(self.AssignmentPanel);

end

-------------------------------------
----------- UpdateAlpha -------------
-------------------------------------
function UpdateAlpha()
	TotemGuruWindows.MainFrame:SetAlpha(TotemGuruConfig.BackgroundAlpha)
	TotemGuruWindows.ButtonsFrame:SetAlpha(TotemGuruConfig.ButtonsAlpha)
	TotemGuruWindows.WarningsFrame:SetAlpha(TotemGuruConfig.WarningsAlpha)
	TotemGuruWindows.PlayerNameFrame:SetAlpha(TotemGuruConfig.PlayerNameAlpha)
end

-------------------------------------
----------- FrameTitle --------------
-------------------------------------
function FrameTitle(text,frame)

	local fontsting = frame:CreateFontString(nil, 'ARTWORK', 'GameFontNormalLarge')
	fontsting:SetJustifyH("MIDDLE")
	fontsting:SetPoint('TOPLEFT', 0, -20)
	fontsting:SetPoint('TOPRIGHT', 0, -20)
	fontsting:SetText(text)
	return fontstring
end
-------------------------------------
--------- FrameSubtitle -------------
-------------------------------------
function FrameSubtitle(text,frame)

	local fontsting = frame:CreateFontString(nil, "ARTWORK", "GameFontWhite")
	fontsting:SetJustifyH("MIDDLE")
	fontsting:SetPoint("TOPLEFT",0,-40)
	fontsting:SetPoint("TOPRIGHT",0,-40)
	fontsting:SetText(text)
	return fontstring
end
---------------------------------------
-- TotemGuruSettingsGUI:createChkBox --
---------------------------------------
function TotemGuruSettingsGUI:createChkBox(name,title,x,y,frame,func)
	local checkbox = 
		CreateFrame( "CheckButton", "chkButton"..name,frame,"OptionsCheckButtonTemplate" );
	frame["chkButton"..name] = checkbox
	checkbox:SetPoint("TOPLEFT", frame, "TOPLEFT", x,y)
	checkbox:SetScript("OnClick", 
		function(self)
			if ( self:GetChecked() ) then
				PlaySound("igMainMenuOptionCheckBoxOn");
			else
				PlaySound("igMainMenuOptionCheckBoxOff");
			end
			TotemGuruConfig[name] = checkbox:GetChecked()
			if func then func() end
			TotemGuruWindows:UpdateHeight()
		end)
	checkbox:SetScript("OnShow", 
		function(self) 
			self:SetChecked(TotemGuruConfig[name]) 
		end)
	getglobal("chkButton"..name.."Text"):SetText(title);
	checkbox:SetChecked(TotemGuruConfig[name])
	return (y-20)
end


---------------------------------------
-- TotemGuruSettingsGUI:createButton --
---------------------------------------
function TotemGuruSettingsGUI:createButton(name,title,x,y,frame,func)
	local button = 
		CreateFrame( "Button", "Button"..name,frame,'OptionsButtonTemplate');
	frame["Button"..name] = button
	button:SetPoint("TOPLEFT", frame, "TOPLEFT", x,y)
	button:SetScript("OnClick", 
		function(self)
			PlaySound("igMainMenuOptionCheckBoxOn")
			if func then func() end
			TotemGuruWindows:UpdateHeight()
		end)
	getglobal("Button"..name.."Text"):SetText(title);
	return (y-20)
end

---------------------------------------
-- TotemGuruSettingsGUI:createSlider --
---------------------------------------
function TotemGuruSettingsGUI:createSlider(variable,title, parent, low, high, step, x, y , func)
	local name = parent:GetName() .. variable
	local slider = CreateFrame('Slider', name, parent, 'OptionsSliderTemplate')
	slider:SetScript('OnValueChanged', 
		function(self)
			TotemGuruConfig[variable] = self:GetValue()
			if func then func() end
			TotemGuruMain_Redraw()
		end)
	slider:SetScript("OnShow", 
		function(self) 
			self:SetValue(TotemGuruConfig[variable]) 
		end)
	slider:SetMinMaxValues(low, high)
	slider:SetValueStep(step)
	slider:SetPoint("TOPLEFT", parent, "TOPLEFT",x,y)
	getglobal(name .. 'Text'):SetText(title)
	getglobal(name .. 'Low'):SetText('less')
	getglobal(name .. 'High'):SetText('more')
	slider:SetValue(TotemGuruConfig[variable])
	BlizzardOptionsPanel_Slider_Enable(slider) --colors the slider properly
	return (y-45)
end
------------------------------------------------
-- TotemGuruSettingsGUI:CreateMonitorDropdown --
------------------------------------------------
function TotemGuruSettingsGUI:CreateMonitorDropdown(x,y)
	local parent = self.OptionsPanel
	local title = "Select totems to monitor"
	local frame = CreateFrame('Frame', "MonitorTypeDropDownFrame" , parent,'UIDropDownMenuTemplate')
	frame:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y-20)
	
	frame.titletext = frame:CreateFontString(nil, 'BACKGROUND')
	frame.titletext:SetPoint('BOTTOMLEFT', frame, 'TOPLEFT')
	frame.titletext:SetFontObject('GameFontNormal')
	frame.titletext:SetText(title)
	if TotemGuruConfig and TotemGuruConfig.Monitor then
		if TotemGuruConfig.Monitor.Raid then
			getglobal("MonitorTypeDropDownFrameText"):SetText("Raid")
		elseif TotemGuruConfig.Monitor.Party then
			getglobal("MonitorTypeDropDownFrameText"):SetText("Party")
		elseif TotemGuruConfig.Monitor.All then
			getglobal("MonitorTypeDropDownFrameText"):SetText("All")
		end
	end
	UIDropDownMenu_Initialize(frame, CreateMonitorMenu)	
	return (y-20)
end
-----------------------
-- CreateMonitorMenu --
-----------------------
function CreateMonitorMenu()
	TotemGuruSettingsGUI.info.text		= "Raid";
	TotemGuruSettingsGUI.info.value		= someglobalvariable;
	TotemGuruSettingsGUI.info.func		= function () 
		TotemGuruConfig.Monitor = {All = false,Party = false,Raid = true} 
		getglobal("MonitorTypeDropDownFrameText"):SetText("Raid")
		end
	UIDropDownMenu_AddButton(TotemGuruSettingsGUI.info);
	TotemGuruSettingsGUI.info.text		= "Party";
	TotemGuruSettingsGUI.info.value		= someglobalvariable;
	TotemGuruSettingsGUI.info.func		= function () 
		TotemGuruConfig.Monitor = {All = false,Party = true,Raid = false} 
		getglobal("MonitorTypeDropDownFrameText"):SetText("Party")
		end
	UIDropDownMenu_AddButton(TotemGuruSettingsGUI.info);
	TotemGuruSettingsGUI.info.text		= "All";
	TotemGuruSettingsGUI.info.value		= someglobalvariable;
	TotemGuruSettingsGUI.info.func		= function () 
		TotemGuruConfig.Monitor = {All = true,Party = false,Raid = false} 
		getglobal("MonitorTypeDropDownFrameText"):SetText("All")
		end
	UIDropDownMenu_AddButton(TotemGuruSettingsGUI.info);
end

------------------------------------------------
-- TotemGuruSettingsGUI:CreateMulticastDropdown --
------------------------------------------------
function TotemGuruSettingsGUI:CreateMulticastDropdown(x,y)
	local parent = self.AssignmentPanel
	local title = "Select Multicast button|nto use for Assigned totems"
	local frame = CreateFrame('Frame', "MulticastTypeDropDownFrame" , parent,'UIDropDownMenuTemplate')
	frame:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y-20)
	frame:SetPoint("TOPRIGHT", parent, "TOPRIGHT", x, y-20)

	frame.titletext = frame:CreateFontString(nil, 'BACKGROUND')
	frame.titletext:SetPoint('BOTTOM', frame,'TOP',-120,0)
	frame.titletext:SetFontObject('GameFontNormal')
	frame.titletext:SetText(title)
	if TotemGuruConfig and TotemGuruConfig.Multicast then
		if TotemGuruConfig.Multicast.Ancestors then
			getglobal("MulticastTypeDropDownFrameText"):SetText("Ancestors")
		elseif TotemGuruConfig.Multicast.Elements then
			getglobal("MulticastTypeDropDownFrameText"):SetText("Elements")
		elseif TotemGuruConfig.Multicast.Spirits then
			getglobal("MulticastTypeDropDownFrameText"):SetText("Spirits")
		end
	end
	UIDropDownMenu_Initialize(frame, CreateMulticastMenu)	
	return (y-20)
end
-----------------------
-- CreateMulticastMenu --
-----------------------
function CreateMulticastMenu()
	TotemGuruSettingsGUI.info.text		= "Ancestors";
	TotemGuruSettingsGUI.info.value		= someglobalvariable;
	TotemGuruSettingsGUI.info.func		= function () 
	  TotemGuruConfig.Multicast = {Spirits = false,Elements = false,Ancestors = true} 
		getglobal("MulticastTypeDropDownFrameText"):SetText("Ancestors")
		end
	UIDropDownMenu_AddButton(TotemGuruSettingsGUI.info);
	TotemGuruSettingsGUI.info.text		= "Elements";
	TotemGuruSettingsGUI.info.value		= someglobalvariable;
	TotemGuruSettingsGUI.info.func		= function () 
		TotemGuruConfig.Multicast = {Spirits = false,Elements = true,Ancestors = false}  
		getglobal("MulticastTypeDropDownFrameText"):SetText("Elements")
		end
	UIDropDownMenu_AddButton(TotemGuruSettingsGUI.info);
	TotemGuruSettingsGUI.info.text		= "Spirits";
	TotemGuruSettingsGUI.info.value		= someglobalvariable;
	TotemGuruSettingsGUI.info.func		= function () 
		TotemGuruConfig.Multicast = {Spirits = true,Elements = false,Ancestors = false} 
		getglobal("MulticastTypeDropDownFrameText"):SetText("Spirits")
		end
	UIDropDownMenu_AddButton(TotemGuruSettingsGUI.info);
end

-------------------------------
-- TotemGuru_CreateTotemsWindow
-------------------------------
function TotemGuruSettingsGUI:createTotemsWindow(name,title, parent)
	if not TotemGuruData.TotemsWindow then
		TotemGuruData.TotemsWindow = parent
		local totemWindow = TotemGuruData.TotemsWindow
		totemWindow:SetPoint("CENTER");
		local prioritySchool, schoolTotems
		totemWindow.TotemCount = 0
		for prioritySchool,schoolTotems in pairs(TotemGuruConfig.Totems) do
			local totemsIndex=0
			local totemIcon = schoolTotems[tostring(totemsIndex)]
			
			while (totemIcon) do
				if (not totemWindow[totemIcon]) then
					totemWindow[totemIcon] = {}
				end
				local localbutton = totemWindow[totemIcon]
				local totem = TotemGuruTotemsInfo[totemIcon]
				if(totem) then
					TotemGuru_Create_Totem_icon(totemWindow,localbutton,totemIcon,"0",prioritySchool,TotemGuru_OnTotemPriorityClick)
					localbutton.button:SetBackdrop({bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
							  edgeFile = "Interface/DialogFrame/UI-DialogBox-Border", 
							  tile = true, tileSize = 1, edgeSize = 16, 
							  insets = { left = 4, right = 4, top = 4, bottom = 4 }});
					localbutton.button:SetParent(totemWindow)
					localbutton.button:SetBackdropBorderColor(1,0,0,1);
					localbutton.button:SetBackdropColor(1,0,0,1);

				end
				TotemGuru_Create_position_arrows(totemWindow,localbutton.button,totemIcon,TotemGuru_TotemUp_OnClick,TotemGuru_TotemDown_OnClick)
				totemsIndex = totemsIndex+1
				totemIcon = schoolTotems[tostring(totemsIndex)]
				if (totemsIndex > totemWindow.TotemCount) then
					totemWindow.TotemCount = totemsIndex
				end
			end
		end
		for counter = 0, totemWindow.TotemCount-1, 1 do
			local fontstring = totemWindow:CreateFontString(nil, "OVERLAY", "GameFontNormal")
			totemWindow[("totemRowFontstring"..counter)] = fontstring
			fontstring:SetFont(TotemGuruConstants.FONT_TYPE, TotemGuruConstants.TOOLTIP_FONT_SIZE)
			fontstring:SetNonSpaceWrap(nil)
			fontstring:SetSpacing(0) 
			fontstring:SetText(tostring(counter+1))
		end
		local fontstring = totemWindow:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		totemWindow[("TitleFontstring")] = fontstring
		fontstring:SetFontObject('GameFontNormal')
		fontstring:SetJustifyH("MIDDLE")
		fontstring:SetText("Click to warn for missing Totems\nRows are number of players/Priority. \nThis will only show warnings for the number of players \ncurrently active in the main window")
	end
	TotemGuru_TotemsWindow_Redraw()
end

--------------------------------
-- TotemGuru_TotemsWindow_Redraw
--------------------------------
function TotemGuru_TotemsWindow_Redraw()
	local totemWindow = TotemGuruData.TotemsWindow
	if totemWindow then
		local totemCountY = 0
		local fontstring
		local xoffset = 100
		local yoffset = -120
		local x
		local y
		local previousTotemCount = -1
		for prioritySchool,schoolTotems in pairs(TotemGuruConfig.Totems) do
			local totemsIndex=0
			local totemIcon = schoolTotems[tostring(totemsIndex)]
			while (totemIcon) do
				if totemCountY < totemsIndex then
					totemCountY = totemsIndex
				end
				x = xoffset + TotemGuruConstants.BORDER_SIZE + TotemGuruConstants.TOTEM_NUMBER_SPACE_SIZE*2 +
				(
					(prioritySchool-1) 
					* (TotemGuruConstants.ARROW_SIZE+TotemGuruConstants.TOTEM_ICON_SIZE + TotemGuruConstants.TOTEM_ICON_SPACER)
				)
				y = yoffset -(TotemGuruConstants.BORDER_SIZE + TotemGuruConstants.HEADER_SIZE + 
					((TotemGuruConstants.TOTEM_ICON_SIZE + TotemGuruConstants.TOTEM_ICON_SPACER)*(totemsIndex)))
  				local button = totemWindow[totemIcon].button
				
				button:SetPoint("TOPLEFT", totemWindow, "TOPLEFT", 
					(x+TotemGuruConstants.ARROW_SIZE),
					y)
				button:SetWidth(TotemGuruConstants.TOTEM_ICON_SIZE)
				button:SetHeight(TotemGuruConstants.TOTEM_ICON_SIZE)
				
				-- if we are monitoring this totem then we need to add the pressed effect
				if( TotemGuruConfig.MonitoredTotems[prioritySchool]
					and TotemGuruConfig.MonitoredTotems[prioritySchool][totemIcon]) then
					button.icon:SetPoint("TOPLEFT",button,"TOPLEFT",5,-5)
					button.icon:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-5,5)
				
				else
					button.icon:SetPoint("TOPLEFT",button,"TOPLEFT",0,0)
					button.icon:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",0,0)
				end				
				
				if totemsIndex >0 then
					button.UpArrow:SetPoint("TOPLEFT", totemWindow, "TOPLEFT", 
						x, 
						y)
					button.UpArrow:SetWidth(TotemGuruConstants.ARROW_SIZE)
					button.UpArrow:SetHeight(TotemGuruConstants.ARROW_SIZE)
					button.UpArrow:Show()
				else
					button.UpArrow:Hide()
				end
				if schoolTotems[tostring(totemsIndex+1)] then
					button.DownArrow:SetPoint("TOPLEFT", totemWindow, "TOPLEFT", 
						x, 
						(y-(TotemGuruConstants.TOTEM_ICON_SIZE-TotemGuruConstants.ARROW_SIZE)))
					button.DownArrow:SetWidth(TotemGuruConstants.ARROW_SIZE)
					button.DownArrow:SetHeight(TotemGuruConstants.ARROW_SIZE)
					button.DownArrow:Show()
				else
					button.DownArrow:Hide()
				end
				if (previousTotemCount < totemCountY) and (totemWindow[("totemRowFontstring"..totemCountY)]) then
					previousTotemCount = totemCountY
					fontstring = totemWindow[("totemRowFontstring"..totemCountY)]
					fontstring:SetPoint("TOPLEFT", totemWindow, "TOPLEFT", xoffset+TotemGuruConstants.BORDER_SIZE, ( y- (TotemGuruConstants.TOTEM_ICON_SIZE-TotemGuruConstants.ARROW_SIZE-(TotemGuruConstants.TOTEM_NUMBER_SPACE_SIZE/2))))
					fontstring:SetPoint("TOPRIGHT", totemWindow, "TOPLEFT", xoffset+TotemGuruConstants.BORDER_SIZE+TotemGuruConstants.TOTEM_NUMBER_SPACE_SIZE, TotemGuruConstants.BORDER_SIZE)

					fontstring:SetFont(TotemGuruConstants.FONT_TYPE, TotemGuruConstants.TOOLTIP_FONT_SIZE)
				end
				totemsIndex = totemsIndex+1
				totemIcon = schoolTotems[tostring(totemsIndex)]
				
			end
		end
		x = (x+TotemGuruConstants.ARROW_SIZE+TotemGuruConstants.TOTEM_ICON_SIZE + TotemGuruConstants.TOTEM_ICON_SPACER+TotemGuruConstants.BORDER_SIZE)
		y = -(TotemGuruConstants.BORDER_SIZE + TotemGuruConstants.HEADER_SIZE)
		totemWindow.TitleFontstring:SetPoint("TOPLEFT", totemWindow, "TOPLEFT", 0,-60)
		totemWindow.TitleFontstring:SetPoint("TOPRIGHT", totemWindow, "TOPRIGHT", 0, -60)
		totemWindow.TitleFontstring:SetFontObject('GameFontNormal')
		
	end
	
end
