local Loc = LibStub("AceLocale-3.0"):NewLocale("Details_RaidInfo-SiegeOfOrgrimmar", "ptBR") 

if (not Loc) then
	return 
end 

Loc ["PLUGIN_NAME"] = "Info da Raide Cerco a Orgrimmar"
Loc ["STRING_RAID_NAME"] = "Cerco a Orgrimmar"

---------------------------------------------------------------------------------------------------

