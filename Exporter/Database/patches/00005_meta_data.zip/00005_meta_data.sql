CREATE TABLE `lp_consent`.`meta_data` (
  `last_fetch` BIGINT(20) UNSIGNED NOT NULL DEFAULT 0
);

INSERT INTO `lp_consent`.`meta_data` (`last_fetch`) VALUES (0);