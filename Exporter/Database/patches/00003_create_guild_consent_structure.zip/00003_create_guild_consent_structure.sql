CREATE TABLE `lp_consent`.`guild_consent` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `guild_id` INT UNSIGNED NOT NULL,
  `responsible_character_id` INT UNSIGNED NOT NULL,
  `consent_given_when` BIGINT UNSIGNED NOT NULL DEFAULT UNIX_TIMESTAMP(),
  `consent_withdrawn_when` BIGINT UNSIGNED,
  PRIMARY KEY (`id`)
);
