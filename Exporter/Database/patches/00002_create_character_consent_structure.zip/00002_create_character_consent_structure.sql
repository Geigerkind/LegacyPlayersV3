CREATE TABLE `lp_consent`.`character_consent` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `character_id` INT UNSIGNED NOT NULL,
  `consent_given_when` BIGINT UNSIGNED NOT NULL DEFAULT UNIX_TIMESTAMP(),
  `consent_withdrawn_when` BIGINT UNSIGNED,
  PRIMARY KEY (`id`)
);
