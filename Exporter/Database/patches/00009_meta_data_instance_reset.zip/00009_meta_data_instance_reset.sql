ALTER TABLE `lp_consent`.`meta_data`
	ADD COLUMN `last_instance_reset_fetch` BIGINT(20) UNSIGNED DEFAULT 0 NOT NULL AFTER `last_fetch`;
